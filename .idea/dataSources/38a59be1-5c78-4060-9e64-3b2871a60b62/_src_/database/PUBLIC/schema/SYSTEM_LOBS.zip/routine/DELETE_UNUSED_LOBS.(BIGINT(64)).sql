CREATE PROCEDURE SYSTEM_LOBS.DELETE_UNUSED_LOBS(IN LIMIT_ID BIGINT, OUT TOTAL_COUNT INTEGER)
  SPECIFIC DELETE_UNUSED_LOBS_10057
  LANGUAGE SQL
  NOT DETERMINISTIC
  MODIFIES SQL DATA
  NEW SAVEPOINT LEVEL BEGIN ATOMIC DECLARE TABLE TEMP_IDS (TEMP_ID INT );
  DECLARE TEMP_COUNT INT DEFAULT 0;
  DECLARE TOTAL INT DEFAULT 0;
  REPEAT INSERT INTO MODULE.TEMP_IDS (TEMP_ID) SELECT LOB_IDS.LOB_ID
                                               FROM SYSTEM_LOBS.LOB_IDS
                                               WHERE LOB_USAGE_COUNT = 0 AND LOB_IDS.LOB_ID < LIMIT_ID
                                               LIMIT 1000;
    INSERT INTO SYSTEM_LOBS.BLOCKS (BLOCK_ADDR, BLOCK_COUNT, TX_ID) (SELECT
                                                                       BLOCK_ADDR,
                                                                       BLOCK_COUNT,
                                                                       0
                                                                     FROM SYSTEM_LOBS.LOBS
                                                                     WHERE LOBS.LOB_ID IN (SELECT TEMP_ID
                                                                                           FROM MODULE.TEMP_IDS));
    DELETE FROM SYSTEM_LOBS.LOBS
    WHERE LOBS.LOB_ID IN (SELECT TEMP_ID
                          FROM MODULE.TEMP_IDS);
    DELETE FROM SYSTEM_LOBS.PARTS
    WHERE LOB_ID IN (SELECT TEMP_ID
                     FROM MODULE.TEMP_IDS);
    DELETE FROM SYSTEM_LOBS.LOB_IDS
    WHERE LOB_IDS.LOB_ID IN (SELECT TEMP_ID
                             FROM MODULE.TEMP_IDS);
    GET DIAGNOSTICS TEMP_COUNT = ROW_COUNT;
    SET TOTAL = TOTAL + TEMP_COUNT;
    DELETE FROM MODULE.TEMP_IDS;
  UNTIL TEMP_COUNT < 1000 END REPEAT;
  SET TOTAL_COUNT = TOTAL;
END;