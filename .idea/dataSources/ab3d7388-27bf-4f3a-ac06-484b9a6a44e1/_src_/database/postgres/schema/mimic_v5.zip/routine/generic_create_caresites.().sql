create function generic_create_caresites() returns void
LANGUAGE plpgsql
AS $$
declare
	rowcnt  integer;
	
begin
    
    select etl.logm('GENERIC_OMOP_LOAD', 'generic_create_caresites' , 'START' );

    insert into mimic_v5.CARE_SITE
    (
        care_site_id
        , care_site_name
        . location_id
        , care_site_source_value
    )
    select 
        nextval('mimic_v5.care_site_id_seq')
        , care_site_source_value as care_site_name
        , coalesce(location_id, 0) as location_id
        , care_site_source_value
    from 
    (
        select distinct 
            provider_name as care_site_source_value
            , location_source_value
        from etl.stage_provider
    ) hosp
    left join mimic_v5.location lo on hosp.location_source_value = lo.location_source_value
    ;
 
  
      get diagnostics rowcnt = ROW_COUNT;
  
      select etl.logm('GENERIC_OMOP_LOAD', 'insert into care site' , rowcnt );
      
      select etl.logm('GENERIC_OMOP_LOAD', 'generic_create_caresites' , 'FINISH' );
      commit;
      
end;
$$;
