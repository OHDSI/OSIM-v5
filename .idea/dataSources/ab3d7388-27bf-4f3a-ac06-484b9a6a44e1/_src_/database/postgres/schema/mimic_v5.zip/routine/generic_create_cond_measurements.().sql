create function generic_create_cond_measurements() returns void
LANGUAGE plpgsql
AS $$
declare
        rowcnt  integer;

    begin

        perform etl.logm('GENERIC_OMOP_LOAD', 'generic_create_cond_measurements from conditions' , 'START' );

        insert into mimic_v5.measurement
        (
            measurement_id,
            person_id,
            measurement_concept_id,
            measurement_date,
            measurement_type_concept_id,
            value_as_concept_id,
            visit_occurrence_id,
            measurement_source_value,
            measurement_source_concept_id,
            provider_id,
            x_srcid,
            x_srcfile
        )
        select
            nextval('mimic_v5.measurement_id_seq') as measurement_id
            , person_id
            , measurement_concept_id
            , measurement_date
            , measurement_type_concept_id
            , value_as_concept_id
            , visit_occurrence_id
            , measurement_source_value
            , measurement_source_concept_id
            , provider_id
            , x_srcid
            , x_srcfile
        from
        (
            select distinct
                v.person_id as person_id
                , coalesce(tar.concept_id, 0 )  as measurement_concept_id
                , s.start_date as measurement_date
                , 44818701 as measurement_type_concept_id  -- 'From physical examination' -- TODO: may need to be changed
                , val.concept_id as value_as_concept_id
                , v.visit_occurrence_id as visit_occurrence_id
                , s.condition_source_value as measurement_source_value
                , coalesce(tar.concept_id, 0) as measurement_source_concept_id
                , pr.provider_id
                , s.id as x_srcid
                , 'STAGE_CONDITION' as x_srcfile
            from etl.stage_condition s
            join mimic_v5.person p on p.person_source_value = s.person_source_value
            left join mimic_v5.visit_occurrence v on s.visit_source_value = v.visit_source_value
            join mimic_v5.concept src on s.condition_source_value = replace(src.concept_code, '.', '' )
                            and src.domain_id like '%Meas%'
                            and coalesce(s.condition_code_source_type, src.vocabulary_id ) = src.vocabulary_id
                            and src.invalid_reason is null
            left join mimic_v5.concept_relationship cr on src.concept_id = cr.concept_id_1
                      			and cr.relationship_id = 'Maps to'
                      			and cr.invalid_reason is null
            left join mimic_v5.concept tar on cr.concept_id_2 = tar.concept_id
                      			and tar.standard_concept = 'S'
                      			and tar.invalid_reason is null
            left join mimic_v5.concept_relationship crv on src.concept_id = crv.concept_id_1
                      			and crv.relationship_id = 'Maps to value'
                      			and crv.invalid_reason is null
            left join mimic_v5.concept val on crv.concept_id_2 = val.concept_id
                      			and val.standard_concept = 'S'
                      			and val.invalid_reason is null
            left join mimic_v5.provider pr on s.provider_source_value = pr.provider_source_value
        ) a
        ;

        get diagnostics rowcnt = ROW_COUNT;

        perform etl.logm('GENERIC_OMOP_LOAD', 'insert into measurements' , rowcnt );

        perform etl.logm('GENERIC_OMOP_LOAD', 'generic_create_cond_measurements from conditions' , 'FINISH' );


    end;
$$;
