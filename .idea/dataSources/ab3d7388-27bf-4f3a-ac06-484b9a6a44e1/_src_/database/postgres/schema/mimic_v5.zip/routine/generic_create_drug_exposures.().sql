create function generic_create_drug_exposures() returns void
LANGUAGE plpgsql
AS $$
declare
  rowcnt integer;

begin



-- drug exposure from pharmacy

 perform etl.logm('OMOP_LOAD', 'create drug_exposures', 'START' );

INSERT INTO mimic_v5.drug_exposure
(
  drug_exposure_id,
  person_id,
  drug_concept_id,
  drug_exposure_start_date,
  drug_exposure_end_date,
  drug_type_concept_id,
  stop_reason,
  refills,
  quantity,
  days_supply,
--  sig,
  route_concept_id,
  effective_drug_dose,
  dose_unit_concept_id,
--  lot_number,
  provider_id,
  visit_occurrence_id,
  drug_source_value,
  drug_source_concept_id,
  route_source_value,
  dose_unit_source_value,
  x_srcid,
  x_srcfile
)
select
  nextval('mimic_v5.drug_exposure_id_seq') as 	drug_exposure_id,
  person_id,
  drug_concept_id,
  drug_exposure_start_date,
  drug_exposure_end_date,
  drug_type_concept_id,
  stop_reason,
  refills,
  quantity,
  days_supply,
--  sig,
  route_concept_id,
  effective_drug_dose,
  dose_unit_concept_id,
--  lot_number,
  provider_id,
  visit_occurrence_id,
  drug_source_value,
  drug_source_concept_id,
  route_source_value,
  dose_unit_source_value,
  x_srcid,
  x_srcfile
from
(
    select
    	p.person_id as person_id,
    	coalesce(tar.concept_id, 0 ) as drug_concept_id,
    	s.drug_start_date  as drug_exposure_start_date,
    	s.drug_end_date as  drug_exposure_end_date,
    	coalesce(cast(s.drug_source_type_value as int),0) as drug_type_concept_id,
    	s.stop_reason as stop_reason,
    	s.refills as refills,
    	s.quantity as quantity,
    	s.days_supply as days_supply,
    	coalesce( rte.concept_id, 0 ) as route_concept_id,
    	s.effective_drug_dose as effective_drug_dose,
    	coalesce( dose.concept_id, 0 ) as dose_unit_concept_id,
    	coalesce( pr.provider_id, 0 )  as provider_id,
    	v.visit_occurrence_id as visit_occurrence_id,
    	s.drug_source_value as drug_source_value,
    	coalesce( src.concept_id, 0) as drug_source_concept_id,
    	s.route_source_value as route_source_value,
      s.dose_unit_source_value as dose_unit_source_value
      , s.id as x_srcid
      , 'STAGE_RX' as x_srcfile
    from etl.stage_rx s
    join mimic_v5.person p on p.person_source_value = s.person_source_value
    left join mimic_v5.visit_occurrence v on s.visit_source_value = v.visit_source_value
    left join mimic_v5.concept src on s.drug_source_value = replace(src.concept_code, '.', '' )
        and src.domain_id like '%Drug%'
        and coalesce(s.drug_source_type, src.vocabulary_id ) = src.vocabulary_id
        and src.invalid_reason is null
    left join mimic_v5.concept_relationship cr on src.concept_id = cr.concept_id_1
        and cr.relationship_id = 'Maps to'
        and cr.invalid_reason is null
    left join mimic_v5.concept tar on cr.concept_id_2 = tar.concept_id
        and tar.standard_concept = 'S'
        and tar.invalid_reason is null
    left join mimic_v5.concept dose on s.dose_unit_source_value = dose.concept_code    ---should be for effective_drug_dose
        and dose.domain_id = 'Unit'
        and dose.invalid_reason is null
        and dose.standard_concept = 'S'
    left join mimic_v5.concept rte on s.route_source_value = rte.concept_code   -- SNOMED Number
        and rte.domain_id = 'Route'
        and rte.invalid_reason is null
        and rte.standard_concept = 'S'
    left join mimic_v5.provider pr on s.provider_source_value = pr.provider_source_value
    where s.drug_start_date is not null
) a
;

  get diagnostics rowcnt = ROW_COUNT;
  perform etl.logm('OMOP_LOAD', 'insert into drug_exposure', rowcnt );
  perform etl.logm('OMOP_LOAD', 'create drug_exposure', 'FINISH' );

end;
$$;
