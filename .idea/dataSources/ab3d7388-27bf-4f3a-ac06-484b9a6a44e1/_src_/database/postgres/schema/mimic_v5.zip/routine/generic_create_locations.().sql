create function generic_create_locations() returns void
LANGUAGE plpgsql
AS $$
declare
	rowcnt  integer;
	
begin
    
     select mimic_v5.logm('GENERIC_OMOP_LOAD', 'generic_create_locations' , 'START' );
 
      insert into mimic_v5.location
      (
        location_id
        , address_1
        , address_2
        , city
        , state
        , zip
        , county
        , location_source_value
      )
      select 
        nextval('mimic_v5.location_id_seq' )
        , address_1 as address_1
        , address_2 as address_2
        , city as city
        , state as state
        , zip as zip 
        , county as county
        , location_source_value as location_source_value
      from
      (
        select distinct 
            address_1 as address_1
            , address_2 as address_2
            , city as city
            , state as state
            , zip as zip   -- substr( zip, 1, 3 ) to get zip_3 for deid purposes, if needed
            , county as county
            , location_source_value
        from etl.stage_patient
        
        union
        
        select distinct 
            address_1 as address_1
            , address_2 as address_2
            , city as city
            , state as state
            , zip as zip   -- substr( zip, 1, 3 ) to get zip_3 for deid purposes, if needed
            , county as county
            , location_source_value
        from etl.stage_provider
        
      ) a
      ;
  
      get diagnostics rowcnt = ROW_COUNT;
  
      select mimic_v5.logm('GENERIC_OMOP_LOAD', 'insert into location' , rowcnt );
      
      select mimic_v5.logm('GENERIC_OMOP_LOAD', 'generic_create_locations' , 'FINISH' );
           
      commit;
      
end;
$$;
