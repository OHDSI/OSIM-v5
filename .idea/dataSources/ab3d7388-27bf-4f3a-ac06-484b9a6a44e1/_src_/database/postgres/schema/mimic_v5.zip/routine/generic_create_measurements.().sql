create function generic_create_measurements() returns void
LANGUAGE plpgsql
AS $$
declare
  rowcnt integer;

begin


perform etl.logm('GENERIC_OMOP_LOAD', 'create measurements', 'START' );

INSERT INTO mimic_v5.measurement
(
    measurement_id,
    person_id,
    measurement_concept_id,
    measurement_date,
    measurement_time,
    measurement_type_concept_id,
    operator_concept_id,
    value_as_number,
    value_as_concept_id,
    unit_concept_id,
    range_low,
    range_high,
    provider_id,
    visit_occurrence_id,
    measurement_source_value,
    measurement_source_concept_id,
    unit_source_value,
    value_source_value,
    x_srcid,
    x_srcfile
 )
 select
    nextval('mimic_v5.measurement_id_seq') as measurement_id,
    person_id,
    measurement_concept_id,
    measurement_date,
    measurement_time,
    measurement_type_concept_id,
    operator_concept_id,
    value_as_number,
    value_as_concept_id,
    unit_concept_id,
    range_low,
    range_high,
    provider_id,
    visit_occurrence_id,
    measurement_source_value,
    measurement_source_concept_id,
    unit_source_value,
    value_source_value,
    x_srcid,
    x_srcfile
  from
 (
    select
       p.person_id as person_id,
       coalesce( tar.concept_id, 0 ) as measurement_concept_id,
       s.measurement_date as measurement_date,
        trim( to_char(extract( hour from s.measurement_date ), '09') ) || ':' ||
          trim( to_char( extract( minute from s.measurement_date ), '09') ) || ':' ||
          trim( to_char(extract( second from s.measurement_date ), '09') )
       as measurement_time,
       coalesce(cast(s.measurement_source_type_value as int),0)  as measurement_type_concept_id,    -- add to stage table
       coalesce( oper.concept_id, 0 ) as operator_concept_id,
       cast( s.value_as_number as float ) as value_as_number,
       coalesce( val.concept_id, 0 ) as value_as_concept_id,
       coalesce(tarunit.concept_id, 0) as  unit_concept_id,
       s.range_low as range_low,
       s.range_high as range_high,
       pr.provider_id as provider_id,
       v.visit_occurrence_id as visit_occurrence_id,
       s.measurement_source_value as measurement_source_value,
       coalesce( src.concept_id, 0 ) as measurement_source_concept_id,
       s.unit_source_value as unit_source_value,
       s.value_source_value as value_source_value
       , s.id as x_srcid
       , 'STAGE_LAB' as x_srcfile
    from etl.stage_lab s
    join mimic_v5.person p on p.person_source_value = s.person_source_value
    left join mimic_v5.visit_occurrence v on s.visit_source_value = v.visit_source_value
    left join mimic_v5.concept src on s.measurement_source_value = src.concept_code   -- loinc has dashes
        and src.domain_id like '%Meas%'
        and coalesce(s.measurement_source_type, src.vocabulary_id ) = src.vocabulary_id
        and src.invalid_reason is null
    left join mimic_v5.concept_relationship cr on src.concept_id = cr.concept_id_1
        and cr.relationship_id = 'Maps to'
        and cr.invalid_reason is null
    left join mimic_v5.concept tar on cr.concept_id_2 = tar.concept_id
        and tar.standard_concept = 'S'
        and tar.invalid_reason is null
    left join mimic_v5.concept_relationship crv on src.concept_id = crv.concept_id_1
        and crv.relationship_id = 'Maps to value'
        and crv.invalid_reason is null
    left join mimic_v5.concept val on crv.concept_id_2 = val.concept_id
        and val.standard_concept = 'S'
        and val.domain_id = 'Meas Value'
        and val.invalid_reason is null
    left join mimic_v5.concept oper on s.operator_source_value = oper.concept_code
        and oper.domain_id = 'Meas Value Operator'
        and oper.standard_concept = 'S'
        and oper.invalid_reason is null
    left join mimic_v5.concept srcunit on s.unit_source_value = srcunit.concept_code
        and srcunit.domain_id = 'Unit'
        and srcunit.invalid_reason is null
    left join mimic_v5.concept_relationship crunit on srcunit.concept_id = crunit.concept_id_1
        and crunit.relationship_id = 'Maps to'
        and crunit.invalid_reason is null
    left join mimic_v5.concept tarunit on crunit.concept_id_2 = tarunit.concept_id
        and tarunit.standard_concept = 'S'
        and tarunit.invalid_reason is null
    left join mimic_v5.provider pr on s.provider_source_value = pr.provider_source_value
  ) a;


  get diagnostics rowcnt = ROW_COUNT;
  perform etl.logm('GENERIC_OMOP_LOAD', 'insert into measurements', rowcnt );
  perform etl.logm('GENERIC_OMOP_LOAD', 'create measurements', 'FINISH' );


end;
$$;
