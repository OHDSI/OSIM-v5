create function generic_create_person() returns void
LANGUAGE plpgsql
AS $$
declare
        rowcnt  integer;

    begin

        perform etl.logm('GENERIC_OMOP_LOAD', 'generic_create_person' , 'START' );


        INSERT INTO mimic_v5.person
        (
            person_id,
            gender_concept_id,
            year_of_birth,
            month_of_birth,
            day_of_birth,
            time_of_birth,
            race_concept_id,
            ethnicity_concept_id,
            location_id,
            provider_id,
            care_site_id,
            person_source_value,
            gender_source_value,
            gender_source_concept_id,
            race_source_value,
            race_source_concept_id,
            ethnicity_source_value,
            ethnicity_source_concept_id,
            x_srcid,
            x_srcfile
        )
        select
            nextval('mimic_v5.person_id_seq') as person_id,
            case pat.gender
                when 'M' then 8507
                when 'F' then 8532
                when 'A' then 8570
                when 'U' then 8551
                when 'O' then 8521
                when null then null
                else 8551
            end as gender_concept_id,
            extract( year from dob ) as year_of_birth,
            extract( month from dob ) as month_of_birth,
            extract( day from dob ) as day_of_birth,

                trim(to_char(extract( hour from dob ), '09')) || ':' ||
                trim(to_char(extract( minute from dob ), '09')) || ':' ||
                trim(to_char(extract( second from dob ), '09') )
            as time_of_birth,
            case pat.race
                when 'White' then 8527
                when 'Black' then 8516
                when 'Asian' then 8515
                when 'American Indian or Alaska Native' then 8657
                when 'Native Hawaiian or Other Pacific Islander' then 8557
                when 'Other' then 8522
                else 0
            end as race_concept_id,
            case pat.ethnicity
                when 'Hispanic' then 38003563
                else 38003563
            end as ethnicity_concept_id,
            coalesce( loc.location_id, 0 ) as location_id,
            coalesce(prov.provider_id, 0 ) as provider_id,
            coalesce( cs.care_site_id, prov.care_site_id, 0 ) as care_site_id,
            pat.person_source_value as person_source_value,
            pat.gender_source_value  as gender_source_value,
            0 as gender_source_concept_id,
            pat.race_source_value as race_source_value,
            0 as race_source_concept_id,
            pat.ethnicity_source_value as ethnicity_source_value,
            0 as ethnicity_source_concept_id
            , pat.id as x_srcid
            , 'STAGE_PERSON' as x_srcfile
        from etl.stage_person pat
        left join mimic_v5.location loc on pat.location_source_value = loc.location_source_value
        left join mimic_v5.provider prov on pat.provider_source_value  = prov.provider_source_value
        left join mimic_v5.care_site cs on pat.care_site_source_value = cs.care_site_source_value
        ;


          get diagnostics rowcnt = ROW_COUNT;

          perform etl.logm('GENERIC_OMOP_LOAD', 'insert into person' , rowcnt );

          perform etl.logm('GENERIC_OMOP_LOAD', 'generic_create_person' , 'FINISH' );


    end;
$$;
