create function generic_create_procedures() returns void
LANGUAGE plpgsql
AS $$
declare
  rowcnt integer;

begin

-- procedures

-- create sequence mimic_v5.procedure_occurrence_id_seq;

perform etl.logm('GENERIC_OMOP_LOAD', 'create procedure', 'START' );

INSERT INTO mimic_v5.procedure_occurrence
(
	procedure_occurrence_id,
	person_id,
	procedure_concept_id,
	procedure_date,
	procedure_type_concept_id,
	modifier_concept_id,
	quantity,
	provider_id,
	visit_occurrence_id,
	procedure_source_value,
	procedure_source_concept_id,
  qualifier_source_value,
  x_srcid,
  x_srcfile
)
select
    nextval('mimic_v5.procedure_occurrence_id_seq') as procedure_occurrence_id,
	person_id,
	procedure_concept_id,
	procedure_date,
	procedure_type_concept_id,
	modifier_concept_id,
	quantity,
	provider_id,
	visit_occurrence_id,
	procedure_source_value,
	procedure_source_concept_id,
  qualifier_source_value,
  x_srcid,
  x_srcfile
from
(
    select
    	p.person_id as person_id,
    	coalesce( tar.concept_id, src.concept_id, 0 )  as procedure_concept_id,
    	coalesce( s.procedure_date, v.visit_start_date )  as procedure_date,
    	cast(s.procedure_source_type_value as int ) as procedure_type_concept_id,
		  coalesce(mod.concept_id,0) as modifier_concept_id,
      cast(s.quantity as int ) as quantity,
    	v.provider_id as provider_id,
    	v.visit_occurrence_id as visit_occurrence_id,
    	s.procedure_source_value as procedure_source_value,
    	coalesce( src.concept_id, 0 ) as procedure_source_concept_id,
      s.code_modifier as qualifier_source_value
      , s.id as x_srcid
      , 'STAGE_PROCEDURE' as x_srcfile
    from etl.stage_procedure s
    join mimic_v5.person p on p.person_source_value = s.person_source_value
    left join mimic_v5.visit_occurrence v on s.visit_source_value = v.visit_source_value
    left join mimic_v5.concept src on s.procedure_source_value = replace(src.concept_code, '.', '' )
        and src.domain_id like '%Proc%'
        and coalesce(s.procedure_code_source_type, src.vocabulary_id ) = src.vocabulary_id
        and src.invalid_reason is null
    left join mimic_v5.concept_relationship cr on src.concept_id = cr.concept_id_1
        and cr.relationship_id = 'Maps to'
        and cr.invalid_reason is null
    left join mimic_v5.concept tar on cr.concept_id_2 = tar.concept_id
        and tar.standard_concept = 'S'
        and tar.invalid_reason is null
    left join mimic_v5.concept mod on s.code_modifier = mod.concept_code
        and mod.concept_class_id like '%Modifier%'
        and mod.vocabulary_id = src.vocabulary_id
    left join mimic_v5.provider pr on s.provider_source_value = pr.provider_source_value
) a
;

  get diagnostics rowcnt = ROW_COUNT;
  perform etl.logm('GENERIC_OMOP_LOAD', 'insert into procedure', rowcnt );
  perform etl.logm('GENERIC_OMOP_LOAD', 'create procedure', 'FINISH' );


end;
$$;
