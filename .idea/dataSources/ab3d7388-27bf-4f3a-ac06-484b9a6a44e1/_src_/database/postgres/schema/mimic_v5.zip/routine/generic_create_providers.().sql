create function generic_create_providers() returns void
LANGUAGE plpgsql
AS $$
declare
	rowcnt  integer;

begin

    perform etl.logm('GENERIC_OMOP_LOAD', 'generic_create_providers' , 'START' );

    INSERT INTO mimic_v5.provider
    (
        provider_id,
        provider_name,
        NPI,
        DEA,
        specialty_concept_id,
        care_site_id,
        year_of_birth,
        gender_concept_id,
        provider_source_value,
        specialty_source_value,
        specialty_source_concept_id,
        gender_source_value,
        gender_source_concept_id,
        x_srcid,
        x_srcfile
    )
    select
        nextval('mimic_v5.provider_id_seq') as provider_id,
        prov.provider_name as provider_name,
        prov.npi as NPI,
        prov.dea as DEA,
        coalesce( spcon.concept_id, 0 ) as specialty_concept_id,
        coalesce( cs.care_site_id, 0 ) as care_site_id,
        prov.year_of_birth as year_of_birth,
        case prov.gender
            when 'M' then 8507
            when 'F' then 8532
            when 'A' then 8570
            when 'U' then 8551
            when 'O' then 8521
            else 0
        end as gender_concept_id,
        prov.provider_source_value as provider_source_value,  -- may need to manipulate this to get almost unique value ||'_'||npi for example
        prov.specialty_source_value as specialty_source_value,
        44819097 as specialty_source_concept_id,  -- SNOMED concept_id, for example
        prov.gender_source_value as gender_source_value,
        0 as gender_source_concept_id
        , prov.id as x_srcid
        , 'STAGE_PROVIDER' as x_srcfile
    from etl.stage_provider prov
    left join mimic_v5.care_site cs on prov.care_site_source_value = cs.care_site_source_value  -- up to individual implementation
    left join mimic_v5.concept spcon on prov.specialty_source_value = spcon.concept_code
                                                        and spcon.domain_id = 'Provider Specialty'
                                                        and spcon.vocabulary_id = 'SNOMED'  -- there are several vocabularies to choose from depending on how it comes in
    ;



      get diagnostics rowcnt = ROW_COUNT;

      perform etl.logm('GENERIC_OMOP_LOAD', 'insert into provider' , rowcnt );

      perform etl.logm('GENERIC_OMOP_LOAD', 'generic_create_providers' , 'FINISH' );


end;
$$;
