create function generic_create_visits() returns void
LANGUAGE plpgsql
AS $$
declare
        rowcnt  integer;

    begin

         perform etl.logm('GENERIC_OMOP_LOAD', 'generic_create_visits' , 'START' );

            insert into mimic_v5.visit_occurrence
            (
                visit_occurrence_id,
                visit_concept_id,
                visit_source_value,
                visit_type_concept_id,
                visit_start_date,
                visit_start_time,
                visit_end_date,
                visit_end_time,
                care_site_id,
                person_id,
                provider_id,
                x_srcid,
                x_srcfile
            )
            select
                nextval('mimic_v5.VISIT_OCCURRENCE_ID_seq') as visit_occurrence_id
                , case visit_type
                    when 'IP' then 9201
                    when 'OUT' then 9202
                    when 'ER' then 9203
                    when 'LONGTERM' then 42898160
                    else 0
                end as visit_concept_id
                , visit_source_value as visit_source_value
                , case visit_source_type_value
                    when 'CLAIM' then 44818517
                    when 'EHR' then 44818518
                    when 'STUDY' then 44818519
                    else 0
                   end as visit_type_concept_id
                , visit_start_date as visit_start_date
                , trim( to_char( extract( hour from visit_start_date ), '09') ) || ':' ||
                        trim( to_char(extract( minute from visit_start_date ), '09') ) || ':' ||
                        trim( to_char(extract( second from visit_start_date ), '09') )
                     as visit_start_time
                , visit_end_date as visit_end_date
                ,  trim( to_char(extract( hour from visit_end_date ), '09') ) || ':' ||
                       trim( to_char( extract( minute from visit_end_date ), '09') ) || ':' ||
                        trim( to_char(extract( second from visit_end_date ), '09') )
                as visit_end_time
                , coalesce( cs.care_site_id, pr.care_site_id ) as care_site
                , p.person_id as person_id
                , pr.provider_id as provider_id
                , vis.id as x_srcid
                , 'STAGE_VISIT' as x_srcfile
            from etl.stage_visit vis
            join mimic_v5.person p on vis.person_source_value = p.person_source_value
            left join mimic_v5.provider pr on vis.provider_source_value = pr.provider_source_value
            left join mimic_v5.care_site cs on vis.care_site_source_value = cs.care_site_source_value;


          get diagnostics rowcnt = ROW_COUNT;

          perform etl.logm('GENERIC_OMOP_LOAD', 'insert into visit_occurrence' , rowcnt );

          perform etl.logm('GENERIC_OMOP_LOAD', 'generic_create_visits' , 'FINISH' );


    end;
$$;
