create function qa_condition_load() returns void
LANGUAGE plpgsql
AS $$
begin

-- -- 0 = not loaded, 1 = loaded, but not matched concept, 2 = loaded matched source concept, 3 = loaded matched target concept
-- create unique index etl_stage_cond_pk on etl.stage_condition( id );

        perform etl.logm('qa_condition_load', 'process' , 'START' ); 
        
        perform etl.logm('qa_condition_load', 'update from conditions' , 'START' ); 
        
        -- check condition_occurrence
        update etl.stage_condition sc
        set loaded = b.loaded
        from
        (
           select 
              case
                when nullif(condition_concept_id, 0 ) is not null
                  then 3
                when nullif(condition_source_concept_id, 0 ) is not null
                  then 2
                else 1
              end as loaded,
              x_srcid as id
            from mimic_v5.condition_occurrence
            where x_srcfile = 'STAGE_CONDITION'
         ) b
         where sc.id = b.id
         and cast(sc.loaded as int) < b.loaded
         ;

        perform etl.logm('qa_condition_load', 'update from conditions' , 'FINISH' ); 
        
        perform etl.logm('qa_condition_load', 'update from measurements' , 'START' );  
        -- check measurement

        update etl.stage_condition sc
        set loaded = b.loaded
        from
        (
           select 
              case
                when nullif(measurement_concept_id, 0 ) is not null
                  then 3
                when nullif(measurement_source_concept_id, 0 ) is not null
                  then 2
                else 1
              end as loaded,
              x_srcid as id
            from mimic_v5.measurement
            where x_srcfile = 'STAGE_CONDITION'
         ) b
         where sc.id = b.id
         and cast(sc.loaded as int) < b.loaded
         ;
 
        perform etl.logm('qa_condition_load', 'update from measurements' , 'FINISH' ); 
        
        perform etl.logm('qa_condition_load', 'update from observations' , 'START' ); 
                
        -- check observation
        update etl.stage_condition sc
        set loaded = b.loaded
        from
        (
           select 
              case
                when nullif(observation_concept_id, 0 ) is not null
                  then 3
                when nullif(observation_source_concept_id, 0 ) is not null
                  then 2
                else 1
              end as loaded,
              x_srcid as id
            from mimic_v5.observation
            where x_srcfile = 'STAGE_CONDITION'
         ) b
         where sc.id = b.id
         and cast(sc.loaded as int) < b.loaded
         ;
 
        perform etl.logm('qa_condition_load', 'update from observations' , 'FINISH' );  
        
        perform etl.logm('qa_condition_load', 'update from procedures' , 'START' );  
        -- check procedure
        update etl.stage_condition sc
        set loaded = b.loaded
        from
        (
           select 
              case
                when nullif(procedure_concept_id, 0 ) is not null
                  then 3
                when nullif(procedure_source_concept_id, 0 ) is not null
                  then 2
                else 1
              end as loaded,
              x_srcid as id
            from mimic_v5.procedure_occurrence
            where x_srcfile = 'STAGE_CONDITION'
         ) b
         where sc.id = b.id
         and cast(sc.loaded as int) < b.loaded
         ;

        perform etl.logm('qa_condition_load', 'update from procedures' , 'FINISH' );  

        perform etl.logm('qa_condition_load', 'process' , 'FINISH' ); 

    end;
$$;
