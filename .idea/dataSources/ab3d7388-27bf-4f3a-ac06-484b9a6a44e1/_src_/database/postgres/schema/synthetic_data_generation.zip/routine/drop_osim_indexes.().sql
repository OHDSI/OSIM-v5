create function drop_osim_indexes() returns void
LANGUAGE plpgsql
AS $$
DECLARE

  BEGIN
    PERFORM insert_log('Dropping OSIM indexes for quicker insertion',
      'drop_osim_indexes');

    BEGIN
      PERFORM 'DROP INDEX xn_cond_era_concept_id';
      PERFORM 'DROP INDEX xn_cond_era_person_id';
      PERFORM 'DROP INDEX xn_cond_era_start_date';
      PERFORM 'DROP INDEX xn_drug_era_concept_id';
      PERFORM 'DROP INDEX xn_drug_era_person_id';
      PERFORM 'DROP INDEX xn_drug_era_start_date';
    EXCEPTION
      WHEN OTHERS THEN
        PERFORM insert_log('Simulated data indexes are already removed',
            'drop_osim_indexes');
    END;

    PERFORM insert_log('Processing complete', 'drop_osim_indexes');

  END;
$$;
