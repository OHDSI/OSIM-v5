create function ins_drug_count_prob() returns void
LANGUAGE plpgsql
AS $$
DECLARE
    num_rows INTEGER;
    MESSAGE              text;
  BEGIN
    PERFORM insert_log('Starting Drug Concept Count Probability Analysis',
      'ins_drug_count_prob');

    PERFORM 'TRUNCATE TABLE osim_drug_count_prob';

    --COMMIT;
    -- Drop Indexes for Quicker Insertion
    BEGIN
      PERFORM 'DROP INDEX osim_drug_count_prob_ix1';
      PERFORM 'DROP INDEX osim_drug_count_prob_ix2';
    EXCEPTION
      WHEN OTHERS THEN
        PERFORM insert_log('Probability indexes are already removed',
            'ins_drug_count_prob');
    END;

    --COMMIT;

    INSERT /*+ append nologging */ INTO osim_drug_count_prob
    ( gender_concept_id, age_bucket, condition_count_bucket,
      drug_count, n, accumulated_probability )
    SELECT
      gender_concept_id,
      age_bucket,
      condition_count_bucket,
      drug_concepts AS drug_count,
      n,
      SUM(probability)
        OVER
         (PARTITION BY gender_concept_id, age_bucket, condition_count_bucket
          ORDER BY probability DESC
            ROWS UNBOUNDED PRECEDING) accumulated_probability
    FROM
     (SELECT
        gender_concept_id,
        age_bucket,
        condition_count_bucket,
        drug_concepts,
        persons AS n,
        1.0 * persons/ NULLIF(SUM(persons)
                                OVER(PARTITION BY gender_concept_id, age_bucket, condition_count_bucket), 0)
            AS probability
      FROM
       (SELECT
          gender_concept_id,
          age_bucket,
          condition_count_bucket,
          drug_concepts,
          COUNT(person_id) AS persons
        FROM
         (SELECT
            person_id,
            gender_concept_id,
            osim__age_bucket(age) AS age_bucket,
            osim__condition_count_bucket(condition_concepts) AS condition_count_bucket,
            drug_concepts
          FROM v_src_person_strata person) t1
        GROUP BY gender_concept_id, age_bucket, condition_count_bucket, drug_concepts) t2
     ) t3;

    GET DIAGNOSTICS num_rows = ROW_COUNT;
    MESSAGE := num_rows || ' rows inserted into osim_drug_count_prob.';
    PERFORM insert_log(MESSAGE, 'ins_drug_count_prob');
    raise debug 'Inserted ins_drug_count_prob, rows = %', num_rows;

    --COMMIT;

    PERFORM '
    CREATE INDEX osim_drug_count_prob_ix1 ON osim_drug_count_prob (
      gender_concept_id, age_bucket, condition_count_bucket)
    NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
      INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 10 FREELIST GROUPS 10 BUFFER_POOL DEFAULT)';

    PERFORM '
    CREATE INDEX osim_drug_count_prob_ix2
      ON osim_drug_count_prob (accumulated_probability)
    NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
      INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 10 FREELIST GROUPS 10 BUFFER_POOL DEFAULT)';


    --COMMIT;
    -- a few of the last buckets may not quite add up to 1.0
    UPDATE osim_drug_count_prob
    SET accumulated_probability = 1.0
    WHERE oid IN
     (SELECT DISTINCT
        FIRST_VALUE(oid)
          OVER
           (PARTITION BY gender_concept_id, age_bucket, condition_count_bucket
            ORDER BY accumulated_probability DESC)
      FROM osim_drug_count_prob);

     --COMMIT;

    PERFORM insert_log('Processing complete', 'ins_drug_count_prob');
    raise debug 'Processing complete ins_drug_count_prob';

    EXCEPTION
      WHEN OTHERS THEN
      PERFORM insert_log('Exception', 'ins_drug_count_prob');
  END;
$$;
