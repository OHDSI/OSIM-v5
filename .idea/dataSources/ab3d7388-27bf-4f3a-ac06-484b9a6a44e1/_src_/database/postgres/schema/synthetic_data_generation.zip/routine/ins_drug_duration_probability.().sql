create function ins_drug_duration_probability() returns void
LANGUAGE plpgsql
AS $$
DECLARE
    num_rows          INTEGER;
    MESSAGE              text;
  BEGIN
    PERFORM insert_log('Starting Drug Concept Duration Probability Analysis',
      'ins_drug_duration_probability');

    PERFORM 'TRUNCATE TABLE osim_drug_duration_probability';
    --COMMIT;

    -- Drop Indexes for Quicker Insertion
    BEGIN
      PERFORM 'DROP INDEX osim_drug_duration_ix1';
      PERFORM 'DROP INDEX osim_drug_duration_ix2';
    EXCEPTION
      WHEN OTHERS THEN
        PERFORM insert_log('Probability indexes are already removed',
            'ins_drug_duration_probability');
    END;

    --COMMIT;

    INSERT /*+ append nologging */ INTO osim_drug_duration_probability
    (drug_concept_id, time_remaining, drug_era_count, total_exposure,
     total_duration, n, accumulated_probability)
    SELECT
      drug_concept_id,
      time_remaining,
      eras,
      total_exposure,
      total_duration,
      n,
      SUM(probability) OVER
       (PARTITION BY drug_concept_id, time_remaining, eras, total_exposure
        ORDER BY probability DESC ROWS UNBOUNDED PRECEDING) accumulated_probability
    FROM
     (SELECT
        drug_concept_id,
        time_remaining,
        eras,
        total_exposure,
        total_duration,
        COUNT(person_id) AS n,
        1.0 * COUNT(person_id)/ NULLIF(SUM(COUNT(person_id)) OVER(PARTITION BY drug_concept_id, time_remaining, eras, total_exposure), 0)
          AS probability
      FROM
       (SELECT
          person.person_id,
          drug.drug_concept_id,
          osim__time_observed_bucket(person.observation_period_end_date - MIN(drug.drug_era_start_date)) AS time_remaining,
          COUNT(drug.drug_era_id) AS eras,
          osim__round_days(SUM(drug.drug_era_end_date - drug.drug_era_start_date)) AS total_exposure,
          osim__round_days(MAX(drug.drug_era_end_date) - MIN(drug.drug_era_start_date))
            AS total_duration
        FROM v_src_person_strata person
        INNER JOIN v_src_drug_era1 drug
          ON person.person_id = drug.person_id
        GROUP BY person.person_id, drug.drug_concept_id, person.observation_period_end_date) t1
      WHERE eras > 1
      GROUP BY drug_concept_id, time_remaining, eras, total_exposure, total_duration) t2
    ORDER BY 1,2,3,4,7;

    GET DIAGNOSTICS num_rows = ROW_COUNT;
    MESSAGE := num_rows || ' rows inserted into osim_drug_duration_probability.';
    PERFORM insert_log(MESSAGE, 'ins_drug_duration_probability');
    raise debug 'Inserted ins_drug_duration_probability, rows %', num_rows;
    --COMMIT;

    PERFORM '
    CREATE INDEX osim_drug_duration_ix1 ON osim_drug_duration_probability (
      drug_concept_id, time_remaining, drug_era_count, total_exposure)
    NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
      INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 10 FREELIST GROUPS 10 BUFFER_POOL DEFAULT)';

    PERFORM '
    CREATE INDEX osim_drug_duration_ix2 ON osim_drug_duration_probability (
      accumulated_probability)
    NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
      INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 10 FREELIST GROUPS 10 BUFFER_POOL DEFAULT)';

     --COMMIT;

    -- a few of the last buckets may not quite add up to 1.0
    UPDATE osim_drug_duration_probability
    SET accumulated_probability = 1.0
    WHERE oid IN
     (SELECT DISTINCT
        FIRST_VALUE(oid)
          OVER
           (PARTITION BY drug_concept_id, time_remaining,
              drug_era_count, total_exposure
            ORDER BY accumulated_probability DESC)
      FROM osim_drug_duration_probability);

    --COMMIT;

    PERFORM insert_log('Processing complete', 'ins_drug_duration_probability');
    raise debug 'Processing complete ins_drug_duration_probability';

    EXCEPTION
    WHEN OTHERS THEN
    PERFORM insert_log('Exception', 'ins_drug_duration_probability');
    GET STACKED DIAGNOSTICS MESSAGE = PG_EXCEPTION_CONTEXT;
    RAISE NOTICE 'context: >>%<<', MESSAGE;
    raise notice '% %', SQLERRM, SQLSTATE;
  END;
$$;
