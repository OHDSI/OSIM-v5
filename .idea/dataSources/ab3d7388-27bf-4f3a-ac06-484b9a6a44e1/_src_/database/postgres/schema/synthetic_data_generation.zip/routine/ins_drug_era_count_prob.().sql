create function ins_drug_era_count_prob() returns void
LANGUAGE plpgsql
AS $$
DECLARE
    num_rows  INTEGER;
    MESSAGE              text;
  BEGIN
    PERFORM insert_log('Starting Drug Era Count Analysis', 'ins_drug_era_count_prob');
    PERFORM 'TRUNCATE TABLE osim_drug_era_count_prob';

    --COMMIT;
    -- Drop Indexes for Quicker Insertion
    BEGIN
      PERFORM 'DROP INDEX osim_drug_era_count_ix1';
      PERFORM 'DROP INDEX osim_drug_era_count_ix2';
    EXCEPTION
      WHEN OTHERS THEN
        PERFORM insert_log('Probability indexes are already removed',
            'ins_drug_era_count_prob');
    END;

    --COMMIT;

    INSERT /*+ append nologging */ INTO osim_drug_era_count_prob
     (drug_concept_id, drug_count_bucket, condition_count_bucket, age_range,
        time_remaining, drug_era_count, total_exposure, n, accumulated_probability)
    SELECT
      drug_concept_id,
      drugs_bucket,
      conds_bucket,
      age_range,
      time_remaining,
      eras,
      total_exposure,
      n,
      SUM(probability) OVER
       (PARTITION BY drug_concept_id, drugs_bucket, conds_bucket,
        age_range, time_remaining
        ORDER BY probability DESC ROWS UNBOUNDED PRECEDING) accumulated_probability
    FROM
     (SELECT
        drug_concept_id,
        drugs_bucket,
        conds_bucket,
		    age_range,
        time_remaining,
        COUNT(person_id) as persons,
        eras,
        total_exposure,
        COUNT(person_id) AS n,
        1.0 * COUNT(person_id)/ NULLIF(SUM(COUNT(person_id)) OVER(PARTITION BY drug_concept_id, drugs_bucket, conds_bucket,
          age_range, time_remaining), 0) AS probability
      FROM
       (SELECT
          drug.drug_concept_id,
          osim__drug_count_bucket(person.drug_concepts) AS drugs_bucket,
          osim__condition_count_bucket(person.condition_concepts) AS conds_bucket,
		      osim__age_bucket(person.age) AS age_range,
          osim__time_observed_bucket(person.observation_period_end_date
            - MIN(drug.drug_era_start_date)) AS time_remaining,
          COUNT(DISTINCT drug.drug_era_id) AS eras,
          osim__round_days(SUM(drug.drug_era_end_date - drug.drug_era_start_date))
            AS total_exposure,
          person.person_id
        FROM v_src_person_strata person
        INNER JOIN v_src_drug_era1 drug ON person.person_id = drug.person_id
        GROUP BY
          drug.drug_concept_id,
          person.drug_concepts,
          person.condition_concepts,
          person.age,
          person.observation_period_end_date,
          person.person_id) t1
      GROUP BY drug_concept_id, eras, total_exposure, drugs_bucket,
        conds_bucket, age_range, time_remaining) t2
    ORDER BY 1,2,3,4,5,9;

    GET DIAGNOSTICS num_rows = ROW_COUNT;
    MESSAGE := num_rows || ' rows inserted into osim_drug_era_count_prob.';
    PERFORM insert_log(MESSAGE, 'ins_drug_era_count_prob');
    raise debug 'Inserted ins_drug_era_count_prob, rows = %', num_rows;

    --COMMIT;

    PERFORM '
      CREATE INDEX osim_drug_era_count_ix1 ON osim_drug_era_count_prob (
        drug_concept_id,
        drug_count_bucket,
        condition_count_bucket,
		    age_range,
        time_remaining)
      PCTFREE 10 INITRANS 2 MAXTRANS 255 NOLOGGING
      STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 5 FREELIST GROUPS 5 BUFFER_POOL DEFAULT)';

    PERFORM '
      CREATE INDEX osim_drug_era_count_ix2 ON osim_drug_era_count_prob (
        accumulated_probability)
      PCTFREE 10 INITRANS 2 MAXTRANS 255 NOLOGGING
      STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 5 FREELIST GROUPS 5 BUFFER_POOL DEFAULT)';

    --COMMIT;

    UPDATE osim_drug_era_count_prob
    SET accumulated_probability = 1.0
    WHERE oid IN
     (SELECT DISTINCT
        FIRST_VALUE(oid)
          OVER
           (PARTITION BY drug_concept_id, drug_count_bucket, condition_count_bucket,
              age_range, time_remaining
            ORDER BY accumulated_probability DESC)
      FROM osim_drug_era_count_prob);

     --COMMIT;

    PERFORM insert_log('Processing complete', 'ins_drug_era_count_prob');
    raise debug 'Processing complete ins_drug_era_count_prob';
    EXCEPTION
      WHEN OTHERS THEN
      PERFORM insert_log('Exception', 'ins_drug_era_count_prob');
    GET STACKED DIAGNOSTICS MESSAGE = PG_EXCEPTION_CONTEXT;
    RAISE NOTICE 'context: >>%<<', MESSAGE;
    raise notice '% %', SQLERRM, SQLSTATE;
  END;
$$;
