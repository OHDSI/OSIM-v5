create function ins_first_cond_probability() returns void
LANGUAGE plpgsql
AS $$
DECLARE
    num_rows INTEGER;
    MESSAGE              text;
  BEGIN

    PERFORM insert_log('Starting First Condition Concept Probability Analysis', 'ins_first_cond_probability');

    PERFORM 'TRUNCATE TABLE osim_first_cond_probability';
    --COMMIT;

    -- Drop Indexes for Quicker Insertion
    BEGIN
      PERFORM 'DROP INDEX osim_first_cond_ix1';
      PERFORM 'DROP INDEX osim_first_cond_ix2';
    EXCEPTION
      WHEN OTHERS THEN
        PERFORM insert_log('Probability indexes are already removed', 'ins_first_cond_probability');
    END;

    --COMMIT;

    INSERT /*+ append nologging */ INTO osim_first_cond_probability
    (gender_concept_id, age_range, cond_count_bucket,
      time_remaining, condition1_concept_id, condition2_concept_id,
     delta_days, n, accumulated_probability)
      SELECT
        gender_concept_id,
        age_range,
        cond_count_bucket,
        time_remaining,
        condition1_concept_id,
        condition2_concept_id,
        delta_days,
        n,
        SUM(probability)
          OVER
           (PARTITION BY
              gender_concept_id,
              age_range,
              cond_count_bucket,
              condition1_concept_id,
              time_remaining
            ORDER BY probability DESC
              ROWS UNBOUNDED PRECEDING) accumulated_probability
      FROM
       (SELECT
          gender_concept_id,
          age_range,
          cond_count_bucket,
          time_remaining,
          condition1_concept_id,
          condition2_concept_id,
          delta_days,
          condition_count AS n,
          1.0 * condition_count/ NULLIF(SUM(condition_count) OVER
            (PARTITION BY gender_concept_id, age_range, cond_count_bucket,
              condition1_concept_id, time_remaining), 0)
            AS probability
        FROM
         (SELECT
            gender_concept_id,
            age_range,
            cond_count_bucket,
            count(*) as condition_count,
            time_remaining,
            condition1_concept_id,
            condition2_concept_id,
            delta_days
          FROM (SELECT * from OSIM__get_first_cond_transitions()) t1
          GROUP BY
            gender_concept_id,
            age_range,
            cond_count_bucket,
            time_remaining,
            condition1_concept_id,
            delta_days,
            condition2_concept_id) t2
        ORDER BY
          condition1_concept_id,
          delta_days,
          age_range,
          gender_concept_id,
          cond_count_bucket,
          time_remaining,
          condition_count DESC) t3
      ORDER BY 5,2,1,3,8;

    GET DIAGNOSTICS num_rows = ROW_COUNT;
    MESSAGE := num_rows || ' rows inserted into osim_first_cond_probability.';
    PERFORM insert_log(MESSAGE, 'ins_first_cond_probability');
    raise debug 'Inserted ins_first_cond_probability, rows = %', num_rows;

    --COMMIT;

    PERFORM '
      CREATE INDEX osim_first_cond_ix1 ON osim_first_cond_probability (
        condition1_concept_id, age_range, gender_concept_id,
        cond_count_bucket, time_remaining)
      NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
        INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
        PCTINCREASE 0 FREELISTS 5 FREELIST GROUPS 5 BUFFER_POOL DEFAULT)';

    PERFORM '
      CREATE INDEX osim_first_cond_ix2
        ON osim_first_cond_probability (accumulated_probability)
      NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
        INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
        PCTINCREASE 0 FREELISTS 5 FREELIST GROUPS 5 BUFFER_POOL DEFAULT)';

    --COMMIT;

    -- a few of the last buckets may not quite add up to 1.0
    UPDATE osim_first_cond_probability
    SET accumulated_probability = 1.0
    WHERE oid IN
     (SELECT DISTINCT
        FIRST_VALUE(oid)
          OVER
           (PARTITION BY condition1_concept_id, age_range, gender_concept_id,
              cond_count_bucket, time_remaining
            ORDER BY accumulated_probability DESC)
      FROM osim_first_cond_probability);

    --COMMIT;

    PERFORM insert_log('Processing complete', 'ins_first_cond_probability');
    raise debug 'Processing complete ins_first_cond_probability';

  EXCEPTION
    WHEN OTHERS THEN
    PERFORM insert_log('Exception', 'ins_first_cond_probability');
    raise notice '% %', SQLERRM, SQLSTATE;

  END;
$$;
