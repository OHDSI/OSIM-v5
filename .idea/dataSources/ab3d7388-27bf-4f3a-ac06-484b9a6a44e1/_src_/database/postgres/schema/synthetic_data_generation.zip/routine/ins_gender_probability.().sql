create function ins_gender_probability() returns void
LANGUAGE plpgsql
AS $$
DECLARE
    num_rows             INTEGER;
    MESSAGE              TEXT;
  BEGIN
    PERFORM insert_log('Starting Gender Probability Analysis', 'ins_gender_probability');

    PERFORM 'TRUNCATE TABLE osim_gender_probability';
    --COMMIT;
    INSERT /*+ append nologging */ INTO osim_gender_probability
      (gender_concept_id, n, accumulated_probability)
      SELECT
        gender_concept_id,
        n,
        SUM(probability)
            OVER
              (ORDER BY probability DESC
                ROWS UNBOUNDED PRECEDING) accumulated_probability
      FROM
       (SELECT DISTINCT
          gender_concept_id,
          COUNT(*) AS n,
          1.0 * COUNT(*) / NULLIF(SUM(COUNT(*)) OVER(),0) AS probability

        FROM v_src_person_strata strata
        GROUP BY gender_concept_id) t1;
    GET DIAGNOSTICS num_rows = ROW_COUNT;
    MESSAGE := num_rows || ' rows inserted into osim_gender_probability.';
    PERFORM insert_log(MESSAGE, 'ins_gender_probability');
    --COMMIT;
    -- Ensure last accumulated_probability = 1.0
    UPDATE osim_gender_probability
    SET accumulated_probability = 1.0
    WHERE oid IN
     (SELECT DISTINCT
        FIRST_VALUE(oid)
          OVER
           (ORDER BY accumulated_probability DESC)
      FROM osim_gender_probability);
    --COMMIT;
    PERFORM insert_log('Processing complete', 'ins_gender_probability');
    raise debug 'Processing complete ins_gender_probability, rows = %', num_rows;

  EXCEPTION
    WHEN OTHERS THEN
    PERFORM insert_log('Exception', 'ins_gender_probability');
    raise notice '% %', SQLERRM, SQLSTATE;

  END;
$$;
