create function ins_outcomes() returns void
LANGUAGE plpgsql
AS $$
DECLARE
    outcome_cur CURSOR FOR
      SELECT risk_or_benefit, drug_concept_id, condition_concept_id, relative_risk,
        outcome_risk_type, outcome_onset_days_min, outcome_onset_days_max
      FROM osim_drug_outcome;
    tmp_persons_with_drug      INTEGER;
    tmp_drug_eras              INTEGER;
    tmp_persons_with_outcome   INTEGER;
    tmp_current_prevalence     INTEGER;
    tmp_target_rows            INTEGER;
    max_condition_era_id       INTEGER;
    outcomes_insert_count      INTEGER;
    --outcomes_to_remove         TAB_OUTCOME;
    db_cond_era_type_code      VARCHAR(3);
    MESSAGE                    text;
    num_rows          INTEGER;
  BEGIN
    PERFORM insert_log('Starting Outcome Analysis/Creation', 'ins_outcomes');

    SELECT MAX(condition_era_id)
    INTO max_condition_era_id
    FROM osim_condition_era;

--     SELECT condition_occurrence_type
--     INTO db_cond_era_type_code
--     FROM osim_src_db_attributes
--     WHERE ROWNUM = 1;

    FOR outcome_row IN outcome_cur LOOP

      outcomes_insert_count := 0;

      SELECT COUNT(DISTINCT drug.person_id)
      INTO tmp_persons_with_drug
      FROM osim_drug_era drug
      WHERE drug.drug_concept_id = outcome_row.drug_concept_id;

      SELECT COUNT(DISTINCT drug_era_id)
      INTO tmp_drug_eras
      FROM osim_drug_era drug
      WHERE drug.drug_concept_id = outcome_row.drug_concept_id;

      SELECT COUNT(DISTINCT person_id)
      INTO tmp_persons_with_outcome
      FROM osim__get_outcome_drug_eras(outcome_row.drug_concept_id,
                                              outcome_row.condition_concept_id,
                                              outcome_row.outcome_risk_type,
                                              outcome_row.outcome_onset_days_min,
                                              outcome_row.outcome_onset_days_max);

      IF tmp_persons_with_drug > 0 THEN
        tmp_current_prevalence := tmp_persons_with_outcome / tmp_persons_with_drug;
      ELSE
        tmp_current_prevalence := 0.0;
      END IF;

      MESSAGE := 'Processing ' || outcome_row.outcome_risk_type ||
        ' ' || outcome_row.risk_or_benefit ||
        ' outcomes for drug_concept_id=' || outcome_row.drug_concept_id ||
        ', condition_concept_id=' || outcome_row.condition_concept_id || '.' ||
        'outcome_onset_days_min=' || outcome_row.outcome_onset_days_min || '. ' ||
        'outcome_onset_days_max=' || outcome_row.outcome_onset_days_max || '.';
      PERFORM insert_log(MESSAGE, 'ins_outcomes');

      MESSAGE := 'Currently there are: ' || tmp_drug_eras || ' existing drug eras, ' ||
        tmp_persons_with_drug || ' persons with drug, ' ||
        tmp_persons_with_outcome || ' persons already with outcome. ' ||
        'Current Prevalence=' || TO_CHAR(tmp_current_prevalence, '9.99999') || '. ' ||
        'Relative Risk=' || TO_CHAR(outcome_row.relative_risk, '9.99999') || '.';

      PERFORM insert_log(MESSAGE, 'ins_outcomes');

      -- Randomized INTEGER of outcomes to attempt to add (or remove)
      tmp_target_rows :=
        ROUND(((DBMS_RANDOM.NORMAL
        * 0.05 * tmp_persons_with_drug * outcome_row.relative_risk)/1.645)
        + (tmp_persons_with_drug
            * (outcome_row.relative_risk - tmp_current_prevalence)));

      IF tmp_target_rows < 0 AND outcome_row.risk_or_benefit = 'benefit' THEN
      --prevenatative
        tmp_target_rows := -tmp_target_rows;

        INSERT INTO osim_tmp_outcome
          SELECT person_id, drug_era_id, condition_era_id
          FROM
           (SELECT /*+ materialize */ *
            FROM osim__get_outcome_eras(outcome_row.drug_concept_id,
                                              outcome_row.condition_concept_id,
                                              outcome_row.outcome_risk_type,
                                              outcome_row.outcome_onset_days_min,
                                              outcome_row.outcome_onset_days_max)

            ORDER BY random()) t1
          LIMIT tmp_target_rows;

        DELETE FROM osim_condition_era cond
        WHERE EXISTS
          (SELECT 1
           FROM osim_tmp_outcome tmp_outc
           WHERE cond.condition_era_id = tmp_outc.condition_era_id
           AND cond.person_id = tmp_outc.person_id);

        outcomes_insert_count := -num_rows;

        MESSAGE := outcomes_insert_count || ' ' || outcome_row.outcome_risk_type ||
          ' outcomes removed for drug_concept_id=' || outcome_row.drug_concept_id ||
          ', condition_concept_id=' || outcome_row.condition_concept_id || '.';
        PERFORM insert_log(MESSAGE, 'ins_outcomes');

      END IF;

      IF tmp_target_rows >= 0 AND outcome_row.risk_or_benefit = 'risk' THEN

        CASE outcome_row.outcome_risk_type
          WHEN 'first exposure' THEN
          -- add outcome to the risk period for the first drug era per selected person
            INSERT INTO osim_condition_era
             (condition_era_id, condition_era_start_date, condition_era_end_date,
              person_id, condition_concept_id,
              condition_occurrence_count)
            WITH outc AS
             (SELECT /*+ materialize */ *
              FROM osim__get_outcome_drug_eras(outcome_row.drug_concept_id,
                                                outcome_row.condition_concept_id,
                                                outcome_row.outcome_risk_type,
                                                outcome_row.outcome_onset_days_min,
                                                outcome_row.outcome_onset_days_max))
            SELECT
              max_condition_era_id + ROWNUM AS condition_era_id,
              condition_era_start_date,
              condition_era_start_date AS condition_era_end_date,
              person_id,
              outcome_row.condition_concept_id AS condition_concept_id,
--               db_cond_era_type_code,
              1
            FROM
             (SELECT
                person_id,
                drug_era_start_date
                  + ROUND((outcome_row.outcome_onset_days_max
                      - outcome_row.outcome_onset_days_min)
                  * normal_rand(1, 0, 1)) AS condition_era_start_date,
                observation_period_end_date
              FROM
               (SELECT
                  person_id,
                  drug_era_start_date,
                  observation_period_end_date
                FROM
                 (SELECT
                    drug.person_id,
                    MIN(drug.drug_era_start_date) AS drug_era_start_date,
                    obs.observation_period_end_date
                  FROM osim_drug_era drug
                  INNER JOIN osim_observation_period obs
                    ON drug.person_id = obs.person_id
                  LEFT JOIN outc
                    ON drug.drug_era_id = outc.drug_era_id
                  WHERE drug.drug_concept_id = outcome_row.drug_concept_id
                    AND outc.drug_era_id IS NULL
                  GROUP BY drug.person_id, obs.observation_period_end_date
                  ORDER BY random()) t1
                  LIMIT tmp_target_rows) t2
             ) t3
              WHERE condition_era_start_date <= observation_period_end_date;

            outcomes_insert_count := num_rows;

          WHEN 'any exposure' THEN -- add an outcome to risk period per selected person
            INSERT INTO osim_condition_era
             (condition_era_id, condition_era_start_date, condition_era_end_date,
              person_id, condition_concept_id,
              condition_occurrence_count)
            WITH
              outc AS
               (SELECT /*+ materialize */ DISTINCT person_id
                FROM osim__get_outcome_drug_eras(outcome_row.drug_concept_id,
                                                  outcome_row.condition_concept_id,
                                                  outcome_row.outcome_risk_type,
                                                  outcome_row.outcome_onset_days_min,
                                                  outcome_row.outcome_onset_days_max)),
              outcome_draw AS
               (SELECT
                  person_id,
                  drug_concept_id,
                  eras,
                  CEIL(random() * eras) AS outcome_exposure
                FROM
                 (SELECT
                    drug.person_id,
                    drug.drug_concept_id,
                    COUNT(drug.drug_era_id) AS eras
                  FROM osim_drug_era drug
                  LEFT JOIN outc ON drug.person_id = outc.person_id
                  WHERE drug_concept_id = outcome_row.drug_concept_id
                    AND outc.person_id IS NULL
                  GROUP BY drug.person_id, drug.drug_concept_id
                ORDER BY random(), 1) t3
                LIMIT tmp_target_rows)
              SELECT
                max_condition_era_id + ROWNUM AS condition_era_id,
                condition_era_start_date,
                condition_era_start_date AS condition_era_end_date,
                person_id,
                outcome_row.condition_concept_id AS condition_concept_id,
--                 db_cond_era_type_code,
                1
              FROM
              (SELECT
                  person_id,
                  risk_start_date + CEIL(normal_rand(1, 0, 1)
                    * (risk_end_date - risk_start_date)) AS condition_era_start_date
                FROM
                 (SELECT
                    drug.person_id,
                    drug_era_start_date + coalesce(outcome_row.outcome_onset_days_min,0)
                      AS risk_start_date,
                    drug_era_start_date + coalesce(outcome_row.outcome_onset_days_max,0)
                      AS risk_end_date,
                    outcome_draw.outcome_exposure,
                    SUM(1)
                      OVER (PARTITION BY drug.person_id, drug.drug_concept_id
                            ORDER BY drug_era_start_date ROWS UNBOUNDED PRECEDING)
                              AS era_seq
                  FROM outcome_draw
                  INNER JOIN osim_drug_era drug
                    ON outcome_draw.person_id = drug.person_id
                      AND outcome_draw.drug_concept_id = drug.drug_concept_id) t1
                WHERE era_seq = outcome_exposure) t2;

            outcomes_insert_count := num_rows;

          WHEN 'accumulative' THEN -- favor later drug exposures for outcome
            -- Use trianglar matrix to assign probability
            -- Each day at risk will have its own ordinal value INTEGER of chances
            INSERT INTO osim_condition_era
             (condition_era_id, condition_era_start_date, condition_era_end_date,
              person_id, condition_concept_id,
              condition_occurrence_count)
            WITH
              outc AS
               (SELECT /*+ materialize */ DISTINCT person_id
                FROM osim__get_outcome_drug_eras(outcome_row.drug_concept_id,
                                                  outcome_row.condition_concept_id,
                                                  outcome_row.outcome_risk_type,
                                                  outcome_row.outcome_onset_days_min,
                                                  outcome_row.outcome_onset_days_max)),
              outcome_draw AS
               (SELECT
                  person_id,
                  drug_concept_id,
                  eras,
                  exposure_days,
                  (exposure_days * exposure_days + exposure_days) / 2 AS accumulated_risk,
                  -- Quadratic Formula to find exposure day of Outcome
                  -- Each successive day has its ordinal of chances
                  -- The accumulated chances on any day are (n**2 + n) / 2
                  -- To determine the ordinal day of the randomly chosen chance (r):
                  --   a = 1/2, -b = - 1/2, c = -r
                  -- Should this use a gentler accumulation?
                  CEIL(SQRT(0.25+2*CEIL(normal_rand(1, 0, 1)
                    * (exposure_days * exposure_days + exposure_days) / 2))-0.5)
                    + coalesce(outcome_row.outcome_onset_days_min,0) AS outcome_day
                FROM
                 (SELECT
                    drug.person_id,
                    drug.drug_concept_id,
                    COUNT(drug_era_id) AS eras,
                    SUM(ROUND(1 + drug.drug_era_end_date - drug.drug_era_start_date))
                      - coalesce(outcome_row.outcome_onset_days_min,0) AS exposure_days
                  FROM osim_drug_era drug
                  LEFT JOIN outc ON drug.person_id = outc.person_id
                  WHERE drug_concept_id = outcome_row.drug_concept_id
                    AND outc.person_id IS NULL
                  GROUP BY drug.person_id, drug.drug_concept_id
                ORDER BY normal_rand(1, 0, 1), 1) t1
                WHERE exposure_days > 0
                LIMIT tmp_target_rows),
              era_accum AS
               (SELECT
                  drug.person_id,
                  drug.drug_era_id,
                  drug.drug_concept_id,
                  SUM(ROUND(1 + drug.drug_era_end_date - drug.drug_era_start_date))
                    OVER
                     (PARTITION BY person_id, drug_concept_id
                      ORDER BY drug_era_start_date ASC
                        ROWS UNBOUNDED PRECEDING) accum_days
                FROM osim_drug_era drug
                WHERE drug_concept_id = outcome_row.drug_concept_id
                ORDER BY 1)
              SELECT
                max_condition_era_id + ROWNUM AS condition_era_id,
                condition_era_start_date,
                condition_era_start_date AS condition_era_end_date,
                person_id,
                outcome_row.condition_concept_id AS condition_concept_id,
--                 db_cond_era_type_code,
                1
              FROM
               (SELECT DISTINCT
                  outcome_draw.person_id,
                  FIRST_VALUE(drug_era_end_date)
                    OVER (PARTITION BY era_accum.person_id, era_accum.drug_concept_id
                          ORDER BY accum_days) -
                  (FIRST_VALUE(accum_days)
                    OVER (PARTITION BY era_accum.person_id, era_accum.drug_concept_id
                          ORDER BY accum_days) - outcome_draw.outcome_day)
                            AS condition_era_start_date
                FROM outcome_draw
                INNER JOIN era_accum
                  ON outcome_draw.person_id = era_accum.person_id
                  AND outcome_draw.drug_concept_id = era_accum.drug_concept_id
                INNER JOIN osim_drug_era drug
                  ON era_accum.drug_era_id = drug.drug_era_id
                WHERE outcome_day <= accum_days) t4;

            outcomes_insert_count := num_rows;

          WHEN 'insidious' THEN -- random during any exposure
            INSERT INTO osim_condition_era
             (condition_era_id, condition_era_start_date, condition_era_end_date,
              person_id, condition_concept_id,
              condition_occurrence_count)
            WITH
              outc AS
               (SELECT /*+ materialize */ DISTINCT person_id
                FROM osim__get_outcome_drug_eras(outcome_row.drug_concept_id,
                                                  outcome_row.condition_concept_id,
                                                  outcome_row.outcome_risk_type,
                                                  outcome_row.outcome_onset_days_min,
                                                  outcome_row.outcome_onset_days_max)),
              outcome_draw AS
               (SELECT
                  person_id,
                  drug_concept_id,
                  eras,
                  exposure_days,
                  CEIL(normal_rand(1, 0, 1) * exposure_days)
                    + coalesce(outcome_row.outcome_onset_days_min,0) AS outcome_day
                FROM
                 (SELECT
                    drug.person_id,
                    drug.drug_concept_id,
                    COUNT(drug_era_id) AS eras,
                    SUM(ROUND(1 + drug.drug_era_end_date - drug.drug_era_start_date))
                      - coalesce(outcome_row.outcome_onset_days_min,0) AS exposure_days
                  FROM osim_drug_era drug
                  LEFT JOIN outc ON drug.person_id = outc.person_id
                  WHERE drug_concept_id = outcome_row.drug_concept_id
                    AND outc.person_id IS NULL
                  GROUP BY drug.person_id, drug.drug_concept_id
                ORDER BY normal_rand(1, 0, 1), 1) t1
                WHERE exposure_days > 0
                LIMIT tmp_target_rows),
              era_accum AS
               (SELECT
                  drug.person_id,
                  drug.drug_era_id,
                  drug.drug_concept_id,
                  SUM(ROUND(1 + drug.drug_era_end_date - drug.drug_era_start_date))
                    OVER
                     (PARTITION BY person_id, drug_concept_id
                      ORDER BY drug_era_start_date ASC
                        ROWS UNBOUNDED PRECEDING) accum_days
                FROM osim_drug_era drug
                WHERE drug_concept_id = outcome_row.drug_concept_id
                ORDER BY 1)
              SELECT
                max_condition_era_id + ROWNUM AS condition_era_id,
                condition_era_start_date,
                condition_era_start_date AS condition_era_end_date,
                person_id,
                outcome_row.condition_concept_id AS condition_concept_id,
--                 db_cond_era_type_code,
                1
              FROM
               (SELECT DISTINCT
                  outcome_draw.person_id,
                  FIRST_VALUE(drug_era_end_date)
                    OVER (PARTITION BY era_accum.person_id, era_accum.drug_concept_id
                          ORDER BY accum_days) -
                  (FIRST_VALUE(accum_days)
                    OVER (PARTITION BY era_accum.person_id, era_accum.drug_concept_id
                          ORDER BY accum_days) - outcome_draw.outcome_day)
                            AS condition_era_start_date
                FROM outcome_draw
                INNER JOIN era_accum
                  ON outcome_draw.person_id = era_accum.person_id
                  AND outcome_draw.drug_concept_id = era_accum.drug_concept_id
                INNER JOIN osim_drug_era drug
                  ON era_accum.drug_era_id = drug.drug_era_id
                WHERE outcome_day <= accum_days) t2;

            outcomes_insert_count := num_rows;

        END CASE;

        MESSAGE := outcomes_insert_count || ' ' || outcome_row.outcome_risk_type ||
          ' outcomes created for drug_concept_id=' || outcome_row.drug_concept_id ||
          ', condition_concept_id=' || outcome_row.condition_concept_id || '.';
        PERFORM insert_log(MESSAGE, 'ins_outcomes');

      END IF;
      --COMMIT;
    END LOOP;
    
    PERFORM insert_log('Processing complete', 'ins_outcomes');
  EXCEPTION
    WHEN OTHERS THEN
    PERFORM insert_log('Exception', 'ins_outcomes');
  END;
$$;
