create function ins_sim_data(person_count integer DEFAULT 5000, person_start_id integer DEFAULT 0) returns void
LANGUAGE plpgsql
AS $$
DECLARE
    my_sid                        VARCHAR;
    my_start_time                 DATE;
    num_rows                      INTEGER;
    MESSAGE                       TEXT;
    max_persons                   INTEGER;
    db_min_date                   DATE;
    db_max_date                   DATE;
    db_min_year                   INTEGER;
    db_max_year                   INTEGER;

    commit_count_max              INTEGER;
    commit_count                  INTEGER;

    message_count_max             INTEGER;
    message_count                 INTEGER;

    osim_db_persons               INTEGER;

    max_person_id                 INTEGER;
    max_condition_era_id          INTEGER;
    max_drug_era_id               INTEGER;

    person_index                  INTEGER;
    this_gender                   INTEGER;
    this_age                      INTEGER;
    this_age_bucket               INTEGER;
    this_year_of_birth            INTEGER;
    this_person_cond_count        INTEGER;
    this_cond_count_bucket        INTEGER;
    this_obs_days                 INTEGER;
    this_obs_bucket               INTEGER;
    this_obs_start                DATE;

    this_person_begin_date        DATE;
    this_person_end_date          DATE;
    this_era_delta_days           INTEGER;
    tmp_rand                      FLOAT;
    tmp INTEGER;
    drug_persistence              INTEGER;
    cond_persistence              INTEGER;


  BEGIN
    commit_count_max := 10;
    commit_count := 0;

    message_count_max := 1000;
    message_count := 0;

    PERFORM insert_log('Starting to generate simulated data',
        'ins_sim_data');

    PERFORM drop_osim_indexes();

    max_persons := person_count;

    SELECT * from sim_initialization(person_start_id) INTO
    my_sid, my_start_time,
    db_min_date, db_max_date, db_min_year, db_max_year,
    max_person_id, max_condition_era_id, max_drug_era_id,
    osim_db_persons, drug_persistence, cond_persistence;

    -- Create temp tables to store simulation for each person

    DROP TABLE IF EXISTS osim_tmp_outcome;
    CREATE TEMPORARY TABLE osim_tmp_outcome (
      person_id NUMERIC(12, 0) NOT NULL,
      drug_era_id NUMERIC(12, 0) NOT NULL,
      condition_era_id NUMERIC(12, 0) NOT NULL
    ) ON COMMIT DELETE ROWS;


    DROP TABLE IF EXISTS osim_tmp_condition_era;
    CREATE TEMPORARY TABLE osim_tmp_condition_era (
      condition_era_id NUMERIC(15, 0) NOT NULL,
      condition_era_start_date DATE,
      person_id NUMERIC(12, 0) NOT NULL,
      confidence NUMERIC,
      condition_era_end_date DATE,
      condition_concept_id NUMERIC(15, 0),
      condition_occurrence_count NUMERIC(5, 0)
    ) ON COMMIT DELETE ROWS;

    DROP TABLE IF EXISTS osim_tmp_drug_era;
    CREATE TEMPORARY TABLE osim_tmp_drug_era (
      drug_era_start_date DATE,
      drug_era_end_date DATE,
      person_id NUMERIC(12, 0) NOT NULL,
      drug_concept_id NUMERIC(15, 0),
      drug_exposure_count NUMERIC(5, 0)
    ) ON COMMIT DELETE ROWS;

    -- Start the simulation
    person_index := 1;
    WHILE person_index <= max_persons
    LOOP
      --
      -- Create osim person
      --
      SELECT * FROM ins_sim_person(db_min_year, max_person_id) INTO max_person_id,
        this_gender, this_age, this_age_bucket, this_year_of_birth;

      --
      -- Create Observation Period
      --
      SELECT * FROM ins_sim_observation_period(max_person_id, this_gender, this_age,
        db_min_date, db_max_date, this_year_of_birth) INTO
        this_year_of_birth, this_person_cond_count, this_cond_count_bucket,
        this_obs_bucket, this_obs_days, this_person_begin_date, this_person_end_date;

      --
      -- Simulate Conditions
      --

      SELECT * FROM ins_sim_conditions (max_person_id, this_person_begin_date,
      this_age, this_gender, this_obs_days, this_person_cond_count, max_condition_era_id,this_cond_count_bucket)
      INTO this_person_cond_count, max_condition_era_id, this_cond_count_bucket;

      --
      -- Simulate Drugs
      --   Drugs are simulated from the person's conditions
      PERFORM ins_sim_drugs(max_person_id, this_person_begin_date,
        this_person_end_date, this_gender, this_cond_count_bucket, this_age,
        this_age_bucket, drug_persistence);

      --
      -- Copy Eras from Temp Tables
      --
      -- insert conditions
      INSERT INTO osim_condition_era
       (condition_era_id, condition_era_start_date, condition_era_end_date,
        person_id, condition_concept_id,
        condition_occurrence_count)
      SELECT
        condition_era_id, condition_era_start_date, condition_era_end_date,
        person_id, condition_concept_id,
        condition_occurrence_count
      FROM osim_tmp_condition_era
      WHERE person_id = max_person_id;

      -- insert conditions
      INSERT INTO osim_drug_era
       (drug_era_id, drug_era_start_date, drug_era_end_date, person_id,
       drug_concept_id, drug_exposure_count)
      SELECT
        max_drug_era_id + coalesce(row_number() OVER (ORDER BY person_id), 0) AS drug_era_id,
        drug_era_start_date, drug_era_end_date, person_id,
        drug_concept_id, drug_exposure_count
      FROM osim_tmp_drug_era
      WHERE person_id = max_person_id;

      GET DIAGNOSTICS num_rows = ROW_COUNT;
      max_drug_era_id := max_drug_era_id + num_rows;

      --COMMIT;
      --Report progress every 1%
      IF FLOOR(person_index/(0.01*person_count)) < FLOOR((person_index+1)/(0.01*person_count)) THEN
        PERFORM insert_log('SID=' || my_sid || ': ' || to_char(person_index+1, '999999') || ' persons completed(' ||
          FLOOR((person_index+1)/(0.01*person_count)) || '%).',
          'ins_sim_data');
      END IF;

      person_index := person_index + 1;
      TRUNCATE TABLE osim_tmp_condition_era;
      TRUNCATE TABLE osim_tmp_drug_era;
      TRUNCATE TABLE osim_tmp_outcome;

    END LOOP;

    person_index := person_index - 1;
    --COMMIT;
    PERFORM insert_log('Processing complete.  ' || person_index
                     || ' persons created.', 'ins_sim_data');
  EXCEPTION
    WHEN OTHERS THEN
    PERFORM insert_log('Exception', 'ins_sim_data');
    DISCARD TEMP; --delete all temp tables if commit doesn't happen
    GET STACKED DIAGNOSTICS MESSAGE = PG_EXCEPTION_CONTEXT;
    RAISE NOTICE 'context: >>%<<', MESSAGE;
    raise notice '% %', SQLERRM, SQLSTATE;
  END;
$$;
