create function ins_time_obs_probability() returns void
LANGUAGE plpgsql
AS $$
DECLARE
    num_rows INTEGER;
    MESSAGE     text;
  BEGIN
    PERFORM insert_log('Starting Observed Years Probability Analysis', 'ins_time_obs_probability');

    PERFORM 'TRUNCATE TABLE osim_time_obs_probability';
    --COMMIT;

    INSERT /*+ append nologging */ INTO osim_time_obs_probability
      SELECT
        gender_concept_id,
        age_at_obs,
        cond_count_bucket,
        semi_years_obs,
        n,
        SUM(probability) OVER
         (PARTITION BY gender_concept_id, age_at_obs, cond_count_bucket
          ORDER BY probability DESC ROWS UNBOUNDED PRECEDING) accumulated_probability
      FROM
       (SELECT DISTINCT
          strata.gender_concept_id,
          strata.age AS age_at_obs,
          strata.cond_count_bucket,
          strata.semi_years_obs,
          COUNT(strata.person_id) AS n,
          1.0 * COUNT(strata.person_id)/ NULLIF(SUM(COUNT(strata.person_id)) OVER(PARTITION BY strata.gender_concept_id, strata.age,
              strata.cond_count_bucket), 0) AS probability
        FROM
         (SELECT
            person_id,
            gender_concept_id,
            age,
            OSIM__condition_count_bucket(condition_concepts) AS cond_count_bucket,
            OSIM__time_observed_bucket(obs_duration_days) AS semi_years_obs
          FROM v_src_person_strata) strata
        GROUP BY strata.gender_concept_id, strata.age,
            strata.cond_count_bucket, strata.semi_years_obs) t1
      ORDER BY 1,2,3,6;
    GET DIAGNOSTICS num_rows = ROW_COUNT;
    MESSAGE := num_rows || ' rows inserted into osim_years_obs_probability.';
    PERFORM insert_log(MESSAGE, 'ins_time_obs_probability');
    raise debug 'Inserted ins_time_obs_probability, rows = %', num_rows;

    --COMMIT;

    UPDATE osim_time_obs_probability
    SET accumulated_probability = 1.0
    WHERE oid IN
     (SELECT DISTINCT
        FIRST_VALUE(oid)
          OVER
           (PARTITION BY gender_concept_id, age_at_obs, cond_count_bucket
            ORDER BY accumulated_probability DESC)
      FROM osim_time_obs_probability);

    --COMMIT;

    PERFORM insert_log('Processing complete', 'ins_time_obs_probability');
    raise debug 'Processing complete ins_time_obs_probability';

  EXCEPTION
    WHEN OTHERS THEN
    PERFORM insert_log('Exception', 'ins_time_obs_probability');
    raise notice '% %', SQLERRM, SQLSTATE;
  END;
$$;
