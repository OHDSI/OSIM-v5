create function osim__age_bucket(numeric) returns integer
LANGUAGE plpgsql
AS $$
DECLARE age ALIAS FOR $1;
  BEGIN
    CASE TRUE
      WHEN age IS NULL THEN RETURN NULL;
      WHEN age < 6 THEN RETURN 6;
      WHEN age < 14 THEN RETURN 14;
      WHEN age < 20 THEN RETURN 20;
      WHEN age < 55 THEN RETURN 55;
      WHEN age < 70 THEN RETURN 70;
      ELSE RETURN 120;
    END CASE;
  END;
$$;
