create function osim__condition_count_bucket(bigint) returns integer
LANGUAGE plpgsql
AS $$
DECLARE condition_count ALIAS FOR $1;
  BEGIN
    CASE TRUE
      WHEN condition_count <= 2 THEN RETURN 2;
      WHEN condition_count <= 7 THEN RETURN 7;
      WHEN condition_count <= 25 THEN RETURN 25;
      ELSE RETURN 2000;
    END CASE;
  END;
$$;
