create function osim__min_num(integer, integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
    value1 ALIAS FOR $1;
    value2 ALIAS FOR $2;
  BEGIN
    RETURN CASE WHEN value1 <= value2 THEN value1 ELSE value2 END;
  END;
$$;
