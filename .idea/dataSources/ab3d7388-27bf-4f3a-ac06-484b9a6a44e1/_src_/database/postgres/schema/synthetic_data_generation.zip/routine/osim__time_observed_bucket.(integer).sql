create function osim__time_observed_bucket(integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE days ALIAS FOR $1;
  BEGIN
    CASE TRUE
      WHEN days > 0 THEN RETURN FLOOR((1+days) / 182.625);
      ELSE RETURN 0;
    END CASE;
  END;
$$;
