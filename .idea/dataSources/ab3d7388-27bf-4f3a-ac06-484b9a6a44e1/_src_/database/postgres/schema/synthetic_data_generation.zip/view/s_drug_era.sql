CREATE VIEW s_drug_era AS SELECT drug_era.drug_era_id,
    drug_era.person_id,
    drug_era.drug_concept_id,
    drug_era.drug_era_start_date,
    drug_era.drug_era_end_date,
    drug_era.drug_exposure_count,
    drug_era.gap_days
   FROM synpuf5.drug_era;
