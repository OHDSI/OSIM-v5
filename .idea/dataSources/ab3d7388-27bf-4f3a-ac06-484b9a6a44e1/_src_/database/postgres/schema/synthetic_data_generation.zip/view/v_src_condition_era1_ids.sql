CREATE VIEW v_src_condition_era1_ids AS SELECT DISTINCT cond.condition_era_id AS condition_occurrence_id,
    cond.condition_occurrence_count
   FROM (synthetic_data_generation.s_condition_era cond
     JOIN synthetic_data_generation.v_src_person person ON ((cond.person_id = person.person_id)));
