create function comp_qa_condition_load(p_loadid integer) returns void
LANGUAGE plpgsql
AS $$
declare 
    rowcnt integer;
    v_loadid  integer;
    logmsg varchar(200); 

  begin

-- -- 0 = not loaded, 1 = loaded, but not matched concept, 2 = loaded matched source concept, 3 = loaded matched target concept

        v_loadid := p_loadid;

        perform etl.logm('qa_condition_load', 'process loadid '||v_loadid , 'START' ); 
        
/*
        -- copy records that did not make it over to error
        insert into etl.stage_condition_error
        (
          id,
          condition_code_source_type,
          condition_source_value,
          condition_source_type_value,
          start_date,
          end_date,
          stop_reason,
          visit_source_value,
          person_source_value,
          provider_source_value,
          load_id,
          loaded
        )
        select s.id,
          condition_code_source_type,
          condition_source_value,
          condition_source_type_value,
          start_date,
          end_date,
          stop_reason,
          visit_source_value,
          person_source_value,
          provider_source_value,
          s.load_id,
          s.loaded
        from etl.stage_condition_temp s
        left join etl.qa_stage_condition q on s.id = q.id and s.load_id = q.load_id
        where q.id is null
        and s.load_id = v_loadid;

        get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_condition_load', 'Error records moved to etl.stage_condition_error: ' , rowcnt );

        -- remove unmapped records that were mapped in other tables
        -- postgres performance improvement
	--  "qastcond_idx" btree (load_id, id)
	-- "cot_srcload_idx" btree (x_srcloadid, x_srcid, x_srcfile)
        delete from omop.condition_occurrence_temp co
        using etl.qa_stage_condition sl
        where co.condition_source_concept_id = 0
        and co.x_srcfile = 'STAGE_CONDITION'
        and co.x_srcid = sl.id
	and co.x_srcloadid = sl.load_id
        and co.x_srcloadid = v_loadid
        and sl.loaded <> 1
        ;

        --  generic subselect method for other DBs.
        -- delete from omop.condition_occurrence_temp co
        -- where co.x_srcid in
        -- (
            -- select id
            -- from etl.stage_condition_temp c
            -- join omop.condition_occurrence_temp co2 on ( c.id = co2.x_srcid and c.load_id = x_srcloadid )
            -- where c.loaded >1
            -- and co2.condition_source_concept_id = 0
            -- and x_srcfile = 'STAGE_CONDITION'
            -- and c.load_id = v_loadid
        -- )
        -- and co.x_srcfile = 'STAGE_CONDITION'
        -- and co.x_srcloadid = v_loadid
        -- ;

        get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_condition_load', 'unmapped records removed that were mapped in other tables: ' , rowcnt );

*/
        -- move to etl stage permanent home
        insert into etl.stage_condition
        (
          id,
          condition_code_source_type,
          condition_source_value,
          condition_source_type_value,
          start_date,
          end_date,
          stop_reason,
          visit_source_value,
          person_source_value,
          provider_source_value,
          load_id,
          loaded
        )
        select sct.id,
          condition_code_source_type,
          condition_source_value,
          condition_source_type_value,
          start_date,
          end_date,
          stop_reason,
          visit_source_value,
          person_source_value,
          provider_source_value,
          sct.load_id,
          qsc.loaded
        from etl.stage_condition_temp sct
		join
		(
			select max(loaded) as loaded, id, load_id
			from etl.qa_stage_condition 
			where load_id = v_loadid
			group by id, load_id
		) qsc on sct.id = qsc.id and sct.load_id = qsc.load_id
        where sct.load_id = v_loadid;

        get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_condition_load', 'moved from etl.stage_condition_temp to permanent: ' , rowcnt );

-- commented out for testing.
        -- delete from etl.stage_condition_temp where load_id = v_loadid;

        -- get diagnostics rowcnt = ROW_COUNT;
        -- perform etl.logm('qa_condition_load', 'deleted from etl.stage_condition_temp: ' , rowcnt );

        perform etl.logm('qa_condition_load', 'process' , 'FINISH' ); 

    end;
$$;
