create function qa_procedure_load(p_loadid integer) returns void
LANGUAGE plpgsql
AS $$
declare
    v_loadid integer;
    rowcnt   integer;
    logmsg   varchar(200);

  begin

-- -- 0 = not loaded, 1 = loaded, but not matched concept, 2 = loaded matched source concept,
--  3 = loaded matched target concept
-- create unique index etl_stage_cond_pk on etl.stage_procedure( id );

    v_loadid := p_loadid;

    perform etl.logm('qa_procedure_load', 'process loadid: '||v_loadid , 'START' ); 
/*

    drop index if exists etl.etl_stage_proc_id;
    create index etl_stage_proc_id on etl.stage_procedure_temp( load_id, id );

    perform etl.logm('qa_procedure_load', 'create stage_proc index' , 'finish' ); 
    

    -- create new table for qa

    drop table if exists etl.qa_stage_procedure;
    create table etl.qa_stage_procedure
    (
      id bigint,
      load_id int,
      loaded int
    );



        -- check procedure_occurrence
        insert into etl.qa_stage_procedure 
        ( id, load_id, loaded )
        select 
            pot.x_srcid as id,
            pot.x_srcloadid as loadid,
            case
              when nullif(pot.procedure_concept_id, 0 ) is not null
                then 3
              when nullif(pot.procedure_source_concept_id, 0 ) is not null
                then 2
              else 1
            end as loaded
        from omop.procedure_occurrence_temp pot
        join etl.stage_procedure_temp spt on pot.x_srcid = spt.id and spt.load_id = pot.x_srcloadid
        where pot.x_srcfile = 'STAGE_PROCEDURE'
        and pot.x_srcloadid = v_loadid
        ;


        get diagnostics rowcnt = ROW_COUNT;

        perform etl.logm('qa_procedure_load', 'update from procedures: ' , rowcnt ); 
        perform etl.logm('qa_procedure_load', 'update from procedures' , 'FINISH' ); 
        
        perform etl.logm('qa_procedure_load', 'update from measurements' , 'START' );  
        -- check measurement


        insert into etl.qa_stage_procedure 
        ( id, load_id, loaded )
        select 
            pot.x_srcid as id,
            pot.x_srcloadid as loadid,
            case
              when nullif(measurement_concept_id, 0 ) is not null
                  then 3
              when nullif(measurement_source_concept_id, 0 ) is not null
                then 2
              else 1
            end as loaded
        from omop.measurement_temp pot
        join etl.stage_procedure_temp spt on pot.x_srcid = spt.id and spt.load_id = pot.x_srcloadid
        where pot.x_srcfile = 'STAGE_PROCEDURE'
        and pot.x_srcloadid = v_loadid
        ;

        get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_procedure_load', 'update from measurements: ' , rowcnt ); 
        perform etl.logm('qa_procedure_load', 'update from measurements' , 'FINISH' ); 
        
        perform etl.logm('qa_procedure_load', 'update from observations' , 'START' ); 
                
        -- check observation
        insert into etl.qa_stage_procedure 
        ( id, load_id, loaded )
        select 
            pot.x_srcid as id,
            pot.x_srcloadid as loadid,
            case
              when nullif(observation_concept_id, 0 ) is not null
                  then 3
              when nullif(observation_source_concept_id, 0 ) is not null
                then 2
              else 1
            end as loaded
        from omop.observation_temp pot
        join etl.stage_procedure_temp spt on pot.x_srcid = spt.id and spt.load_id = pot.x_srcloadid
        where pot.x_srcfile = 'STAGE_PROCEDURE'
        and pot.x_srcloadid = v_loadid
        ; 
        get diagnostics rowcnt = ROW_COUNT;

        perform etl.logm('qa_procedure_load', 'update from observations: ' , rowcnt);  
        perform etl.logm('qa_procedure_load', 'update from observations' , 'FINISH' );  
        
        perform etl.logm('qa_procedure_load', 'update from condition' , 'START' );  
        
        -- check condition
        insert into etl.qa_stage_procedure 
        ( id, load_id, loaded )
        select 
            pot.x_srcid as id,
            pot.x_srcloadid as loadid,
            case
              when nullif(condition_concept_id, 0 ) is not null
                  then 3
              when nullif(condition_source_concept_id, 0 ) is not null
                then 2
              else 1
            end as loaded
        from omop.condition_occurrence_temp pot
        join etl.stage_procedure_temp spt on pot.x_srcid = spt.id and spt.load_id = pot.x_srcloadid
        where pot.x_srcfile = 'STAGE_PROCEDURE'
        and pot.x_srcloadid = v_loadid
        ;         

        get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_procedure_load', 'update from condition: ' , rowcnt );  
        perform etl.logm('qa_procedure_load', 'update from condition' , 'FINISH' );  

        perform etl.logm('qa_procedure_load', 'update from drug_exposure' , 'START' );

        -- check drug exposure
        insert into etl.qa_stage_procedure 
        ( id, load_id, loaded )
        select 
            pot.x_srcid as id,
            pot.x_srcloadid as loadid,
            case
              when nullif(drug_concept_id, 0 ) is not null
                  then 3
              when nullif(drug_source_concept_id, 0 ) is not null
                then 2
              else 1
            end as loaded
        from omop.drug_exposure_temp pot
        join etl.stage_procedure_temp spt on pot.x_srcid = spt.id and spt.load_id = pot.x_srcloadid
        where pot.x_srcfile = 'STAGE_PROCEDURE'
        and pot.x_srcloadid = v_loadid
        ;

        get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_procedure_load', 'update from drug_exposure: ' , rowcnt );
        perform etl.logm('qa_procedure_load', 'update from drug_exposure' , 'FINISH' );

		    perform etl.logm('qa_procedure_load', 'update from device_exposure' , 'START' );

        -- check device exposure
        insert into etl.qa_stage_procedure 
        ( id, load_id, loaded )
        select 
            pot.x_srcid as id,
            pot.x_srcloadid as loadid,
            case
              when nullif(device_concept_id, 0 ) is not null
                  then 3
              when nullif(device_source_concept_id, 0 ) is not null
                then 2
              else 1
            end as loaded
        from omop.device_exposure_temp pot
        join etl.stage_procedure_temp spt on pot.x_srcid = spt.id and spt.load_id = pot.x_srcloadid
        where pot.x_srcfile = 'STAGE_PROCEDURE'
        and pot.x_srcloadid = v_loadid
        ;

        get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_procedure_load', 'update from device_exposure: ' , rowcnt );
        perform etl.logm('qa_procedure_load', 'update from device_exposure' , 'FINISH' );

*/
-- create index for qa_stage_procedure
        drop index if exists etl.qastproc_idx;
        create index qastproc_idx on etl.qa_stage_procedure( load_id, id, loaded );

        select 'Loadid: '||v_loadid||', loaded = 3:' || count(*) into logmsg
        from 
        (
          select max(loaded) as loaded, id, load_id 
          from etl.qa_stage_procedure 
          where load_id = v_loadid
          group by id, load_id
        ) a
        where loaded = 3
        ;
        perform etl.logm('qa_procedure_load', 'QA check count: ' , logmsg );

        select 'Loadid: '||v_loadid||', loaded = 2:' || count(*) into logmsg
        from 
        (
          select max(loaded) as loaded, id, load_id 
          from etl.qa_stage_procedure 
          where load_id = v_loadid
          group by id, load_id
        ) a
        where loaded = 2
        ;
        perform etl.logm('qa_procedure_load', 'QA check count: ' , logmsg );

        select 'Loadid: '||v_loadid||', loaded = 1:' || count(*) into logmsg
        from 
        (
          select max(loaded) as loaded, id, load_id 
          from etl.qa_stage_procedure 
          where load_id = v_loadid
          group by id, load_id
        ) a
        where loaded = 1
        ;
        perform etl.logm('qa_procedure_load', 'QA check count: ' , logmsg );


    -- copy records that did not make it over to error
    insert into etl.stage_procedure_error
    (
        id,
        procedure_code_source_type,
        procedure_source_value,
        procedure_source_type_value,
        code_modifier,
        procedure_date,
        quantity,
        stop_reason,
        total_charge,
        total_cost,
        total_paid,
        paid_by_payer,
        paid_by_patient,
        paid_patient_copay,
        paid_patient_coinsurance,
        paid_patient_deductible,
        paid_by_primary,
        visit_source_value,
        person_source_value,
        provider_source_value,
        load_id,
        loaded
    )
    select
      spt.id,
      procedure_code_source_type,
      procedure_source_value,
      procedure_source_type_value,
      code_modifier,
      procedure_date,
      quantity,
      stop_reason,
      total_charge,
      total_cost,
      total_paid,
      paid_by_payer,
      paid_by_patient,
      paid_patient_copay,
      paid_patient_coinsurance,
      paid_patient_deductible,
      paid_by_primary,
      visit_source_value,
      person_source_value,
      provider_source_value,
      spt.load_id,
      spt.loaded
    from etl.stage_procedure_temp spt
    left join etl.qa_stage_procedure qsc on spt.id = qsc.id and spt.load_id = qsc.load_id
    where qsc.id is null 
    and spt.load_id = v_loadid;

    get diagnostics rowcnt = ROW_COUNT;
    perform etl.logm('qa_procedure_load', 'Error records moved to etl.stage_condition_error: ' , rowcnt );

    -- remove unmapped records that were mapped in other tables
    -- postgres performance improvement
    -- "pot_srcload_idx" btree (x_srcloadid, x_srcid, x_srcfile)
    -- qastproc_idx ( load_id, id );
    
drop table if exists etl.procedure_occurrence_delete;
create table etl.procedure_occurrence_delete
(
    x_srcloadid integer,
    x_srcid bigint,
    x_srcfile varchar(20)
);

    insert into etl.procedure_occurrence_delete
    ( x_srcloadid, x_srcid, x_srcfile )
    select
            x_srcloadid, x_srcid, x_srcfile
        from omop.procedure_occurrence_temp co
        join etl.qa_stage_procedure sl on co.x_srcid = sl.id
                                  and co.x_srcloadid = sl.load_id
        where co.procedure_source_concept_id = 0
        and co.x_srcloadid = v_loadid
        and co.x_srcfile = 'STAGE_PROCEDURE'
        and sl.loaded <> 1;

    get diagnostics rowcnt = ROW_COUNT;
    perform etl.logm('qa_procedure_load', 'unmapped records that were mapped in other tables: ' , rowcnt );

         perform etl.logm('qa_procedure_load', 'index created on etl.procedure_occurrence_delete ' , 'FINISH' );         
         create index podel_idx on etl.procedure_occurrence_delete( x_srcloadid, x_srcid, x_srcfile );
         perform etl.logm('qa_procedure_load', 'index created on etl.procedure_occurrence_delete ' , 'FINISH' );
         /*
    -- move to etl stage permanent home
   insert into etl.stage_procedure
    (
        id,
        procedure_code_source_type,
        procedure_source_value,
        procedure_source_type_value,
        code_modifier,
        procedure_date,
        quantity,
        stop_reason,
        total_charge,
        total_cost,
        total_paid,
        paid_by_payer,
        paid_by_patient,
        paid_patient_copay,
        paid_patient_coinsurance,
        paid_patient_deductible,
        paid_by_primary,
        visit_source_value,
        person_source_value,
        provider_source_value,
        load_id,
        loaded
    )
    select
      sct.id,
      procedure_code_source_type,
      procedure_source_value,
      procedure_source_type_value,
      code_modifier,
      procedure_date,
      quantity,
      stop_reason,
      total_charge,
      total_cost,
      total_paid,
      paid_by_payer,
      paid_by_patient,
      paid_patient_copay,
      paid_patient_coinsurance,
      paid_patient_deductible,
      paid_by_primary,
      visit_source_value,
      person_source_value,
      provider_source_value,
      sct.load_id,
      qsc.loaded
    from etl.stage_procedure_temp sct
    join
    ( select max(loaded) as loaded, id, load_id 
        from etl.qa_stage_procedure 
        where load_id = v_loadid
        group by id, load_id
    ) qsc on sct.id = qsc.id and sct.load_id = qsc.load_id
    where sct.load_id = v_loadid;

    get diagnostics rowcnt = ROW_COUNT;
    perform etl.logm('qa_procedure_load', 'moved from etl.stage_procedure_temp to permanent: ' , rowcnt );

    -- commented out for testing
    -- delete from etl.stage_procedure_temp where load_id = v_loadid;

    get diagnostics rowcnt = ROW_COUNT;
    perform etl.logm('qa_procedure_load', 'deleted from etl.stage_procedure_temp: ' , rowcnt );
*/
    perform etl.logm('qa_procedure_load3', 'process' , 'FINISH' ); 

  end;
$$;
