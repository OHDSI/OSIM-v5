create function qa_procedure_load1(p_loadid integer) returns void
LANGUAGE plpgsql
AS $$
declare
    v_loadid integer;
    rowcnt   integer;
    logmsg   varchar(200);

  begin

-- -- 0 = not loaded, 1 = loaded, but not matched concept, 2 = loaded matched source concept,
--  3 = loaded matched target concept
-- create unique index etl_stage_cond_pk on etl.stage_procedure( id );

    v_loadid := p_loadid;

    perform etl.logm('qa_procedure_load', 'process loadid: '||v_loadid , 'START' ); 

    drop index if exists etl.etl_stage_proc_id;
    create index etl_stage_proc_id on etl.stage_procedure_temp( id, load_id );

    perform etl.logm('qa_procedure_load', 'update from procedures' , 'START' ); 
    

    -- create new table for qa

-- for testing
    update etl.load_info
    set status = 1 
    where load_id = v_loadid;

    select count(*) into rowcnt
    from etl.load_info
    where load_id = v_loadid
    and status = 1;

    if rowcnt <> 1 then
      raise exception 'previous process did not complete';
    end if;

-- end testing

    create table etl.qa_stage_procedure
    (
      id bigint,
      load_id int,
      loaded int
    );



        -- check procedure_occurrence
        insert into etl.qa_stage_procedure 
        ( id, load_id, loaded )
        select 
            pot.x_srcid as id,
            pot.x_srcloadid as loadid,
            case
              when nullif(pot.procedure_concept_id, 0 ) is not null
                then 3
              when nullif(pot.procedure_source_concept_id, 0 ) is not null
                then 2
              else 1
            end as loaded
        from omop.procedure_occurrence_temp pot
        join etl.stage_procedure_temp spt on pot.x_srcid = spt.id and spt.load_id = pot.x_srcloadid
        where pot.x_srcfile = 'STAGE_PROCEDURE'
        and pot.x_srcloadid = v_loadid
        ;


        get diagnostics rowcnt = ROW_COUNT;

        perform etl.logm('qa_procedure_load', 'update from procedures: ' , rowcnt ); 
        perform etl.logm('qa_procedure_load', 'update from procedures' , 'FINISH' ); 
        
        perform etl.logm('qa_procedure_load', 'update from measurements' , 'START' );  
        -- check measurement


        insert into etl.qa_stage_procedure 
        ( id, load_id, loaded )
        select 
            pot.x_srcid as id,
            pot.x_srcloadid as loadid,
            case
              when nullif(measurement_concept_id, 0 ) is not null
                  then 3
              when nullif(measurement_source_concept_id, 0 ) is not null
                then 2
              else 1
            end as loaded
        from omop.measurement_temp pot
        join etl.stage_procedure_temp spt on pot.x_srcid = spt.id and spt.load_id = pot.x_srcloadid
        where pot.x_srcfile = 'STAGE_PROCEDURE'
        and pot.x_srcloadid = v_loadid
        ;

        get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_procedure_load', 'update from measurements: ' , rowcnt ); 
        perform etl.logm('qa_procedure_load', 'update from measurements' , 'FINISH' ); 
        
        perform etl.logm('qa_procedure_load', 'update from observations' , 'START' ); 
                
        -- check observation
        insert into etl.qa_stage_procedure 
        ( id, load_id, loaded )
        select 
            pot.x_srcid as id,
            pot.x_srcloadid as loadid,
            case
              when nullif(observation_concept_id, 0 ) is not null
                  then 3
              when nullif(observation_source_concept_id, 0 ) is not null
                then 2
              else 1
            end as loaded
        from omop.observation_temp pot
        join etl.stage_procedure_temp spt on pot.x_srcid = spt.id and spt.load_id = pot.x_srcloadid
        where pot.x_srcfile = 'STAGE_PROCEDURE'
        and pot.x_srcloadid = v_loadid
        ; 
        get diagnostics rowcnt = ROW_COUNT;

        perform etl.logm('qa_procedure_load', 'update from observations: ' , rowcnt);  
        perform etl.logm('qa_procedure_load', 'update from observations' , 'FINISH' );  
        
        perform etl.logm('qa_procedure_load', 'update from condition' , 'START' );  
        
        -- check condition
        insert into etl.qa_stage_procedure 
        ( id, load_id, loaded )
        select 
            pot.x_srcid as id,
            pot.x_srcloadid as loadid,
            case
              when nullif(condition_concept_id, 0 ) is not null
                  then 3
              when nullif(condition_source_concept_id, 0 ) is not null
                then 2
              else 1
            end as loaded
        from omop.condition_occurrence_temp pot
        join etl.stage_procedure_temp spt on pot.x_srcid = spt.id and spt.load_id = pot.x_srcloadid
        where pot.x_srcfile = 'STAGE_PROCEDURE'
        and pot.x_srcloadid = v_loadid
        ;         

        get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_procedure_load', 'update from condition: ' , rowcnt );  
        perform etl.logm('qa_procedure_load', 'update from condition' , 'FINISH' );  

        perform etl.logm('qa_procedure_load', 'update from drug_exposure' , 'START' );

        -- check drug exposure
        insert into etl.qa_stage_procedure 
        ( id, load_id, loaded )
        select 
            pot.x_srcid as id,
            pot.x_srcloadid as loadid,
            case
              when nullif(drug_concept_id, 0 ) is not null
                  then 3
              when nullif(drug_source_concept_id, 0 ) is not null
                then 2
              else 1
            end as loaded
        from omop.drug_exposure_temp pot
        join etl.stage_procedure_temp spt on pot.x_srcid = spt.id and spt.load_id = pot.x_srcloadid
        where pot.x_srcfile = 'STAGE_PROCEDURE'
        and pot.x_srcloadid = v_loadid
        ;

        get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_procedure_load', 'update from drug_exposure: ' , rowcnt );
        perform etl.logm('qa_procedure_load', 'update from drug_exposure' , 'FINISH' );

		    perform etl.logm('qa_procedure_load', 'update from device_exposure' , 'START' );

        -- check device exposure
        insert into etl.qa_stage_procedure 
        ( id, load_id, loaded )
        select 
            pot.x_srcid as id,
            pot.x_srcloadid as loadid,
            case
              when nullif(device_concept_id, 0 ) is not null
                  then 3
              when nullif(device_source_concept_id, 0 ) is not null
                then 2
              else 1
            end as loaded
        from omop.device_exposure_temp pot
        join etl.stage_procedure_temp spt on pot.x_srcid = spt.id and spt.load_id = pot.x_srcloadid
        where pot.x_srcfile = 'STAGE_PROCEDURE'
        and pot.x_srcloadid = v_loadid
        ;

        get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_procedure_load', 'update from device_exposure: ' , rowcnt );
        perform etl.logm('qa_procedure_load', 'update from device_exposure' , 'FINISH' );

-- create index for qa_stage_procedure
        drop index if exists qastproc_idx;
        create index qastproc_idx on etl.qa_stage_procedure( load_id, id );

        select 'Loadid: '||v_loadid||', loaded = 3:' || count(*) into logmsg
        from 
        (
          select max(loaded) as loaded, id, load_id 
          from etl.qa_stage_procedure 
          where load_id = v_loadid
          group by id, load_id
        ) a
        where loaded = 3
        ;
        perform etl.logm('qa_procedure_load', 'QA check count: ' , logmsg );

        select 'Loadid: '||v_loadid||', loaded = 2:' || count(*) into logmsg
        from 
        (
          select max(loaded) as loaded, id, load_id 
          from etl.qa_stage_procedure 
          where load_id = v_loadid
          group by id, load_id
        ) a
        where loaded = 2
        ;
        perform etl.logm('qa_procedure_load', 'QA check count: ' , logmsg );

        select 'Loadid: '||v_loadid||', loaded = 1:' || count(*) into logmsg
        from 
        (
          select max(loaded) as loaded, id, load_id 
          from etl.qa_stage_procedure 
          where load_id = v_loadid
          group by id, load_id
        ) a
        where loaded = 1
        ;
        perform etl.logm('qa_procedure_load', 'QA check count: ' , logmsg );


    perform etl.logm('qa_procedure_load1', 'process' , 'FINISH' ); 

  end;
$$;
