create function qa_procedure_load3(p_loadid integer) returns void
LANGUAGE plpgsql
AS $$
declare
    v_loadid integer;
    rowcnt   integer;
    logmsg   varchar(200);

  begin

-- -- 0 = not loaded, 1 = loaded, but not matched concept, 2 = loaded matched source concept,
--  3 = loaded matched target concept
-- create unique index etl_stage_cond_pk on etl.stage_procedure( id );

    v_loadid := p_loadid;

    perform etl.logm('qa_procedure_load3', 'process loadid: '||v_loadid , 'START' );

    select count(*) into rowcnt
    from etl.load_info
    where load_id = v_loadid
    and status = 1;

    if rowcnt <> 1 then
      raise exception 'previous process did not complete';
    end if;


    -- move to etl stage permanent home
   insert into etl.stage_procedure
    (
        id,
        procedure_code_source_type,
        procedure_source_value,
        procedure_source_type_value,
        code_modifier,
        procedure_date,
        quantity,
        stop_reason,
        total_charge,
        total_cost,
        total_paid,
        paid_by_payer,
        paid_by_patient,
        paid_patient_copay,
        paid_patient_coinsurance,
        paid_patient_deductible,
        paid_by_primary,
        visit_source_value,
        person_source_value,
        provider_source_value,
        load_id,
        loaded
    )
    select
      sct.id,
      procedure_code_source_type,
      procedure_source_value,
      procedure_source_type_value,
      code_modifier,
      procedure_date,
      quantity,
      stop_reason,
      total_charge,
      total_cost,
      total_paid,
      paid_by_payer,
      paid_by_patient,
      paid_patient_copay,
      paid_patient_coinsurance,
      paid_patient_deductible,
      paid_by_primary,
      visit_source_value,
      person_source_value,
      provider_source_value,
      sct.load_id,
      qsc.loaded
    from etl.stage_procedure_temp sct
    join
    ( select max(loaded) as loaded, id, load_id 
        from etl.qa_stage_procedure 
        where load_id = v_loadid
        group by id, load_id
    ) qsc on sct.id = qsc.id and sct.load_id = qsc.load_id
    where sct.load_id = v_loadid;

    get diagnostics rowcnt = ROW_COUNT;
    perform etl.logm('qa_procedure_load', 'moved from etl.stage_procedure_temp to permanent: ' , rowcnt );

    -- commented out for testing
    -- delete from etl.stage_procedure_temp where load_id = v_loadid;

    get diagnostics rowcnt = ROW_COUNT;
    perform etl.logm('qa_procedure_load', 'deleted from etl.stage_procedure_temp: ' , rowcnt );

    perform etl.logm('qa_procedure_load3', 'process' , 'FINISH' ); 

  end;
$$;
