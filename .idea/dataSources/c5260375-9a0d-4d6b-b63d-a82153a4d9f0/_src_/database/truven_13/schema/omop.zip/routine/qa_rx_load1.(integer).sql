create function qa_rx_load1(p_loadid integer) returns void
LANGUAGE plpgsql
AS $$
declare
	rowcnt integer;
    v_loadid integer;
    logmsg varchar(200);

  begin

-- -- 0 = not loaded, 1 = loaded, but not matched concept, 2 = loaded matched source concept, 3 = loaded matched target concept
-- create unique index etl_stage_cond_pk on etl.stage_rx( id );


        
        v_loadid := p_loadid;
        perform etl.logm('qa_rx_load1', 'process loadid:'||v_loadid , 'START' ); 
 
create table IF NOT EXISTS etl.loadstatus
(
  load_id int,
  type varchar(25),
  status int
);
       
        insert into etl.loadstatus
          ( load_id, type, status)
        values
          ( v_loadid, 'rx', -1 );

        drop index if exists etl.etl_stage_rx_id;
        create index etl_stage_rx_id on etl.stage_rx_temp( id, load_id );
        
        perform etl.logm('qa_rx_load1', 'update from procedures' , 'START' ); 
        

create table IF NOT EXISTS etl.qa_stage_rx
(
  id bigint,
  load_id int,
  loaded int
);
        
        -- check procedure_occurrence

insert into etl.qa_stage_rx 
( id, load_id, loaded )
select 
  cot.x_srcid as id,
  cot.x_srcloadid as load_id, 
              case
                when nullif(procedure_concept_id, 0 ) is not null
                  then 3
                when nullif(procedure_source_concept_id, 0 ) is not null
                  then 2
                else 1
              end as loaded
from omop.procedure_occurrence_temp cot
join etl.stage_rx_temp srt on cot.x_srcid = srt.id and srt.load_id = cot.x_srcloadid
where cot.x_srcfile = 'STAGE_RX'
and cot.x_srcloadid = v_loadid
         ;

		get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_rx_load', 'update from procedures: ' , rowcnt ); 
        perform etl.logm('qa_rx_load', 'update from procedures' , 'FINISH' ); 
        
        perform etl.logm('qa_rx_load', 'update from measurements' , 'START' );  
        -- check measurement

insert into etl.qa_stage_rx 
( id, load_id, loaded )
select 
  cot.x_srcid as id,
  cot.x_srcloadid as load_id, 
              case
                when nullif(measurement_concept_id, 0 ) is not null
                  then 3
                when nullif(measurement_source_concept_id, 0 ) is not null
                  then 2
                else 1
              end as loaded
from omop.measurement_temp cot
join etl.stage_rx_temp srt on cot.x_srcid = srt.id and srt.load_id = cot.x_srcloadid
where cot.x_srcfile = 'STAGE_RX'
and cot.x_srcloadid = v_loadid
         ;

 
		get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_rx_load', 'update from measurements: ' , rowcnt ); 
        perform etl.logm('qa_rx_load', 'update from measurements' , 'FINISH' ); 
        
        perform etl.logm('qa_rx_load', 'update from observations' , 'START' ); 
                
        -- check observation

insert into etl.qa_stage_rx 
( id, load_id, loaded )
select 
  cot.x_srcid as id,
  cot.x_srcloadid as load_id, 
              case
                when nullif(observation_concept_id, 0 ) is not null
                  then 3
                when nullif(observation_source_concept_id, 0 ) is not null
                  then 2
                else 1
              end as loaded
from omop.observation_temp cot
join etl.stage_rx_temp srt on cot.x_srcid = srt.id and srt.load_id = cot.x_srcloadid
where cot.x_srcfile = 'STAGE_RX'
and cot.x_srcloadid = v_loadid
         ;

 
		get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_rx_load', 'update from observations' , 'FINISH' );  
        
        perform etl.logm('qa_rx_load', 'update from condition' , 'START' );  
 
        -- check condition
insert into etl.qa_stage_rx 
( id, load_id, loaded )
select 
  cot.x_srcid as id,
  cot.x_srcloadid as load_id, 
              case
                when nullif(condition_concept_id, 0 ) is not null
                  then 3
                when nullif(condition_source_concept_id, 0 ) is not null
                  then 2
                else 1
              end as loaded
from omop.condition_occurrence_temp cot
join etl.stage_rx_temp srt on cot.x_srcid = srt.id and srt.load_id = cot.x_srcloadid
where cot.x_srcfile = 'STAGE_RX'
and cot.x_srcloadid = v_loadid
         ;


		get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_rx_load', 'update from condition: ' , rowcnt );  
        perform etl.logm('qa_rx_load', 'update from condition' , 'FINISH' );  

        perform etl.logm('qa_rx_load', 'update from rx' , 'START' );  

        -- check rx
insert into etl.qa_stage_rx 
( id, load_id, loaded )
select 
  cot.x_srcid as id,
  cot.x_srcloadid as load_id, 
              case
                when nullif(cot.drug_concept_id, 0 ) is not null
                  then 3
                when nullif(cot.drug_source_concept_id, 0 ) is not null
                  then 2
                else 1
              end as loaded
from omop.drug_exposure_temp cot
join etl.stage_rx_temp srt on cot.x_srcid = srt.id and srt.load_id = cot.x_srcloadid
where cot.x_srcfile = 'STAGE_RX'
and cot.x_srcloadid = v_loadid
         ;


		get diagnostics rowcnt = ROW_COUNT;
        perform etl.logm('qa_rx_load', 'update from rx: ' , rowcnt );  
        perform etl.logm('qa_rx_load', 'update from rx' , 'FINISH' );  
        
        perform etl.logm('qa_rx_load', 'update from device' , 'START' );

        -- check device
insert into etl.qa_stage_rx 
( id, load_id, loaded )
select 
  cot.x_srcid as id,
  cot.x_srcloadid as load_id, 
              case
                when nullif(cot.device_concept_id, 0 ) is not null
                  then 3
                when nullif(cot.device_source_concept_id, 0 ) is not null
                  then 2
                else 1
              end as loaded
from omop.device_exposure_temp cot
join etl.stage_rx_temp srt on cot.x_srcid = srt.id and srt.load_id = cot.x_srcloadid
where cot.x_srcfile = 'STAGE_RX'
and cot.x_srcloadid = v_loadid
         ;


		get diagnostics rowcnt = ROW_COUNt;
        perform etl.logm('qa_rx_load', 'update from device: ' , rowcnt );
        perform etl.logm('qa_rx_load', 'update from device' , 'FINISH' );


    perform etl.logm('qa_rx_load', 'update from device_exposure' , 'FINISH' );
    perform etl.logm('qa_rx_load1', 'process' , 'FINISH' ); 
        
        update etl.loadstatus
        set status = 1
        where load_id = v_loadid
        and type = 'rx';

  end;
$$;
