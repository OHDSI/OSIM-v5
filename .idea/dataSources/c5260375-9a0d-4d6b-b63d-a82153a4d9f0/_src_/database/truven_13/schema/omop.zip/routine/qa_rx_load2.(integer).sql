create function qa_rx_load2(p_loadid integer) returns void
LANGUAGE plpgsql
AS $$
declare
  rowcnt integer;
    v_loadid integer;
    logmsg varchar(200);

  begin

    v_loadid := p_loadid;

    perform etl.logm('qa_rx_load2', 'process loadid: '||v_loadid , 'START' );
    
    select count(*) into rowcnt
    from etl.loadstatus
    where load_id = v_loadid
    and status = 1
    and type = 'rx';

    if rowcnt <> 1 then
      perform etl.logm('qa_rx_load2', 'status check returns error: '||v_loadid , 'ERROR' );
      raise exception 'previous process did not complete';
    end if;

        update etl.loadstatus
        set status = 3
        where load_id = v_loadid
        and type = 'rx';

-- create index for qa_stage_procedure
        drop index if exists qastrx_idx;
        create index qastrx_idx on etl.qa_stage_rx( load_id, id );

    select 'Loadid: '||v_loadid||', loaded = 3:' || count(*) into logmsg
    from 
    (
      select max(loaded) as loaded, id, load_id 
      from etl.qa_stage_rx 
      where load_id = v_loadid
      group by id, load_id
    ) a
    where loaded = 3
    ;

    perform etl.logm('qa_rx_load', 'QA check count: ' , logmsg );

    select 'Loadid: '||v_loadid||', loaded = 3:' || count(*) into logmsg
    from 
    (
      select max(loaded) as loaded, id, load_id 
      from etl.qa_stage_rx 
      where load_id = v_loadid
      group by id, load_id
    ) a
    where loaded = 2;
    perform etl.logm('qa_rx_load', 'QA check count: ' , logmsg );

    select 'Loadid: '||v_loadid||', loaded = 3:' || count(*) into logmsg
    from 
    (
      select max(loaded) as loaded, id, load_id 
      from etl.qa_stage_rx 
      where load_id = v_loadid
      group by id, load_id
    ) a
    where  loaded = 1;
    perform etl.logm('qa_rx_load', 'QA check count: ' , logmsg );


    -- copy records that did not make it over to error

    insert into etl.stage_rx_error
    (
        id,
        drug_source_type,
        drug_source_value,
        drug_source_type_value,
        drug_start_date,
        drug_end_date,
        stop_reason,
        refills,
        quantity,
        days_supply,
        dose_unit_source_value,
        effective_drug_dose,
        total_charge,
        total_cost,
        total_paid,
        paid_by_payer,
        paid_by_patient,
        paid_patient_copay,
        paid_patient_coinsurance,
        paid_patient_deductible,
        paid_by_primary,
        paid_ingredient_cost,
        pait_dispensing_fee,
        route_source_value,
        visit_source_value,
        person_source_value,
        provider_source_value,
        load_id,
        loaded
    )
   select
      srt.id,
      drug_source_type,
      drug_source_value,
      drug_source_type_value,
      drug_start_date,
      drug_end_date,
      stop_reason,
      refills,
      quantity,
      days_supply,
      dose_unit_source_value,
      effective_drug_dose,
      total_charge,
      total_cost,
      total_paid,
      paid_by_payer,
      paid_by_patient,
      paid_patient_copay,
      paid_patient_coinsurance,
      paid_patient_deductible,
      paid_by_primary,
      paid_ingredient_cost,
      pait_dispensing_fee,
      route_source_value,
      visit_source_value,
      person_source_value,
      provider_source_value,
      srt.load_id,
      srt.loaded
    from etl.stage_rx_temp  srt
       left join etl.qa_stage_rx qsr on srt.id = qsr.id and srt.load_id = qsr.load_id
       where qsr.id is null  -- there is no record in the etl.qa_stage file, so nothing matched to load it
       and srt.load_id =  v_loadid;

    get diagnostics rowcnt = ROW_COUNT;
    perform etl.logm('qa_rx_load', 'Error records moved to etl.stage_rx_error: ' , rowcnt );

    -- remove unmapped records that were mapped in other tables
        -- postgres performance improvement
        
        delete from omop.drug_exposure_temp co
        using etl.qa_stage_rx sl
        where co.drug_source_concept_id = 0
        and co.x_srcfile = 'STAGE_RX'
        and co.x_srcid = sl.id
        and co.x_srcloadid = sl.load_id
        and co.x_srcloadid = v_loadid
        and sl.loaded <> 1
        ;
        /*  generic subselect method for other DBs.

    delete from omop.drug_exposure_temp de
    where de.x_srcid in
    (
        select id
        from etl.stage_rx_temp rx
        join omop.drug_exposure_temp de2 on ( rx.id = de2.x_srcid and rx.load_id = de2.x_srcloadid )
        where rx.loaded >1
        and de2.drug_source_concept_id = 0
        and de2.x_srcfile = 'STAGE_RX'
        and rx.load_id = v_loadid
    )
    and de.x_srcfile = 'STAGE_RX'
    and de.x_srcloadid = v_loadid
    ;
*/

    get diagnostics rowcnt = ROW_COUNT;
    perform etl.logm('qa_rx_load2', 'unmapped records removed that were mapped in other tables: ' , rowcnt );
    
        update etl.loadstatus
        set status = 3
        where load_id = v_loadid
        and type = 'rx';

    perform etl.logm('qa_rx_load2', 'process' , 'FINISH' ); 

  end;
$$;
