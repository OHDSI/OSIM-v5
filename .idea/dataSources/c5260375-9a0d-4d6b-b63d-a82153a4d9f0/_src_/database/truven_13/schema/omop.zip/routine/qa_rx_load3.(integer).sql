create function qa_rx_load3(p_loadid integer) returns void
LANGUAGE plpgsql
AS $$
declare
  rowcnt integer;
    v_loadid integer;
    logmsg varchar(200);

  begin

    v_loadid := p_loadid;

    perform etl.logm('qa_rx_load3', 'process loadid: '||v_loadid , 'START' );

    select count(*) into rowcnt
    from etl.loadstatus
    where load_id = v_loadid
    and status = 3
    and type = 'rx';

    if rowcnt <> 1 then
      perform etl.logm('qa_rx_load3', 'status check returns error: '||v_loadid , 'ERROR' );
      raise exception 'previous process did not complete';
    end if;

        update etl.loadstatus
        set status = 4
        where load_id = v_loadid
        and type = 'rx';

    -- move to etl stage permanent home
    insert into etl.stage_rx
    (
        id,
        drug_source_type,
        drug_source_value,
        drug_source_type_value,
        drug_start_date,
        drug_end_date,
        stop_reason,
        refills,
        quantity,
        days_supply,
        dose_unit_source_value,
        effective_drug_dose,
        total_charge,
        total_cost,
        total_paid,
        paid_by_payer,
        paid_by_patient,
        paid_patient_copay,
        paid_patient_coinsurance,
        paid_patient_deductible,
        paid_by_primary,
        paid_ingredient_cost,
        pait_dispensing_fee,
        route_source_value,
        visit_source_value,
        person_source_value,
        provider_source_value,
        load_id,
        loaded
    )
    select
      srt.id,
      drug_source_type,
      drug_source_value,
      drug_source_type_value,
      drug_start_date,
      drug_end_date,
      stop_reason,
      refills,
      quantity,
      days_supply,
      dose_unit_source_value,
      effective_drug_dose,
      total_charge,
      total_cost,
      total_paid,
      paid_by_payer,
      paid_by_patient,
      paid_patient_copay,
      paid_patient_coinsurance,
      paid_patient_deductible,
      paid_by_primary,
      paid_ingredient_cost,
      pait_dispensing_fee,
      route_source_value,
      visit_source_value,
      person_source_value,
      provider_source_value,
      srt.load_id,
      qsr.loaded
     from etl.stage_rx_temp srt
        join -- only add records that are in etl.qa_stage
        ( select max(loaded) as loaded, id, load_id 
            from etl.qa_stage_rx 
            where load_id = v_loadid
            group by id, load_id
        ) qsr on srt.id = qsr.id and srt.load_id = qsr.load_id
        where srt.load_id = v_loadid;

-- removed for testinh
    -- delete from etl.stage_rx_temp
    -- where load_id = v_loadid;

    get diagnostics rowcnt = ROW_COUNT;
    perform etl.logm('qa_rx_load', 'moved from etl.stage_rx_temp to permanent: ' , rowcnt );

-- removed for testinh
    -- delete from etl.stage_rx_temp
    -- where load_id = v_loadid;

    get diagnostics rowcnt = ROW_COUNT;
    perform etl.logm('qa_rx_load', 'deleted from etl.stage_rx_temp: ' , rowcnt );

        update etl.loadstatus
        set status = 4
        where load_id = v_loadid
        and type = 'rx';
    perform etl.logm('qa_rx_load3', 'process' , 'FINISH' ); 

  end;
$$;
