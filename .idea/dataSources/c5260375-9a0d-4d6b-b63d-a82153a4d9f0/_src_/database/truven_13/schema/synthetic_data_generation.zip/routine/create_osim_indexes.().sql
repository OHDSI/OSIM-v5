create function create_osim_indexes() returns void
LANGUAGE plpgsql
AS $$
DECLARE
  BEGIN
    PERFORM insert_log('Creating OSIM indexes for quicker selection',
      'create_osim_indexes');

    BEGIN
      PERFORM '
      CREATE INDEX xn_cond_era_concept_id
        ON osim_condition_era (condition_concept_id ASC)
      NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
      INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 5 FREELIST GROUPS 5 BUFFER_POOL DEFAULT)';

      PERFORM '
      CREATE INDEX xn_cond_era_person_id ON osim_condition_era (person_id ASC)
      NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
      INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 5 FREELIST GROUPS 5 BUFFER_POOL DEFAULT)';

      PERFORM '
      CREATE INDEX xn_cond_era_start_date
        ON osim_condition_era (condition_era_start_date ASC)
      NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
      INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 5 FREELIST GROUPS 5 BUFFER_POOL DEFAULT)';

      PERFORM '
      CREATE INDEX xn_drug_era_concept_id ON osim_drug_era (drug_concept_id ASC)
      NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
      INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 5 FREELIST GROUPS 5 BUFFER_POOL DEFAULT)';

      PERFORM '
      CREATE INDEX xn_drug_era_person_id ON osim_drug_era (person_id ASC)
      NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
      INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 5 FREELIST GROUPS 5 BUFFER_POOL DEFAULT)';

      PERFORM '
      CREATE INDEX xn_drug_era_start_date ON osim_drug_era (drug_era_start_date ASC)
      NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
      INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 5 FREELIST GROUPS 5 BUFFER_POOL DEFAULT)';
    EXCEPTION
      WHEN OTHERS THEN
        PERFORM insert_log('Simulated data indexes already exist',
            'create_osim_indexes');
    END;

    PERFORM insert_log('Processing complete', 'create_osim_indexes');
  END;
$$;
