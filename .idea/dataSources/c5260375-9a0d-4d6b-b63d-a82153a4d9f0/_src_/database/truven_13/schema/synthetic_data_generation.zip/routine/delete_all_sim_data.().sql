create function delete_all_sim_data() returns void
LANGUAGE plpgsql
AS $$
DECLARE
  BEGIN
    PERFORM insert_log('Deleting all simulate data', 'delete_all_sim_data');

    TRUNCATE TABLE osim_person CASCADE;
    TRUNCATE TABLE osim_observation_period CASCADE;
    TRUNCATE TABLE osim_condition_era CASCADE;
    TRUNCATE TABLE osim_drug_era CASCADE;
    --COMMIT;


    PERFORM insert_log('Processing complete', 'delete_all_sim_data');
  EXCEPTION
    WHEN OTHERS THEN
    PERFORM insert_log('Exception', 'delete_all_sim_data');
END;
$$;
