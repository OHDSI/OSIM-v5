create function ins_cond_count_probability() returns void
LANGUAGE plpgsql
AS $$
DECLARE
    num_rows INTEGER;
    MESSAGE              text;
  BEGIN
    PERFORM insert_log('Starting Condition Concept Count Probability Analysis', 'ins_cond_count_probability');

    PERFORM 'TRUNCATE TABLE osim_cond_count_probability';
    --COMMIT;

    INSERT /*+ append nologging */ INTO osim_cond_count_probability
      SELECT
        gender_concept_id,
        age_at_obs,
        NULL AS cond_era_count,
        cond_count AS cond_concept_count,
        n,
        SUM(probability) OVER
         (PARTITION BY gender_concept_id, age_at_obs
          ORDER BY probability DESC ROWS UNBOUNDED PRECEDING) accumulated_probability
      FROM
       (SELECT DISTINCT
          strata.gender_concept_id,
          strata.age AS age_at_obs,
          strata.condition_concepts AS cond_count,
          COUNT(strata.person_id) AS n,
          1.0 * COUNT(strata.person_id)/ NULLIF(SUM(COUNT(strata.person_id)) OVER(PARTITION BY strata.gender_concept_id, strata.age),0) AS probability
        FROM v_src_person_strata strata
        GROUP BY strata.gender_concept_id, strata.age, strata.condition_concepts) t1
      ORDER BY 1,2,6;

    GET DIAGNOSTICS num_rows = ROW_COUNT;
    MESSAGE := num_rows || ' rows inserted into osim_cond_count_probability.';
    PERFORM insert_log(MESSAGE, 'ins_cond_count_probability');

    --COMMIT;

    UPDATE osim_cond_count_probability
    SET accumulated_probability = 1.0
    WHERE oid IN
     (SELECT DISTINCT
        FIRST_VALUE(oid)
          OVER
           (PARTITION BY gender_concept_id, age_at_obs
            ORDER BY accumulated_probability DESC)
      FROM osim_cond_count_probability);

  --COMMIT;

  PERFORM insert_log('Processing complete', 'ins_cond_count_probability');

  EXCEPTION
    WHEN OTHERS THEN
    PERFORM insert_log('Exception', 'ins_cond_count_probability');
    raise notice '% %', SQLERRM, SQLSTATE;

  END;
$$;
