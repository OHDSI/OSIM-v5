create function ins_cond_first_drug_prob() returns void
LANGUAGE plpgsql
AS $$
DECLARE
    num_rows INTEGER;
    MESSAGE              text;
  BEGIN
    PERFORM insert_log('Starting Condition Interval Drug Era Analysis',
      'ins_cond_first_drug_prob');

    PERFORM 'TRUNCATE TABLE osim_cond_first_drug_prob';

    --COMMIT;
    -- Drop Indexes for Quicker Insertion
    BEGIN
      PERFORM 'DROP INDEX osim_cond_drug_prob_ix1';
      PERFORM 'DROP INDEX osim_cond_drug_prob_ix2';
    EXCEPTION
      WHEN OTHERS THEN
        PERFORM insert_log('Probability indexes are already removed',
            'ins_cond_first_drug_prob');
    END;

    --COMMIT;

    INSERT /*+ append nologging */ INTO osim_cond_first_drug_prob
    (  condition_concept_id, interval_bucket, gender_concept_id, age_bucket,
        condition_count_bucket, drug_count_bucket, day_cond_count, drug_concept_id,
        delta_days, n, accumulated_probability )
    WITH gaps AS
     (SELECT
       cond_gaps.person_id,
       cond_gaps.gender_concept_id,
       cond_gaps.age_bucket,
       cond_gaps.condition_count_bucket,
       cond_gaps.drug_count_bucket,
       cond_gaps.cond_start_date,
       cond_gaps.next_cond_start_date,
       cond_gaps.day_cond_count,
       coalesce(COUNT(DISTINCT drug.drug_concept_id),0) AS drug_era_count
      FROM
       (SELECT
          cond_dates.person_id,
          person.gender_concept_id,
          osim__age_bucket(
            person.age + (cond_dates.condition_era_start_date
              - person.observation_period_start_date)
              / 365.25) AS age_bucket,
          osim__condition_count_bucket(person.condition_concepts)
            AS condition_count_bucket,
          osim__drug_count_bucket(person.drug_concepts) AS drug_count_bucket,
          cond_dates.condition_era_start_date AS cond_start_date,
          LEAD (cond_dates.condition_era_start_date,1,person.observation_period_end_date)
            OVER (PARTITION BY cond_dates.person_id
                  ORDER BY cond_dates.condition_era_start_date)
                    AS next_cond_start_date,
          cond_dates.day_cond_count
        FROM v_src_person_strata person
        INNER JOIN
         (SELECT
            person_id,
            condition_era_start_date,
            COUNT(condition_concept_id) AS day_cond_count
          FROM
           (SELECT DISTINCT
              cond.person_id,
              cond.condition_concept_id,
              cond.condition_era_start_date
            FROM v_src_condition_era1 cond
            UNION
            SELECT
              person_id,
              -1 AS condition_concept_id,
              observation_period_start_date AS condition_era_start_date
            FROM v_src_person_strata) t1
          GROUP BY person_id, condition_era_start_date) cond_dates
          ON person.person_id = cond_dates.person_id
        WHERE person.observation_period_end_date
                >= cond_dates.condition_era_start_date) cond_gaps
      LEFT JOIN v_src_first_drugs drug ON cond_gaps.person_id = drug.person_id
          AND cond_gaps.cond_start_date <= drug.drug_era_start_date
          AND cond_gaps.next_cond_start_date > drug.drug_era_start_date
      GROUP BY cond_gaps.person_id, cond_gaps.gender_concept_id,
       cond_gaps.age_bucket, cond_gaps.condition_count_bucket,
       cond_gaps.drug_count_bucket,cond_gaps.cond_start_date,
        cond_gaps.next_cond_start_date, cond_gaps.day_cond_count),
      cond_drug AS
       (SELECT DISTINCT
          gaps.person_id,
          gaps.gender_concept_id,
          gaps.age_bucket,
          gaps.condition_count_bucket,
          gaps.drug_count_bucket,
          gaps.cond_start_date,
          gaps.next_cond_start_date,
          gaps.day_cond_count,
          coalesce(cond.condition_concept_id,-1) AS condition_concept_id,
          coalesce(drug.drug_era_start_date,gaps.cond_start_date) AS drug_era_start_date,
          coalesce(drug.drug_concept_id,-1) AS drug_concept_id
        FROM gaps
        LEFT JOIN v_src_condition_era1 cond
          ON gaps.person_id = cond.person_id
          AND gaps.cond_start_date = cond.condition_era_start_date
        LEFT JOIN v_src_first_drugs drug
          ON gaps.person_id = drug.person_id
            AND gaps.cond_start_date <= drug.drug_era_start_date
            AND gaps.next_cond_start_date > drug.drug_era_start_date)
    SELECT
      condition_concept_id,
      interval_bucket,
      gender_concept_id,
      age_bucket,
      condition_count_bucket,
      drug_count_bucket,
      2 as day_cond_count,
      drug_concept_id,
      delta_days,
      n,
      SUM(probability)
        OVER
         (PARTITION BY condition_concept_id, interval_bucket, gender_concept_id,
            age_bucket, condition_count_bucket, drug_count_bucket
          ORDER BY probability DESC
            ROWS UNBOUNDED PRECEDING) accumulated_probability
    FROM
     (SELECT
        condition_concept_id,
        interval_bucket,
        gender_concept_id,
        age_bucket,
        condition_count_bucket,
        drug_count_bucket,
        drug_concept_id,
        delta_days,
        sum_prob AS n,
        1.0 * sum_prob/ NULLIF(SUM(sum_prob)
                                OVER(PARTITION BY condition_concept_id, interval_bucket,
                    gender_concept_id, age_bucket, condition_count_bucket,
                    drug_count_bucket), 0) AS probability
      FROM
       (SELECT
          condition_concept_id,
          interval_bucket,
          gender_concept_id,
          age_bucket,
          condition_count_bucket,
          drug_count_bucket,
          delta_days,
          drug_concept_id,
          SUM(prob) AS sum_prob
        FROM
         (SELECT
            condition_concept_id,
            osim__duration_days_bucket(next_cond_start_date - cond_start_date)
              AS interval_bucket,
            gender_concept_id,
            age_bucket,
            condition_count_bucket,
            drug_count_bucket,
            osim__round_days(delta_days) AS delta_days,
            drug_concept_id,
            1.0 / (day_cond_count) AS prob
          FROM
           (SELECT DISTINCT
              person_id,
              gender_concept_id,
              age_bucket,
              condition_count_bucket,
              drug_count_bucket,
              cond_start_date,
              next_cond_start_date,
              day_cond_count,
              condition_concept_id,
              drug_era_start_date - cond_start_date AS delta_days,
              drug_concept_id
            FROM cond_drug
            UNION
            SELECT DISTINCT
              gaps.person_id,
              gaps.gender_concept_id,
              gaps.age_bucket,
              gaps.condition_count_bucket,
              gaps.drug_count_bucket,
              gaps.cond_start_date,
              gaps.next_cond_start_date,
              gaps.day_cond_count,
              cond.condition_concept_id,
              0 AS delta_days,
              -1 AS drug_concept_id
            FROM gaps
            INNER JOIN v_src_condition_era1 cond
              ON gaps.person_id = cond.person_id
                AND gaps.cond_start_date = cond.condition_era_start_date
            WHERE gaps.day_cond_count > 1) t1
          ORDER BY 1,2) t2
        GROUP BY condition_concept_id, interval_bucket, gender_concept_id,
              age_bucket, condition_count_bucket, drug_count_bucket,
              delta_days, drug_concept_id
        ORDER BY 1,2,5 DESC) t3
     ) t4
    ORDER BY 1,2,6;

    GET DIAGNOSTICS num_rows = ROW_COUNT;
    MESSAGE := num_rows || ' rows inserted into osim_cond_drug_prob for '
        || 'co-occurent condtion transitions.';
    PERFORM insert_log(MESSAGE, 'ins_cond_drug_prob');

    --COMMIT;

    PERFORM '
    CREATE INDEX osim_cond_drug_prob_ix1 ON osim_cond_first_drug_prob (
      condition_concept_id, interval_bucket, age_bucket, condition_count_bucket,
      drug_count_bucket, day_cond_count, gender_concept_id)
      NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
        INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
        PCTINCREASE 0 FREELISTS 10 FREELIST GROUPS 10 BUFFER_POOL DEFAULT)';

    PERFORM '
    CREATE INDEX osim_cond_drug_prob_ix2
      ON osim_cond_first_drug_prob (accumulated_probability)
      NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
        INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
        PCTINCREASE 0 FREELISTS 10 FREELIST GROUPS 10 BUFFER_POOL DEFAULT)';

    --COMMIT;

    -- a few of the last buckets may not quite add up to 1.0
    UPDATE osim_cond_first_drug_prob
    SET accumulated_probability = 1.0
    WHERE oid IN
     (SELECT DISTINCT
        FIRST_VALUE(oid)
          OVER
           (PARTITION BY condition_concept_id, interval_bucket, day_cond_count
            ORDER BY accumulated_probability DESC)
      FROM osim_cond_first_drug_prob);

    --COMMIT;

    PERFORM insert_log('Processing complete', 'ins_cond_first_drug_prob');
    EXCEPTION
      WHEN OTHERS THEN
      PERFORM insert_log('Exception', 'ins_cond_first_drug_prob');
  END;
$$;
