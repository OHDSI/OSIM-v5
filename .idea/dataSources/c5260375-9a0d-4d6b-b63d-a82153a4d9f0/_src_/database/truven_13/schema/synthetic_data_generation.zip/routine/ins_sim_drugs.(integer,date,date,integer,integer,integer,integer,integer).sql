create function ins_sim_drugs(max_person_id integer, this_person_begin_date date, this_person_end_date date, this_gender integer, this_cond_count_bucket integer, this_age integer, this_age_bucket integer, drug_persistence integer) returns void
LANGUAGE plpgsql
AS $$
DECLARE

    tmp_rand                      FLOAT;
    this_target_drug_count        INTEGER;
    this_target_drug_bucket       INTEGER;
    this_person_drug_count        INTEGER;
    this_cond_drug_count          INTEGER;
    this_drug_concept             INTEGER;
    this_drug_delta_days          INTEGER;

  BEGIN
    --
    -- Simulate Drugs
    --   Drugs are simulated from the person's Conditons

    -- Clear existing condition and drug concepts for new person
    DROP TABLE IF EXISTS this_person_drugs_table;
    CREATE TEMPORARY TABLE this_person_drugs_table (
      drug_concept_id INTEGER NOT NULL
    ) ON COMMIT DELETE ROWS;


    -- Draw for person's Distinct Drug Concept count
    BEGIN
      tmp_rand := random();
      SELECT DISTINCT FIRST_VALUE(drug_count)
        OVER (ORDER BY accumulated_probability)
      INTO STRICT this_target_drug_count
      FROM osim_drug_count_prob
      WHERE gender_concept_id = this_gender
        AND age_bucket = this_age_bucket
        AND condition_count_bucket = this_cond_count_bucket
        AND tmp_rand <= accumulated_probability;
    EXCEPTION
      WHEN NO_DATA_FOUND
        THEN
          this_target_drug_count := 0;
    END;
    this_target_drug_bucket := osim__drug_count_bucket(this_target_drug_count);

    this_person_drug_count := 0;

    --
    -- Begin Drug simulation Loop
    --
    WHILE this_person_drug_count < this_target_drug_count
    LOOP
      DECLARE
        tmp_age                   INTEGER;
        tmp_age_bucket            INTEGER;
        -- Cursor of all condition eras and starta needed for transitions
        cond_era_cur CURSOR FOR
          SELECT
            person_id,
            condition_concept_id,
            condition_era_start_date,
            interval_bucket,
            day_cond_count
          FROM
           (SELECT DISTINCT
              cond_lag.person_id,
              coalesce(cond.condition_concept_id,-1) AS condition_concept_id,
              cond_lag.lag_start_date AS condition_era_start_date,
              osim__duration_days_bucket(cond_lag.lag_end_date
                  - cond_lag.lag_start_date) AS interval_bucket,
              cond_lag.day_cond_count
            FROM
             (SELECT
                cond_dates.person_id,
                cond_dates.condition_era_start_date AS lag_start_date,
                LEAD (cond_dates.condition_era_start_date,1,
                  cond_dates.condition_era_start_date+30)
                  OVER (PARTITION BY cond_dates.person_id
                        ORDER BY cond_dates.condition_era_start_date)
                          AS lag_end_date,
                cond_dates.day_cond_count
              FROM
               (SELECT DISTINCT
                  cond.person_id,
                  cond.condition_era_start_date,
                  COUNT (DISTINCT cond.condition_concept_id) AS day_cond_count
                FROM osim_tmp_condition_era cond
                WHERE cond.person_id=max_person_id
                GROUP BY cond.person_id, cond.condition_era_start_date
                UNION
                SELECT person_id, condition_era_start_date, 0
                FROM osim_tmp_condition_era cond
                  WHERE cond.person_id = max_person_id
                  AND cond.condition_era_start_date = this_person_begin_date
                AND cond.condition_era_id IS NULL) cond_dates) cond_lag
            LEFT JOIN osim_tmp_condition_era cond
              ON cond_lag.person_id = cond.person_id
                AND cond_lag.lag_start_date=cond.condition_era_start_date) t1
          ORDER BY 5 DESC;

      BEGIN
        <<cond_loop>>
        FOR cond_era IN cond_era_cur LOOP
          -- Draw for INTEGER of Drug Draws
          BEGIN
            tmp_age := (cond_era.condition_era_start_date
              - this_person_begin_date) / 365.25 + this_age;
            tmp_age_bucket := osim__age_bucket(tmp_age);

            tmp_rand := random();

            SELECT DISTINCT
              FIRST_VALUE(drug_count)
                OVER (ORDER BY count_prob.accumulated_probability) AS drug_era_count
            INTO STRICT this_cond_drug_count
            FROM osim_cond_drug_count_prob count_prob
            WHERE count_prob.condition_concept_id = cond_era.condition_concept_id
              AND count_prob.drug_count_bucket = this_target_drug_bucket
              AND count_prob.condition_count_bucket = this_cond_count_bucket
              AND count_prob.interval_bucket = cond_era.interval_bucket
              AND count_prob.age_bucket = tmp_age_bucket
              AND tmp_rand <= count_prob.accumulated_probability;
          EXCEPTION
            WHEN NO_DATA_FOUND
              THEN
                this_cond_drug_count := 0;
          END;

          -- Force the last few Drugs, if necessary
          IF this_target_drug_count - this_person_drug_count < 10
             AND this_cond_drug_count = 0 THEN
            this_cond_drug_count := 1;
          END IF;


          FOR i IN 1..this_cond_drug_count
          LOOP
          -- Draw for Drug Concept
            BEGIN
              tmp_rand := random();
              SELECT DISTINCT
                FIRST_VALUE(drug_concept_id)
                  OVER (ORDER BY accumulated_probability),
                coalesce(FIRST_VALUE(delta_days)
                  OVER (ORDER BY accumulated_probability),0)
              INTO STRICT this_drug_concept, this_drug_delta_days
              FROM osim_cond_first_drug_prob prob
              WHERE prob.condition_concept_id = cond_era.condition_concept_id
                AND prob.drug_count_bucket = this_target_drug_bucket
                AND prob.condition_count_bucket = this_cond_count_bucket
                AND prob.gender_concept_id = this_gender
                AND prob.age_bucket = this_age_bucket
                AND prob.day_cond_count = 2
                  --CASE WHEN cond_era.day_cond_count > 1 THEN 2 ELSE 1 END
                AND tmp_rand <= prob.accumulated_probability;
            EXCEPTION
              WHEN NO_DATA_FOUND
                THEN
                  this_drug_concept := 0;
                  this_drug_delta_days := 0;
            END;

            IF this_drug_concept > 0 AND NOT EXISTS (select 1 from this_person_drugs_table where drug_concept_id = this_drug_concept) THEN
              this_drug_delta_days := (osim__randomize_days(this_drug_delta_days));


              IF cond_era.condition_era_start_date + this_drug_delta_days
                <= this_person_end_date THEN
                INSERT INTO osim_tmp_drug_era
                 (drug_era_start_date, drug_era_end_date, person_id,
                  drug_concept_id, drug_exposure_count)
                VALUES(
                  cond_era.condition_era_start_date + this_drug_delta_days,
                  cond_era.condition_era_start_date + this_drug_delta_days,
                  cond_era.person_id,
                  this_drug_concept,
                  1);

                this_person_drug_count := this_person_drug_count + 1;
                INSERT INTO this_person_drugs_table VALUES (this_drug_concept);

                IF this_person_drug_count >= this_target_drug_count THEN
                  --IF normal_rand(1, 0, 1) <= 0.8 THEN
                    EXIT cond_loop;
                  --END IF;
                END IF;

              END IF;

            END IF;

          END LOOP;

        END LOOP;
      END;

      --Prevent Deadlock
      IF random() <= 0.2 THEN
        this_target_drug_count := this_target_drug_count - 1;
      END IF;

    END LOOP;

    DECLARE
      drug_eras_cur CURSOR FOR
        SELECT drug.drug_concept_id, drug.drug_era_start_date
        FROM osim_tmp_drug_era drug
        WHERE person_id = max_person_id
        FOR UPDATE NOWAIT; -- OF drug_era_end_date NOWAIT;
      tmp_drug_concept_id       INTEGER;
      tmp_drug_era_start_date   DATE;
      tmp_drug_era_end_date     DATE;
      tmp_era_duration          INTEGER;
      tmp_days_remaining        INTEGER;
      tmp_days_remaining_bucket INTEGER;
      tmp_drug_eras_max         INTEGER;
      tmp_drug_eras_for_drug    INTEGER;
      tmp_age                   INTEGER;
      tmp_age_bucket            INTEGER;
      tmp_total_exposure        INTEGER;
      tmp_drug_duration         INTEGER;
      tmp_gap_duration          INTEGER;
      tmp_gaps                  INTEGER;
      tmp_gap                   INTEGER;
      tmp_duration_start        DATE;
      tmp_duration_end          DATE;
    BEGIN

      FOR drug_eras IN drug_eras_cur LOOP

        tmp_drug_concept_id := drug_eras.drug_concept_id;
        tmp_drug_era_start_date := drug_eras.drug_era_start_date;
        tmp_drug_era_end_date := tmp_drug_era_start_date;

        tmp_days_remaining := this_person_end_date - tmp_drug_era_start_date;
        tmp_days_remaining_bucket :=
          osim__time_observed_bucket(tmp_days_remaining);

        tmp_age := this_age + (tmp_drug_era_start_date
          - this_person_begin_date) / 365.25;
        tmp_age_bucket := osim__age_bucket(tmp_age);

        BEGIN
          tmp_rand := random();
          SELECT DISTINCT
            FIRST_VALUE(drug_era_count)
              OVER (ORDER BY accumulated_probability),
            FIRST_VALUE(total_exposure)
              OVER (ORDER BY accumulated_probability)
          INTO STRICT tmp_drug_eras_max, tmp_total_exposure
          FROM osim_drug_era_count_prob
          WHERE drug_concept_id = tmp_drug_concept_id
            AND drug_count_bucket = this_target_drug_bucket
            AND condition_count_bucket = this_cond_count_bucket
            AND age_range = tmp_age_bucket
            AND time_remaining = tmp_days_remaining_bucket
            AND tmp_rand <= accumulated_probability;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            tmp_drug_eras_max := 1;
            tmp_total_exposure := 0;
        END;

        IF tmp_drug_eras_max = 1 THEN
          tmp_drug_duration := tmp_total_exposure;
        ELSE
          BEGIN
            tmp_rand := random();
            SELECT DISTINCT
              FIRST_VALUE(total_duration)
                OVER (ORDER BY accumulated_probability)
            INTO STRICT tmp_drug_duration
            FROM osim_drug_duration_probability
            WHERE drug_concept_id = tmp_drug_concept_id
              AND time_remaining = tmp_days_remaining_bucket
              AND drug_era_count = tmp_drug_eras_max
              AND total_exposure = tmp_total_exposure
              AND tmp_rand <= accumulated_probability;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              tmp_drug_duration := ((drug_persistence + 1) * (tmp_drug_eras_max - 1)) + tmp_total_exposure;
              tmp_drug_duration := tmp_drug_duration
                + random() * ((this_person_end_date - tmp_drug_era_start_date) - tmp_drug_duration);
          END;
        END IF;

        tmp_total_exposure := osim__randomize_days(tmp_total_exposure);
        tmp_drug_duration := osim__randomize_days(tmp_drug_duration);
        tmp_drug_eras_for_drug := 1;

        tmp_duration_start := tmp_drug_era_start_date;
        tmp_duration_end := tmp_duration_start + tmp_drug_duration;

        IF tmp_total_exposure > tmp_drug_duration - ((drug_persistence + 1) * (tmp_drug_eras_max - 1)) THEN
          tmp_total_exposure := tmp_drug_duration - ((drug_persistence + 1) * (tmp_drug_eras_max - 1));
        END IF;

        WHILE tmp_drug_eras_for_drug <= tmp_drug_eras_max
        LOOP

          tmp_gap_duration := tmp_drug_duration - tmp_total_exposure;
          tmp_gaps := tmp_drug_eras_max - tmp_drug_eras_for_drug;
          IF tmp_gaps = 0 THEN
            tmp_era_duration := tmp_total_exposure;
          ELSE
            tmp_era_duration :=
              ROUND(normal_rand(1, 0, 1) * (tmp_total_exposure / (tmp_gaps + 1))
                + (tmp_total_exposure / (tmp_gaps + 1)));
            IF tmp_era_duration < 0 THEN
              tmp_era_duration := 0;
            END IF;
            IF tmp_era_duration > tmp_total_exposure THEN
              tmp_era_duration := tmp_total_exposure;
            END IF;

            tmp_gap := tmp_gap_duration - ( (drug_persistence + 1) * tmp_gaps);
            tmp_gap :=
              ROUND(normal_rand(1, 0, 1) * (tmp_gap / tmp_gaps)
                + (tmp_gap / tmp_gaps));

            tmp_gap := tmp_gap + (drug_persistence + 1);

            IF tmp_gap > tmp_gap_duration - ( (drug_persistence + 1) * (tmp_gaps-1)) THEN
              tmp_gap := tmp_gap_duration - ( (drug_persistence + 1) * (tmp_gaps-1));
            END IF;

            IF tmp_gap < (drug_persistence + 1) THEN
              tmp_gap := (drug_persistence + 1);
            END IF;

          END IF;

          IF tmp_drug_eras_for_drug = 1 THEN
            -- Update already existing first era
            tmp_drug_era_end_date := tmp_drug_era_start_date + tmp_era_duration;

            UPDATE osim_tmp_drug_era
            SET drug_era_end_date = tmp_drug_era_end_date
            WHERE CURRENT OF drug_eras_cur;

            tmp_duration_start := tmp_drug_era_end_date + tmp_gap;
          ELSE
            IF MOD(tmp_drug_eras_for_drug,2) = 0 THEN
              -- insert at the beginning of the duration
              tmp_drug_era_start_date := tmp_duration_start;
              tmp_drug_era_end_date := tmp_duration_start + tmp_era_duration;
              tmp_duration_start := tmp_drug_era_end_date + tmp_gap;
            ELSE
              -- insert at the end of the duration
              tmp_drug_era_end_date := tmp_duration_end;
              tmp_drug_era_start_date := tmp_drug_era_end_date - tmp_era_duration;
              tmp_duration_end := tmp_drug_era_start_date - tmp_gap;
            END IF;
            --insert drug era
            IF tmp_drug_era_start_date <= this_person_end_date THEN
              IF tmp_drug_era_end_date > this_person_end_date THEN
                tmp_drug_era_end_date := this_person_end_date;
              END IF;
              INSERT INTO osim_tmp_drug_era
                (drug_era_start_date, drug_era_end_date, person_id,
                 drug_concept_id, drug_exposure_count)
              VALUES( tmp_drug_era_start_date, tmp_drug_era_end_date,
                      max_person_id,
--                       db_drug_era_type_code,
                      tmp_drug_concept_id, 1);
            END IF;
          END IF;

          tmp_drug_duration := tmp_duration_end - tmp_duration_start;
          tmp_total_exposure  := tmp_total_exposure - tmp_era_duration;
          tmp_drug_eras_for_drug := tmp_drug_eras_for_drug + 1;

        END LOOP;

      END LOOP;

    END;
    PERFORM insert_log('Simulated drug',
        'ins_sim_drug');

  END;
$$;
