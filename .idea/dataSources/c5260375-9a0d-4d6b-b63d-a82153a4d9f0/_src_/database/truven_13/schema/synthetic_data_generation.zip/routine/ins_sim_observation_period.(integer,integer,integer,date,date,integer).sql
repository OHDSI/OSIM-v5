create function ins_sim_observation_period(max_person_id integer, this_gender integer, this_age integer, db_min_date date, db_max_date date, INOUT this_year_of_birth integer, OUT this_cond_count_limit integer, OUT this_cond_count_bucket integer, OUT this_obs_bucket integer, OUT this_obs_days integer, OUT this_person_begin_date date, OUT this_person_end_date date) returns record
LANGUAGE plpgsql
AS $$
DECLARE
    tmp_rand                      FLOAT;
    tmp                           INTEGER;
  BEGIN
    --
    -- Create Observation Period
    --

    -- Draw for distinct condition count
    tmp_rand := random();
    SELECT DISTINCT FIRST_VALUE(cond_concept_count)
      OVER (ORDER BY accumulated_probability)
    INTO this_cond_count_limit
    --select count(*)
    FROM osim_cond_count_probability
    WHERE gender_concept_id = this_gender
      AND age_at_obs = this_age
      AND tmp_rand <= accumulated_probability;

    this_cond_count_bucket := osim__condition_count_bucket(this_cond_count_limit);

    -- Draw for full semi-years observed (observation period duration)
    tmp_rand := random();
    SELECT DISTINCT FIRST_VALUE(time_observed)
      OVER (ORDER BY accumulated_probability)
    INTO this_obs_bucket
    FROM osim_time_obs_probability
    WHERE gender_concept_id = this_gender
      AND age_at_obs = this_age
      AND cond_count_bucket = this_cond_count_bucket
      AND tmp_rand <= accumulated_probability;

    this_obs_days := FLOOR((random() * 0.9999 + this_obs_bucket) * 182.625);

    -- Randomly assign person start date
    -- Is this an issue for new and discontinued drug concepts?
    --

    tmp := FLOOR(((db_max_date - this_obs_days) - db_min_date) * random());
    this_person_begin_date := db_min_date;
    SELECT tmp + db_min_date INTO this_person_begin_date;

    this_year_of_birth := this_year_of_birth + CAST(extract(year from this_person_begin_date) AS INTEGER)
      - CAST(extract(year from db_min_date) AS INTEGER);

    -- Insert person
    INSERT INTO osim_person
    (person_id,year_of_birth,gender_concept_id,race_concept_id)
    SELECT
      max_person_id AS person_id,
      this_year_of_birth AS year_of_birth,
      this_gender AS gender_concept_id,
      NULL AS race_concept_id
    ;

    -- Create observation period record
    this_person_end_date := this_person_begin_date + this_obs_days;

    INSERT INTO osim_observation_period
    (observation_period_id, person_id, observation_period_start_date,
      observation_period_end_date, rx_data_availability, dx_data_availability,
     hospital_data_availability
    )
    SELECT
      max_person_id AS observation_period_id,
      max_person_id AS person_id,
      this_person_begin_date AS observation_period_start_date,
      this_person_end_date AS observation_period_end_date,
      'Y', 'Y', 'N'
    ;
    PERFORM insert_log('Simulated observation period',
        'ins_sim_observation_period');
  END;
$$;
