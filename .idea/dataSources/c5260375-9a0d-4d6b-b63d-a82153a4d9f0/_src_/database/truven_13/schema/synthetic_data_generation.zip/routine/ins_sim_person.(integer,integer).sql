create function ins_sim_person(db_min_year integer, INOUT max_person_id integer, OUT this_gender integer, OUT this_age integer, OUT this_age_bucket integer, OUT this_year_of_birth integer) returns record
LANGUAGE plpgsql
AS $$
DECLARE
    tmp_rand                      FLOAT;
    i                             INTEGER;
  BEGIN
    --
    -- Create osim person
    --
    -- Try 5 times to generate a person before giving nulls
    i := 1;
    WHILE i <=5 LOOP

      BEGIN
      -- Draw for gender_concept_id
      tmp_rand := random();
      SELECT DISTINCT FIRST_VALUE(gender_concept_id)
        OVER (ORDER BY accumulated_probability)
      INTO STRICT this_gender
      FROM osim_gender_probability
      WHERE tmp_rand <= accumulated_probability;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          i := i + 1; -- try again if value null
          PERFORM insert_log('Trying again', 'ins_sim_person');
          CONTINUE;
      END;

      BEGIN
        -- Draw for age
      tmp_rand := random();
      SELECT DISTINCT FIRST_VALUE(age_at_obs)
        OVER (ORDER BY accumulated_probability)
      INTO STRICT this_age
      FROM osim_age_at_obs_probability
      WHERE gender_concept_id = this_gender
        AND tmp_rand <= accumulated_probability;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          i := i + 1; -- try again if value null
          PERFORM insert_log('Trying again', 'ins_sim_person');
          CONTINUE;
      END;

      -- Calcualte this person' age bucket and year of birth
      this_age_bucket := osim__age_bucket(this_age);
      this_year_of_birth := db_min_year - this_age;

      EXIT; -- person created succesfully
    END LOOP;
    IF i = 6 THEN
      PERFORM insert_log('WARNING: Null values', 'ins_sim_person');
    END IF;
    max_person_id := max_person_id + 1;
    PERFORM insert_log('Simulated a person',
        'ins_sim_person');
  END;
$$;
