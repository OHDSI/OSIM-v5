create function ins_src_db_attributes() returns void
LANGUAGE plpgsql
AS $$
DECLARE
    db_min_date           DATE;
    db_max_date           DATE;
    persons_count         INTEGER;
    condition_eras_count  INTEGER;
    drug_eras_count       INTEGER;

--     db_cond_era_type_code VARCHAR(3);
--     db_drug_era_type_code VARCHAR(3);
    num_rows              INTEGER;
    MESSAGE               text;
  BEGIN
    PERFORM insert_log('Getting general Source Database Counts', 'ins_src_db_attributes');

    SELECT MIN(min_db_date)
    INTO db_min_date
    FROM
     (SELECT MIN(observation_period_start_date) AS min_db_date
      FROM v_src_observation_period) t1;

    SELECT MAX(max_db_date)
    INTO db_max_date
    FROM
     (SELECT MAX(observation_period_end_date) AS max_db_date
      FROM v_src_observation_period) t2;

    SELECT COUNT(DISTINCT person.person_id)
    INTO persons_count
    FROM v_src_person person;

    SELECT COUNT(DISTINCT cond.condition_occurrence_id)
    INTO condition_eras_count
    FROM v_src_condition_era1_ids cond;

    SELECT COUNT(DISTINCT drug.drug_exposure_id)
    INTO drug_eras_count
    FROM v_src_drug_era1_ids drug;

    MESSAGE := 'Source CDM Attributes:'
      || ' db_min_date=' || db_min_date
      || ', db_max_date=' || db_max_date
      || ', persons_count=' || persons_count
--       || ', drug_exposure_type=' || db_drug_era_type_code
      || ', condition_eras_count=' || condition_eras_count
      || ', drug_eras_count=' || drug_eras_count;
--     insert_log(MESSAGE, 'ins_src_db_attributes');

    PERFORM 'TRUNCATE TABLE osim_src_db_attributes';

    INSERT INTO osim_src_db_attributes
      (db_min_date, db_max_date, persons_count, condition_eras_count,
       drug_eras_count)
    SELECT db_min_date, db_max_date, persons_count, condition_eras_count,
      drug_eras_count;
--       ,db_cond_era_type_code

    GET DIAGNOSTICS num_rows = ROW_COUNT;
    MESSAGE := num_rows || ' rows inserted into osim_src_db_attributes.';
    --COMMIT;
    PERFORM insert_log(MESSAGE, 'ins_src_db_attributes');
    PERFORM insert_log('Processing complete', 'ins_src_db_attributes');

  END;
$$;
