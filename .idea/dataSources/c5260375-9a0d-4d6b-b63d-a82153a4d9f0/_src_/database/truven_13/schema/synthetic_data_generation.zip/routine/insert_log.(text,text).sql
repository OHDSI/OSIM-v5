create function insert_log(text, text) returns void
LANGUAGE plpgsql
AS $$
DECLARE
    m ALIAS FOR $1;
    procedure_name ALIAS FOR $2;
  BEGIN
    INSERT INTO osim_log (stored_procedure_name, message)
    VALUES (procedure_name, m);

  EXCEPTION
    WHEN OTHERS THEN
    RAISE NOTICE 'Log exception';
  END;
$$;
