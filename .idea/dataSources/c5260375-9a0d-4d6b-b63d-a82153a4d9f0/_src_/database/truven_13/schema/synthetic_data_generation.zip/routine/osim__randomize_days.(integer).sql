create function osim__randomize_days(integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE days ALIAS FOR $1;
  BEGIN
    CASE TRUE
      WHEN days <= 75 THEN RETURN ROUND(days);
      ELSE RETURN ROUND(days - 15 + random() * 30);
    END CASE;
  END;
$$;
