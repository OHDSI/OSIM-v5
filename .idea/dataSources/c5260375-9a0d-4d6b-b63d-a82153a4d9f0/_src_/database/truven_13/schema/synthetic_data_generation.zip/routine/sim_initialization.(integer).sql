create function sim_initialization(person_start_id integer, OUT my_sid character varying, OUT my_start_time date, OUT db_min_date date, OUT db_max_date date, OUT db_min_year integer, OUT db_max_year integer, OUT max_person_id integer, OUT max_condition_era_id integer, OUT max_drug_era_id integer, OUT osim_db_persons integer, OUT drug_persistence integer, OUT cond_persistence integer) returns record
LANGUAGE plpgsql
AS $$
DECLARE
  BEGIN
    PERFORM insert_log('Initializing Simulation',
      'sim_initialization');

    SELECT session_user
    INTO my_sid;

    SELECT current_timestamp
    INTO my_start_time;

    PERFORM insert_log('My SID=' || my_sid || ', Simulation Start Time=' ||
      to_char(my_start_time, 'Dy DD-Mon-YYYY HH24:MI:SS'),
      'sim_initialization');

    -- Get Min and Max dates for the simulation date range
    SELECT src.db_min_date, src.db_max_date
    FROM osim_src_db_attributes src
    LIMIT 1 INTO db_min_date, db_max_date;

    db_min_year := CAST(extract(year from db_min_date) AS INTEGER);
    db_max_year := CAST(extract(year from db_max_date) AS INTEGER);

    -- Get max person_id from existing simulated data
    -- to maintain unique ID generation
    IF person_start_id = 0 THEN
      SELECT coalesce(MAX(person_id),0)
      INTO max_person_id
      FROM osim_person;
    ELSE
      max_person_id := person_start_id - 1;
    END IF;

    -- Get max condition_era_id from existing simulated data
    -- to maintain unique ID generation
    SELECT coalesce(MAX(condition_era_id),0)
    INTO max_condition_era_id
    FROM osim_condition_era;

    -- Get max drug_era_id from existing simulated data
    -- to maintain unique ID generation
    SELECT coalesce(MAX(drug_era_id),0)
    INTO max_drug_era_id
    FROM osim_drug_era;

    -- Get current person count in existing simulated data
    SELECT COUNT(distinct person_id)
    INTO osim_db_persons
    FROM osim_person;

    PERFORM insert_log('Processing complete', 'sim_initialization');
  END;
$$;
