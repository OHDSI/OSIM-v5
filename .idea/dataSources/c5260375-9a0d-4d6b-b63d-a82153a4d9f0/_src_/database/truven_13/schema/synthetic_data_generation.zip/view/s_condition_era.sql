CREATE VIEW s_condition_era AS SELECT condition_era.condition_era_id,
    condition_era.person_id,
    condition_era.condition_concept_id,
    condition_era.condition_era_start_date,
    condition_era.condition_era_end_date,
    condition_era.condition_occurrence_count
   FROM omop.condition_era;
