CREATE VIEW s_observation_period AS SELECT observation_period.observation_period_id,
    observation_period.person_id,
    observation_period.observation_period_start_date,
    observation_period.observation_period_end_date,
    observation_period.period_type_concept_id,
    observation_period.x_srcid,
    observation_period.x_srcloadid,
    observation_period.x_srcfile,
    observation_period.x_createdate,
    observation_period.x_updatedate
   FROM omop.observation_period;
