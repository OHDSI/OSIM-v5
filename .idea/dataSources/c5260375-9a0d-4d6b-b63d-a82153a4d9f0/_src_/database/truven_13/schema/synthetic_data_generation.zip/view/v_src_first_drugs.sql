CREATE VIEW v_src_first_drugs AS SELECT DISTINCT drug.person_id,
    first_value(drug.drug_era_start_date) OVER (PARTITION BY drug.person_id, drug.drug_concept_id ORDER BY drug.drug_era_start_date) AS drug_era_start_date,
    first_value(drug.drug_era_end_date) OVER (PARTITION BY drug.person_id, drug.drug_concept_id ORDER BY drug.drug_era_start_date) AS drug_era_end_date,
    drug.drug_concept_id
   FROM (synthetic_data_generation.v_src_drug_era1 drug
     JOIN synthetic_data_generation.s_person person ON ((drug.person_id = person.person_id)))
  GROUP BY drug.person_id, drug.drug_era_start_date, drug.drug_era_end_date, drug.drug_concept_id;
