create function anytextcat(anynonarray, text) returns text
STABLE
LANGUAGE SQL
AS $$
select $1::pg_catalog.text || $2
$$;
