create function analyze_source_db() returns void
LANGUAGE plpgsql
AS $$
DECLARE
  BEGIN
    PERFORM insert_log('Starting Condition Concept Reoccurrence Probability Analysis',
        'analyze_source_db');

    PERFORM ins_src_db_attributes();
    PERFORM ins_gender_probability();
    PERFORM ins_age_at_obs_probability();
    PERFORM ins_cond_count_probability();
    PERFORM ins_time_obs_probability();
    PERFORM ins_cond_era_count_prob();
    PERFORM ins_first_cond_probability();
    PERFORM ins_cond_days_before_prob();
    PERFORM ins_drug_count_prob();
    PERFORM ins_cond_drug_count_prob();
    PERFORM ins_cond_first_drug_prob();
    PERFORM ins_drug_era_count_prob();
    PERFORM ins_drug_duration_probability();

    PERFORM insert_log('Processing complete', 'analyze_source_db');

  END;
$$;
