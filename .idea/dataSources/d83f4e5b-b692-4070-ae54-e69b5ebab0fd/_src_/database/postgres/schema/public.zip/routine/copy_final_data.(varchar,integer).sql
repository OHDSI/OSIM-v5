create function copy_final_data(destination_schema character varying DEFAULT 'osim_dev'::character varying, total_person_count integer DEFAULT 5000) returns void
LANGUAGE plpgsql
AS $$
DECLARE
    current_person_count INTEGER;
--     tmp_max_id           INTEGER;
    tmp_sql              VARCHAR(2000);
  BEGIN
    SELECT COUNT(*)
    INTO current_person_count
    FROM osim_person;

    IF current_person_count = total_person_count THEN
      SELECT create_osim_indexes();

      PERFORM insert_log('Copying person data', 'copy_final_data');

      tmp_sql :=
       'INSERT /*+ APPEND NOLOGGING */ INTO ' ||
         destination_schema || '.person ' ||
       ' (person_id,year_of_birth,gender_concept_id,race_concept_id) ' ||
       'SELECT person_id, year_of_birth, gender_concept_id, NULL AS race_concept_id ' ||
       'FROM osim_person ' ||
       'ORDER BY person_id';

      PERFORM tmp_sql;
      --COMMIT;

      PERFORM insert_log('Copying observation period data', 'copy_final_data');

      tmp_sql :=
       'INSERT /*+ APPEND NOLOGGING */ INTO ' ||
          destination_schema || '.observation_period ' ||
       '  (observation_period_id, person_id, observation_period_start_date, ' ||
       '   observation_period_end_date, rx_data_availability, dx_data_availability, ' ||
       '   hospital_data_availability) ' ||
       'SELECT observation_period_id, person_id, observation_period_start_date, ' ||
       '  observation_period_end_date, rx_data_availability, dx_data_availability, ' ||
       '  hospital_data_availability ' ||
       'FROM osim_observation_period ' ||
       'ORDER BY person_id';

      PERFORM tmp_sql;
      --COMMIT;

      PERFORM insert_log('Copying condition era data', 'copy_final_data');

      tmp_sql :=
       'INSERT /*+ APPEND NOLOGGING */ INTO ' ||
          destination_schema || '.omop_condition_era ' ||
       '  (condition_era_id, condition_era_start_date, condition_era_end_date, ' ||
       '   person_id, condition_concept_id, ' ||
       '   condition_occurrence_count) ' ||
       'SELECT ROWNUM, condition_era_start_date, condition_era_end_date, ' ||
       '  person_id, condition_concept_id, ' ||
       '  condition_occurrence_count ' ||
       'FROM osim_condition_era ' ||
       'ORDER BY condition_era_start_date, person_id';

      PERFORM tmp_sql;
      --COMMIT;

      PERFORM insert_log('Copying drug era data', 'copy_final_data');

      tmp_sql :=
       'INSERT /*+ APPEND NOLOGGING */ INTO ' ||
          destination_schema || '.omop_drug_era ' ||
       '  (drug_era_id, drug_era_start_date, drug_era_end_date, person_id, ' ||
       '   drug_exposure_type, drug_concept_id, drug_exposure_count) ' ||
       'SELECT ROWNUM, drug_era_start_date, drug_era_end_date, person_id, ' ||
       '  drug_exposure_type, drug_concept_id, drug_exposure_count ' ||
       'FROM osim_drug_era ' ||
       'ORDER BY drug_era_start_date, person_id';

      PERFORM tmp_sql;
      --COMMIT;

      PERFORM insert_log('Data copying complete', 'copy_final_data');

    ELSE
      PERFORM insert_log('All data is not complete for final copy', 'copy_final_data');
    END IF;

    PERFORM insert_log('Processing complete', 'copy_final_data');
  EXCEPTION
    WHEN OTHERS THEN
    PERFORM insert_log('Exception', 'copy_final_data');

  END;
$$;
