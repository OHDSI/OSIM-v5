create function ins_age_at_obs_probability() returns void
LANGUAGE plpgsql
AS $$
DECLARE
    num_rows             INTEGER;
    MESSAGE              text;
  BEGIN

    PERFORM insert_log('Starting Age Probability Analysis', 'ins_age_at_obs_probability');

    PERFORM 'TRUNCATE TABLE osim_age_at_obs_probability';
    --COMMIT;

    INSERT /*+ append nologging */ INTO osim_age_at_obs_probability
      (gender_concept_id, age_at_obs, n, accumulated_probability)
      SELECT
        gender_concept_id,
        age_at_obs,
        n,
        SUM(probability)
          OVER
           (PARTITION BY gender_concept_id
            ORDER BY probability DESC ROWS UNBOUNDED PRECEDING) accumulated_probability
      FROM
       (SELECT
          strata.gender_concept_id,
          strata.age AS age_at_obs,
          COUNT(person_id) AS n,
          1.0 * COUNT(person_id) / NULLIF(SUM(COUNT(person_id)) OVER(PARTITION BY gender_concept_id),0) AS probability
        FROM v_src_person_strata strata
        GROUP BY gender_concept_id, age) t1;

    GET DIAGNOSTICS num_rows = ROW_COUNT;
    MESSAGE := num_rows || ' rows inserted into osim_age_at_obs_probability.';
    PERFORM insert_log(MESSAGE, 'ins_age_at_obs_probability');

    --COMMIT;
    -- Ensure last accumulated_probability = 1.0
    UPDATE osim_age_at_obs_probability
    SET accumulated_probability = 1.0
    WHERE oid IN
     (SELECT DISTINCT
        FIRST_VALUE(oid)
          OVER
           (PARTITION BY gender_concept_id
            ORDER BY accumulated_probability DESC)
      FROM osim_age_at_obs_probability);

     --COMMIT;

    PERFORM insert_log('Processing complete', 'ins_age_at_obs_probability');

  EXCEPTION
    WHEN OTHERS THEN
    PERFORM insert_log('Exception', 'ins_age_at_obs_probability');
    raise notice '% %', SQLERRM, SQLSTATE;
  END;
$$;
