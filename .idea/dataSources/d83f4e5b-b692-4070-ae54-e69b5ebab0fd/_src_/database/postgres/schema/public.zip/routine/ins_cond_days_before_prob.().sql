create function ins_cond_days_before_prob() returns void
LANGUAGE plpgsql
AS $$
DECLARE
    num_rows INTEGER;
    MESSAGE              text;
  BEGIN
    PERFORM insert_log('Starting Condition Concept Reoccurrence Probability Analysis',
      'ins_cond_reoccur_probability');

    PERFORM 'TRUNCATE TABLE osim_cond_reoccur_probability';
    --COMMIT;

    -- Drop Indexes for Quicker Insertion
    BEGIN
      PERFORM 'DROP INDEX osim_cond_reoccur_ix1';
      PERFORM 'DROP INDEX osim_cond_reoccur_ix2';
    EXCEPTION
      WHEN OTHERS THEN
        PERFORM insert_log('Probability indexes are already removed',
            'ins_cond_reoccur_probability');
    END;

    --COMMIT;

    INSERT /*+ append nologging */ INTO osim_cond_reoccur_probability
    (condition_concept_id, age_range, time_remaining,
     delta_days, n, accumulated_probability)
      SELECT
        condition_concept_id,
        age_range,
        time_remaining,
        delta_days,
        n,
        SUM(probability)
          OVER
           (PARTITION BY
              --gender_concept_id,
              age_range,
              time_remaining,
              condition_concept_id
            ORDER BY probability DESC
              ROWS UNBOUNDED PRECEDING) accumulated_probability
      FROM
       (SELECT
          --gender_concept_id,
          age_range,
          time_remaining,
          condition_concept_id,
          delta_days,
          eras AS n,
          1.0 * eras/ NULLIF(SUM(eras)
                                OVER(PARTITION BY age_range, time_remaining, condition_concept_id), 0)
            AS probability
        FROM
         (SELECT
            --gender_concept_id,
            age_range,
            time_remaining,
            condition_concept_id,
            delta_days,
            count(condition_era_id) AS eras
          FROM
           (SELECT
              condition_era_id,
              condition_concept_id,
              osim__age_bucket(age + (prior_start - this_start) / 365.25)
                AS age_range,
              osim__time_observed_bucket(observation_period_end_date - prior_start)
                AS time_remaining,
              osim__round_days(this_start - prior_start) AS delta_days
            FROM
             (SELECT
                person.age,
                cond.condition_era_id,
                cond.condition_concept_id,
                coalesce(LAG(cond.condition_era_start_date,1)
                  OVER ( PARTITION BY person.person_id, cond.condition_concept_id
                         ORDER BY cond.condition_era_start_date),
                          person.observation_period_start_date) AS prior_start,
                cond.condition_era_start_date AS this_start,
                person.observation_period_end_date
              FROM v_src_person_strata person
              INNER JOIN v_src_condition_era1 cond
                ON person.person_id = cond.person_id) t1
           ) t2
          GROUP BY age_range, time_remaining, condition_concept_id, delta_days) t3
       ) t4
      ORDER BY 1,2,3,6;

    GET DIAGNOSTICS num_rows = ROW_COUNT;
    MESSAGE := num_rows || ' rows inserted into osim_cond_reoccur_probability.';
    PERFORM insert_log(MESSAGE, 'ins_cond_reoccur_probability');

    --COMMIT;

    PERFORM '
    CREATE INDEX osim_cond_reoccur_ix1 ON osim_cond_reoccur_probability (
      condition_concept_id,
      age_range,
      time_remaining)
    NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
      INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 10 FREELIST GROUPS 10 BUFFER_POOL DEFAULT)';

    PERFORM '
    CREATE INDEX osim_cond_reoccur_ix2 ON osim_cond_reoccur_probability (
      accumulated_probability)
    NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
      INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 10 FREELIST GROUPS 10 BUFFER_POOL DEFAULT)';

    --COMMIT;

    -- a few of the last buckets may not quite add up to 1.0
    UPDATE osim_cond_reoccur_probability
    SET accumulated_probability = 1.0
    WHERE oid IN
     (SELECT DISTINCT
        FIRST_VALUE(oid)
          OVER
           (PARTITION BY condition_concept_id, age_range, time_remaining
            ORDER BY accumulated_probability DESC)
      FROM osim_cond_reoccur_probability);

    --COMMIT;

    PERFORM insert_log('Processing complete', 'ins_cond_reoccur_probability');
  EXCEPTION
    WHEN OTHERS THEN
    PERFORM insert_log('Exception', 'ins_cond_reoccur_probability');

  END;
$$;
