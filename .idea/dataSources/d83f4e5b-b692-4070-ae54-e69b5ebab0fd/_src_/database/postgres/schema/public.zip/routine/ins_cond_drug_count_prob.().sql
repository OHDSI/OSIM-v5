create function ins_cond_drug_count_prob() returns void
LANGUAGE plpgsql
AS $$
DECLARE
    num_rows INTEGER;
    MESSAGE              text;
  BEGIN
    PERFORM insert_log('Starting Condition Interval Drug Era Count Probability Analysis',
      'ins_cond_drug_count_prob');

    PERFORM 'TRUNCATE TABLE osim_cond_drug_count_prob';
    --COMMIT;

    -- Drop Indexes for Quicker Insertion
    BEGIN
      PERFORM 'DROP INDEX osim_cond_drug_count_prob_ix1';
      PERFORM 'DROP INDEX osim_cond_drug_count_prob_ix2';
    EXCEPTION
      WHEN OTHERS THEN
        PERFORM insert_log('Probability indexes are already removed',
            'ins_cond_drug_count_prob');
    END;

     --COMMIT;


    INSERT /*+ append nologging */ INTO osim_cond_drug_count_prob
    (  condition_concept_id, interval_bucket, age_bucket, drug_count_bucket,
        condition_count_bucket, drug_count, n, accumulated_probability )
    WITH gaps AS
     (SELECT
       cond_gaps.person_id,
       cond_gaps.age_bucket,
       cond_gaps.cond_start_date,
       cond_gaps.next_cond_start_date,
       cond_gaps.drug_concepts,
       cond_gaps.condition_concepts,
       cond_gaps.day_cond_count,
       coalesce(COUNT(DISTINCT drug.drug_concept_id),0) AS drug_count
      FROM
       (SELECT
          cond_dates.person_id,
          cond_dates.condition_era_start_date AS cond_start_date,
          person.drug_concepts,
          person.condition_concepts,
          osim__age_bucket(
            person.age + (cond_dates.condition_era_start_date
              - person.observation_period_start_date) / 365.25)
                      AS age_bucket,
          LEAD (cond_dates.condition_era_start_date,1,
              person.observation_period_end_date)
            OVER (PARTITION BY cond_dates.person_id
                  ORDER BY cond_dates.condition_era_start_date)
                    AS next_cond_start_date,
          cond_dates.day_cond_count
        FROM v_src_person_strata person
        INNER JOIN
         (SELECT
            person_id,
            condition_era_start_date,
            COUNT(condition_concept_id) AS day_cond_count
          FROM
           (SELECT DISTINCT
              cond.person_id,
              cond.condition_concept_id,
              cond.condition_era_start_date
            FROM v_src_condition_era1 cond
            UNION
            SELECT
              person_id,
              -1 AS condition_concept_id,
              observation_period_start_date AS condition_era_start_date
            FROM v_src_person_strata) t1
          GROUP BY person_id, condition_era_start_date) cond_dates
          ON person.person_id = cond_dates.person_id
        WHERE person.observation_period_end_date
          >= cond_dates.condition_era_start_date) cond_gaps
      LEFT JOIN v_src_first_drugs drug ON cond_gaps.person_id = drug.person_id
          AND cond_gaps.cond_start_date <= drug.drug_era_start_date
          AND cond_gaps.next_cond_start_date > drug.drug_era_start_date
      GROUP BY cond_gaps.person_id, cond_gaps.age_bucket, cond_gaps.cond_start_date,
        cond_gaps.next_cond_start_date, cond_gaps.drug_concepts,
        cond_gaps.condition_concepts,cond_gaps.day_cond_count)
    SELECT
      condition_concept_id,
      interval_bucket,
      age_bucket,
      drug_count_bucket,
      condition_count_bucket,
      gap_drug_count,
      n,
      SUM(probability)
        OVER
         (PARTITION BY condition_concept_id, interval_bucket, age_bucket,
                   drug_count_bucket, condition_count_bucket
          ORDER BY probability DESC
            ROWS UNBOUNDED PRECEDING) accumulated_probability
    FROM
     (SELECT
        condition_concept_id,
        interval_bucket,
        age_bucket,
        drug_count_bucket,
        condition_count_bucket,
        gap_drug_count,
        sum_prob AS n,
        1.0 * sum_prob/ NULLIF(SUM(sum_prob)
                                OVER(PARTITION BY condition_concept_id, interval_bucket, age_bucket,
                   drug_count_bucket, condition_count_bucket), 0) AS probability
      FROM
       (SELECT
          condition_concept_id,
          interval_bucket,
          age_bucket,
          drug_count_bucket,
          condition_count_bucket,
          gap_drug_count,
          SUM(prob) AS sum_prob
        FROM
         (SELECT DISTINCT
            gaps.person_id,
            gaps.age_bucket,
            cond.condition_concept_id,
            gaps.cond_start_date,
            gaps.next_cond_start_date,
            osim__drug_count_bucket(gaps.drug_concepts) AS drug_count_bucket,
            osim__condition_count_bucket(gaps.condition_concepts)
              AS condition_count_bucket,
            osim__duration_days_bucket(gaps.next_cond_start_date
                - gaps.cond_start_date) AS interval_bucket,
            1 AS prob,
            gaps.drug_count as gap_drug_count
          FROM gaps
          INNER JOIN v_src_condition_era1 cond
            ON gaps.person_id = cond.person_id
            AND gaps.cond_start_date = cond.condition_era_start_date
          UNION
          SELECT DISTINCT
            person_id,
            age_bucket,
            -1 AS condition_concept_id,
            FIRST_VALUE(cond_start_date)
              OVER (PARTITION BY person_id ORDER BY cond_start_date)
                AS cond_start_date,
            FIRST_VALUE(next_cond_start_date)
              OVER (PARTITION BY person_id ORDER BY cond_start_date)
                AS next_cond_start_date,
            osim__drug_count_bucket(drug_concepts)
                AS drug_count_bucket,
            osim__condition_count_bucket(condition_concepts)
                AS condition_count_bucket,
            osim__duration_days_bucket(FIRST_VALUE(next_cond_start_date)
              OVER (PARTITION BY person_id ORDER BY cond_start_date)
            - FIRST_VALUE(cond_start_date)
                OVER (PARTITION BY person_id ORDER BY cond_start_date))
                  AS interval_bucket,
            1 AS prob,
            FIRST_VALUE(drug_count)
              OVER (PARTITION BY person_id ORDER BY cond_start_date)
                AS gap_drug_count
          FROM gaps
          ORDER BY 1,3,2) t1
        GROUP BY condition_concept_id, interval_bucket, age_bucket, drug_count_bucket,
          condition_count_bucket, gap_drug_count
      ORDER BY 1,2,3,4,5,7 DESC) t2
     ) t3
    ORDER BY 1,2,3,4,5,8;

    GET DIAGNOSTICS num_rows = ROW_COUNT;
    MESSAGE := num_rows || ' rows inserted into osim_cond_drug_count_prob.';
    PERFORM insert_log(MESSAGE, 'ins_cond_drug_count_prob');

     --COMMIT;

    PERFORM '
    CREATE INDEX osim_cond_drug_count_prob_ix1 ON osim_cond_drug_count_prob (
      condition_concept_id, interval_bucket, age_bucket, drug_count_bucket,
      condition_count_bucket)
    NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
      INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 10 FREELIST GROUPS 10 BUFFER_POOL DEFAULT)';

    PERFORM '
    CREATE INDEX osim_cond_drug_count_prob_ix2
      ON osim_cond_drug_count_prob (accumulated_probability)
    NOLOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 STORAGE (
      INITIAL 10M NEXT 10M MINEXTENTS 1 MAXEXTENTS 2147483645
      PCTINCREASE 0 FREELISTS 10 FREELIST GROUPS 10 BUFFER_POOL DEFAULT)';

    --COMMIT;

    -- a few of the last buckets may not quite add up to 1.0
    UPDATE osim_cond_drug_count_prob
    SET accumulated_probability = 1.0
    WHERE oid IN
     (SELECT DISTINCT
        FIRST_VALUE(oid)
          OVER
           (PARTITION BY condition_concept_id, interval_bucket, age_bucket,
              drug_count_bucket, condition_count_bucket
            ORDER BY accumulated_probability DESC)
      FROM osim_cond_drug_count_prob);

    --COMMIT;

    PERFORM insert_log('Processing complete', 'ins_cond_drug_count_prob');
  EXCEPTION
    WHEN OTHERS THEN
    PERFORM insert_log('Exception', 'ins_cond_drug_count_prob');

  END;
$$;
