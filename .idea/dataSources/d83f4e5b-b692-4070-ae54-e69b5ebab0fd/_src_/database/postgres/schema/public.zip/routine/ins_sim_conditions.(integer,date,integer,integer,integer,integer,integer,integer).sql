create function ins_sim_conditions(max_person_id integer, this_person_begin_date date, this_age integer, this_gender integer, this_obs_days integer, INOUT this_person_cond_count_limit integer, INOUT max_condition_era_id integer, INOUT this_cond_count_bucket integer) returns record
LANGUAGE plpgsql
AS $$
DECLARE
    tmp_rand                      FLOAT;
    this_person_cond_count        INTEGER;
    this_person_era_count         INTEGER;
    this_cond_date                DATE;
    this_cond_concept             INTEGER;
    this_cond_delta_days          INTEGER;
    init_cond_date                DATE;
    init_cond_concept             INTEGER;
    init_cond_delta_days          INTEGER;
    init_cond_age                 INTEGER;
    init_cond_time_remaining      INTEGER;
    this_cond_age                 INTEGER;
    this_cond_age_bucket          INTEGER;
    this_cond_time_remaining      INTEGER;
    tmp_time_remaining            INTEGER;
    prev_cond_concept             INTEGER;
    this_era_date                 DATE;
    this_end_date                 DATE;
    this_era_age                  INTEGER;
    this_era_age_bucket           INTEGER;
    this_era_delta_days           INTEGER;
    this_era_time_remaining       INTEGER;
    this_cond_era_count_limit     INTEGER;
    this_cond_era_count           INTEGER;

  BEGIN
    -- Clear existing condition concepts for new person
    DROP TABLE IF EXISTS this_person_conditions_table;
    CREATE TEMPORARY TABLE this_person_conditions_table (
      condition_concept_id INTEGER NOT NULL
    ) ON COMMIT DELETE ROWS;

    this_person_cond_count := 0;
    this_person_era_count := 0;

    -- Initial date and condition concept of -1
    --
    this_cond_date := this_person_begin_date;
    this_cond_concept := -1;
    this_cond_delta_days := 0;

    init_cond_date := this_person_begin_date;
    init_cond_concept := -1;
    init_cond_delta_days := 0;

    --
    -- Simulate Conditions
    --
    WHILE this_person_cond_count < this_person_cond_count_limit
    LOOP

      -- For very first condition, non bucketed age is used
      -- For subsequent conditions based on prior condition transition,
      --   the age bucket is used
      this_cond_age :=
        CASE
          WHEN this_cond_concept = -1 THEN this_age
          ELSE this_cond_age + this_cond_delta_days / 365.25
        END;

      this_cond_age_bucket :=
        CASE
          WHEN this_cond_concept = -1 THEN this_cond_age
          ELSE osim__age_bucket(CAST(this_cond_age AS INTEGER))
        END;

      this_cond_date :=
        CASE
          WHEN this_cond_concept = -1 THEN this_person_begin_date
          ELSE this_cond_date + this_cond_delta_days
        END;

      this_cond_time_remaining :=
        CASE
          WHEN this_cond_concept = -1 THEN this_obs_days
          ELSE this_cond_time_remaining - this_cond_delta_days
        END;

      tmp_time_remaining := osim__time_observed_bucket(this_cond_time_remaining);

      -- Draw for next condition and days until it starts
      prev_cond_concept := this_cond_concept;
      tmp_rand := random();
      BEGIN
        SELECT DISTINCT
          FIRST_VALUE(condition2_concept_id)
            OVER (ORDER BY accumulated_probability),
          coalesce(FIRST_VALUE(delta_days)
            OVER (ORDER BY accumulated_probability) ,0)
        INTO STRICT this_cond_concept, this_cond_delta_days
          FROM osim_first_cond_probability prob
          WHERE prob.condition1_concept_id = this_cond_concept
            AND prob.gender_concept_id = this_gender
            AND prob.age_range = this_cond_age_bucket
            AND prob.cond_count_bucket = this_cond_count_bucket
            AND time_remaining = tmp_time_remaining
            AND tmp_rand <= prob.accumulated_probability;
      EXCEPTION
        WHEN NO_DATA_FOUND
          THEN
            this_cond_concept := -1;
            this_cond_delta_days := 0;
      END;

      -- Randomize from returned days bucket
      this_cond_delta_days := (osim__randomize_days(this_cond_delta_days));

      -- If the person already has this conditon concept,
      --   do not add it again

      IF this_cond_concept >= 0
        AND NOT EXISTS (SELECT 1 FROM this_person_conditions_table WHERE condition_concept_id = this_cond_concept)
      THEN

        this_era_date := this_cond_date + this_cond_delta_days;
        this_era_age := this_cond_age + this_cond_delta_days / 365.25;
        this_era_time_remaining := this_cond_time_remaining - this_cond_delta_days;

        IF init_cond_concept = -1 THEN
          init_cond_concept := this_cond_concept;
          init_cond_age := this_era_age;
          init_cond_time_remaining := this_era_time_remaining;
          init_cond_date := this_era_date;
        END IF;

        -- Draw For Conditon Era Count for this Condition Concept
        tmp_rand := random();
        tmp_time_remaining := osim__time_observed_bucket(this_era_time_remaining);
        BEGIN
          SELECT DISTINCT
            FIRST_VALUE(cond_era_count) OVER (ORDER BY accumulated_probability)
          INTO STRICT this_cond_era_count_limit
          FROM osim_cond_era_count_prob prob
          WHERE prob.cond_count_bucket = this_cond_count_bucket
            AND prob.condition_concept_id = this_cond_concept
            AND prob.time_remaining = tmp_time_remaining
            AND tmp_rand <= prob.accumulated_probability;
        EXCEPTION
          WHEN NO_DATA_FOUND
            THEN
              -- this should not ever happen
              this_cond_era_count_limit := 1;
        END;

        -- Write first Condition Era  for the Conditon Concept
        max_condition_era_id := max_condition_era_id + 1;
        INSERT INTO osim_tmp_condition_era
         (condition_era_id, condition_era_start_date, condition_era_end_date,
          person_id, condition_concept_id,
          condition_occurrence_count)
          SELECT
            max_condition_era_id,
            this_era_date,
            this_era_date,
            max_person_id,
            this_cond_concept,
            1
          ;
        this_person_era_count := this_person_era_count + 1;
        this_cond_era_count := 1;

        this_person_cond_count := this_person_cond_count + 1;

        INSERT INTO this_person_conditions_table VALUES (this_cond_concept);

        -- Now Insert Condition Reoccurrences
        WHILE this_cond_era_count < this_cond_era_count_limit
        LOOP
          tmp_rand := random();
          tmp_time_remaining := osim__time_observed_bucket(this_era_time_remaining);
          this_era_age_bucket := osim__age_bucket(this_era_age);

          -- Draw for days until the subsequent Conditon Era
          BEGIN
            SELECT DISTINCT
              FIRST_VALUE(delta_days)
                OVER (ORDER BY accumulated_probability) as delta_days
            INTO STRICT this_era_delta_days
            FROM osim_cond_reoccur_probability prob
              WHERE condition_concept_id = this_cond_concept
              AND age_range = this_era_age_bucket
              AND time_remaining = tmp_time_remaining
              AND tmp_rand <= accumulated_probability;
          EXCEPTION
            WHEN NO_DATA_FOUND
              THEN
                -- Reset to first occurrence
                this_era_age_bucket := 0;
                this_era_date := this_cond_date + this_cond_delta_days;
                this_era_age := this_cond_age + this_cond_delta_days / 365.25;
                this_era_time_remaining := this_cond_time_remaining
                    - this_cond_delta_days;
                this_cond_era_count_limit := this_cond_era_count_limit - 1;
          END;
          IF this_era_age_bucket > 0 THEN
            --
            -- Write Condition Era
            --
            -- Randomize from returned days bucket
            this_era_delta_days := (osim__randomize_days(this_era_delta_days));
            this_era_date := this_era_date + this_era_delta_days;
            this_era_age := this_era_age + this_era_delta_days / 365.25;
            this_era_time_remaining := this_era_time_remaining
                - this_era_delta_days;

            max_condition_era_id := max_condition_era_id + 1;
            INSERT INTO osim_tmp_condition_era
             (condition_era_id, condition_era_start_date, condition_era_end_date,
              person_id, condition_concept_id,
              condition_occurrence_count)
              SELECT
                max_condition_era_id,
                this_era_date,
                this_era_date,
                max_person_id,
                this_cond_concept,
                1
              ;

            this_person_era_count := this_person_era_count + 1;
            this_cond_era_count := this_cond_era_count + 1;

          END IF;

          IF this_era_time_remaining < 0 THEN
            this_era_date := this_cond_date;
            this_era_age := this_cond_age;
            this_era_time_remaining := this_cond_time_remaining;
            this_cond_era_count_limit := this_cond_era_count_limit - 1;
          END IF;

        END LOOP;

      ELSE -- person already has drawn conditon

        IF this_cond_concept < 0 AND init_cond_concept < 0 THEN
          this_person_cond_count_limit := this_person_cond_count_limit - 1;
        END IF;

        IF this_cond_concept < 0 AND init_cond_concept >= 0 THEN
          IF random() <= 0.5 THEN
            this_cond_concept := init_cond_concept;
            this_cond_age := init_cond_age;
            this_cond_time_remaining := init_cond_time_remaining;
            this_cond_date := init_cond_date;
            --Prevent Deadlock
            IF random() <= 0.2 THEN
              this_person_cond_count_limit := this_person_cond_count_limit - 1;
            END IF;
          END IF;
          this_cond_delta_days := 0;
        END IF;

        IF this_cond_concept >= 0 THEN
          IF random() <= 0.5 THEN
            this_cond_delta_days := 0;
          END IF;

        END IF;

      END IF;

    END LOOP; -- All Conditon Eras are complete for this person

    -- Just in case there are duplicate conditions on the same date
    DELETE FROM osim_tmp_condition_era
    WHERE condition_era_id
    IN
     (SELECT cond1.condition_era_id
      FROM osim_tmp_condition_era cond1
      INNER JOIN osim_tmp_condition_era cond2
        ON cond1.person_id = cond2.person_id
          AND cond1.condition_era_start_date = cond2.condition_era_start_date
          AND cond1.condition_concept_id = cond2.condition_concept_id
      WHERE cond1.condition_era_id > cond2.condition_era_id);

    -- Just in case there are conditions out of observation date
    this_end_date = this_person_begin_date + this_obs_days;
    DELETE FROM osim_tmp_condition_era
    WHERE condition_era_start_date >= this_end_date;

    -- Set actual Condition Count Bucket
    this_person_cond_count_limit := this_person_cond_count;
    this_cond_count_bucket := osim__condition_count_bucket(this_person_cond_count);

    PERFORM insert_log('Simulated condition',
        'ins_sim_condition');
  END;
$$;
