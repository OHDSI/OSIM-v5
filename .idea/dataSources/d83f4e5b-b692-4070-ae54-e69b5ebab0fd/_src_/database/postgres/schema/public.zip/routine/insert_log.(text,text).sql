create function insert_log(text, text) returns void
LANGUAGE plpgsql
AS $$
DECLARE
    m ALIAS FOR $1;
    procedure_name ALIAS FOR $2;
    open_connections TEXT [] := PUBLIC.dblink_get_connections();
    --v_conn_str  text := 'port=5432 dbname=postgres host=ohdsi_v5.i3l.gatech.edu user=ohdsi_admin_user password=J4ckets_4_synpUf';
    v_conn_str  text := 'port=5432 dbname=postgres host=localhost user=kausarm password=Pass@123';
    v_query     text;
    my_dblink_name TEXT := 'logging_dblink' ;
  BEGIN
    IF open_connections IS NULL
       OR NOT open_connections @> ARRAY [ my_dblink_name ] THEN
        PERFORM PUBLIC.dblink_connect(
            my_dblink_name, v_conn_str);
        raise notice 'New db link connection made' ;
    ELSE
        raise notice 'Db link connection exists, re-using' ;
    END IF;

    v_query := 'SELECT true FROM insert_log_atx( ' || quote_nullable(m) ||
		 ',' || quote_nullable(procedure_name) || ')';
    PERFORM PUBLIC.dblink_exec(my_dblink_name, v_query);

    -- PERFORM * FROM dblink(v_conn_str, v_query) AS p (ret boolean);
  END;
$$;
