create function osim__duration_days_bucket(integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
    days ALIAS FOR $1;
  BEGIN
    CASE TRUE
      WHEN days <= 7 THEN RETURN 7;
      ELSE RETURN 8;
    END CASE;
  END;
$$;
