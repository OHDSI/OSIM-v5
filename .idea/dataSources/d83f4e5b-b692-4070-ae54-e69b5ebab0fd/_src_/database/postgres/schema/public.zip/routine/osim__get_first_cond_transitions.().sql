create function osim__get_first_cond_transitions() returns SETOF cond_transition
LANGUAGE plpgsql
AS $$
DECLARE
      rs COND_TRANSITION;
    BEGIN
      for rs in SELECT
        strata.gender_concept_id,
        coalesce(osim__age_bucket(LAG(strata.age,1)
          OVER (PARTITION BY strata.person_id
          ORDER BY condition_era_start_date, condition_concept_id)),strata.age)
            AS age_range,
        OSIM__condition_count_bucket(strata.condition_concepts) AS cond_count_bucket,
        OSIM__time_observed_bucket(strata.observation_period_end_date -
          coalesce(LAG(cond.condition_era_start_date,1)
            OVER (PARTITION BY strata.person_id
            ORDER BY condition_era_start_date, condition_concept_id),
              strata.observation_period_start_date)) AS time_remaining,
        coalesce(LAG(condition_concept_id,1)
          OVER (PARTITION BY strata.person_id
          ORDER BY condition_era_start_date, condition_concept_id),-1)
            AS condition1_concept_id,
        condition_concept_id AS condition2_concept_id,
        OSIM__ROUND_DAYS(cond.condition_era_start_date -
          coalesce(LAG(cond.condition_era_start_date,1)
            OVER (PARTITION BY strata.person_id
            ORDER BY condition_era_start_date, condition_concept_id),
              strata.observation_period_start_date)) AS delta_days
      FROM v_src_person_strata strata
      INNER JOIN v_src_first_conditions cond
        ON strata.person_id = cond.person_id
      ORDER BY 1,2,3,4
    LOOP
      RETURN NEXT rs;
    END LOOP;
    RETURN;
  END;
$$;
