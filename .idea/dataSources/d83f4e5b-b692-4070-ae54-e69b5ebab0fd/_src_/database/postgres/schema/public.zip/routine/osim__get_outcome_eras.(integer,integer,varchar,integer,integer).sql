create function osim__get_outcome_eras(integer, integer, character varying, integer, integer) returns SETOF drug_cond_outcome
LANGUAGE plpgsql
AS $$
DECLARE
  drug_concept_id ALIAS FOR $1;
  condition_concept_id ALIAS FOR $2;
  outcome_risk_type  ALIAS FOR $3;
  outcome_onset_days_min ALIAS FOR $4;
  outcome_onset_days_max ALIAS FOR $5;
  p_drug_concept_id      INTEGER;
  p_condition_concept_id INTEGER;
  outcomes_cur CURSOR  FOR
      SELECT DISTINCT
        drug.person_id,
        drug.drug_era_id,
        cond.condition_era_id
      FROM osim_drug_era drug
      INNER JOIN
       (SELECT DISTINCT
          person_id,
          FIRST_VALUE(drug_era_id)
            OVER (PARTITION BY person_id
                  ORDER BY drug_era_start_date) AS drug_era_id,
          FIRST_VALUE(drug_era_start_date)
            OVER (PARTITION BY person_id
                  ORDER BY drug_era_start_date) AS drug_era_start_date
        FROM osim_drug_era
        WHERE drug_concept_id = p_drug_concept_id) first_drug
        ON drug.person_id = first_drug.person_id
      INNER JOIN osim_condition_era cond ON drug.person_id = cond.person_id
        AND cond.condition_concept_id = p_condition_concept_id
      WHERE drug.drug_concept_id = p_drug_concept_id
        AND 1 =
          CASE
            WHEN outcome_risk_type = 'first exposure' THEN
              CASE
                WHEN drug.drug_era_start_date = first_drug.drug_era_start_date THEN 1
                ELSE 0
              END
            ELSE 1
          END
        AND 1 =
          CASE
            WHEN (outcome_risk_type = 'insidious'
              OR outcome_risk_type = 'accumulative') THEN
              CASE
                WHEN cond.condition_era_start_date
                  BETWEEN drug.drug_era_start_date AND drug.drug_era_end_date THEN 1
                ELSE 0
              END
            WHEN cond.condition_era_start_date
              BETWEEN drug.drug_era_start_date + coalesce(outcome_onset_days_min ,0)
                AND drug.drug_era_start_date
                 + coalesce(outcome_onset_days_max, drug.drug_era_end_date
                    - drug.drug_era_start_date) THEN 1
            ELSE 0
          END;
  BEGIN
    p_drug_concept_id := drug_concept_id;
    p_condition_concept_id := condition_concept_id;
    FOR rs IN outcomes_cur LOOP
      RETURN NEXT ROW(rs);
    END LOOP;
   RETURN;

  END;
$$;
