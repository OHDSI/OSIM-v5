create function osim__round_days(bigint) returns integer
LANGUAGE plpgsql
AS $$
DECLARE days ALIAS FOR $1;
  BEGIN
    CASE
      WHEN days <= 75 THEN RETURN ROUND(days);
      ELSE RETURN ROUND(days/30) * 30;
    END CASE;
  END;
$$;
