CREATE VIEW s_observation_period AS SELECT observation_period.observation_period_id,
    observation_period.person_id,
    observation_period.observation_period_start_date,
    observation_period.observation_period_end_date,
    observation_period.period_type_concept_id
   FROM lite_synpuf2.observation_period;
