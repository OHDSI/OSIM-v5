CREATE VIEW v_src_all_conditions AS SELECT DISTINCT person.person_id,
    person.gender_concept_id,
    (to_number(to_char((cond.condition_era_start_date)::timestamp with time zone, 'yyyy'::text), '9999'::text) - (person.year_of_birth)::numeric) AS age,
    cond.condition_era_start_date,
    cond.condition_concept_id
   FROM (v_src_condition_era1 cond
     JOIN v_src_person person ON ((cond.person_id = person.person_id)));
