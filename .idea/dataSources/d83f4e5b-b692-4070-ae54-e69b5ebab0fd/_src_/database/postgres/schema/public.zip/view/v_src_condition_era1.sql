CREATE VIEW v_src_condition_era1 AS SELECT cond.condition_era_id,
    cond.condition_era_start_date,
    cond.person_id,
    cond.condition_era_end_date,
    cond.condition_concept_id,
    cond.condition_occurrence_count
   FROM (s_condition_era cond
     JOIN v_src_person person ON ((cond.person_id = person.person_id)));
