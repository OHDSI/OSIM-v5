CREATE VIEW v_src_condition_era1_ids AS SELECT DISTINCT cond.condition_era_id AS condition_occurrence_id,
    cond.condition_occurrence_count
   FROM (s_condition_era cond
     JOIN v_src_person person ON ((cond.person_id = person.person_id)));
