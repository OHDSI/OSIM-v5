CREATE VIEW v_src_drug_era1 AS SELECT drug.drug_era_id,
    drug.drug_era_start_date,
    drug.drug_era_end_date,
    drug.person_id,
    drug.drug_concept_id,
    drug.drug_exposure_count
   FROM (s_drug_era drug
     JOIN v_src_person person ON ((drug.person_id = person.person_id)));
