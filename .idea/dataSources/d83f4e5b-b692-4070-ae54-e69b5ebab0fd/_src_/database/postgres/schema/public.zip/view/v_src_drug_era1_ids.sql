CREATE VIEW v_src_drug_era1_ids AS SELECT DISTINCT drug.drug_era_id AS drug_exposure_id,
    drug.drug_exposure_count
   FROM (s_drug_era drug
     JOIN v_src_person person ON ((drug.person_id = person.person_id)));
