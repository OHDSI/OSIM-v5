CREATE VIEW v_src_first_conditions AS SELECT DISTINCT cond.person_id,
    first_value(cond.condition_era_start_date) OVER (PARTITION BY cond.person_id, cond.condition_concept_id ORDER BY cond.condition_era_start_date) AS condition_era_start_date,
    cond.condition_concept_id
   FROM (v_src_condition_era1 cond
     JOIN s_person person ON ((cond.person_id = person.person_id)))
  GROUP BY cond.person_id, cond.condition_era_start_date, cond.condition_concept_id;
