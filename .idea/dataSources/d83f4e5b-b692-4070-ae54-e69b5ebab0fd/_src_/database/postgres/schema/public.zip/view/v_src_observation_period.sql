CREATE VIEW v_src_observation_period AS SELECT obs.observation_period_id,
    obs.observation_period_start_date,
    obs.observation_period_end_date,
    obs.person_id
   FROM (s_observation_period obs
     JOIN v_src_person person ON ((obs.person_id = person.person_id)));
