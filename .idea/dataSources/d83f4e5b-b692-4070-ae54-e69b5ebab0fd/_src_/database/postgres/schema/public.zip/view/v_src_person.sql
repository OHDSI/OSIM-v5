CREATE VIEW v_src_person AS SELECT DISTINCT person.person_id,
    person.year_of_birth,
    person.gender_concept_id,
    person.race_concept_id,
    person.ethnicity_concept_id,
    person.location_id,
    person.gender_source_concept_id,
    person.race_source_concept_id,
    person.ethnicity_source_concept_id
   FROM (s_person person
     JOIN s_observation_period period ON ((person.person_id = period.person_id)))
  WHERE ((person.year_of_birth IS NOT NULL) AND (period.observation_period_start_date IS NOT NULL));
