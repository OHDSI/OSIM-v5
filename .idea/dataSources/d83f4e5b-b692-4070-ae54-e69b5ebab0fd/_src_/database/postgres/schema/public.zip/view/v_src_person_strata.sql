CREATE VIEW v_src_person_strata AS WITH drug_counts AS (
         SELECT person.person_id,
            count(DISTINCT drug_era.drug_concept_id) AS drugs
           FROM (v_src_person person
             JOIN s_drug_era drug_era ON ((person.person_id = drug_era.person_id)))
          GROUP BY person.person_id
        ), cond_counts AS (
         SELECT person.person_id,
            count(DISTINCT condition_era.condition_concept_id) AS conditions
           FROM (v_src_person person
             JOIN s_condition_era condition_era ON ((person.person_id = condition_era.person_id)))
          GROUP BY person.person_id
        ), person_strata AS (
         SELECT person.person_id,
            person.year_of_birth,
            person.gender_concept_id,
            person.race_concept_id,
            person.ethnicity_concept_id,
            person.location_id,
            person.gender_source_concept_id,
            person.race_source_concept_id,
            person.ethnicity_source_concept_id,
            min(period.observation_period_start_date) AS observation_period_start_date,
            max(period.observation_period_end_date) AS observation_period_end_date,
            (to_number(to_char((min(period.observation_period_start_date))::timestamp with time zone, 'yyyy'::text), '9999'::text) - (person.year_of_birth)::numeric) AS age,
            (max(period.observation_period_end_date) - min(period.observation_period_start_date)) AS obs_duration_days
           FROM (v_src_person person
             JOIN s_observation_period period ON ((person.person_id = period.person_id)))
          GROUP BY person.person_id, person.year_of_birth, person.gender_concept_id, person.race_concept_id, person.ethnicity_concept_id, person.location_id, person.gender_source_concept_id, person.race_source_concept_id, person.ethnicity_source_concept_id
        )
 SELECT strata.person_id,
    strata.year_of_birth,
    strata.gender_concept_id,
    strata.race_concept_id,
    strata.ethnicity_concept_id,
    strata.location_id,
    strata.gender_source_concept_id,
    strata.race_source_concept_id,
    strata.ethnicity_source_concept_id,
    strata.observation_period_start_date,
    strata.observation_period_end_date,
    strata.age,
    strata.obs_duration_days,
    COALESCE(cond.conditions, (0)::bigint) AS condition_concepts,
    COALESCE(drug.drugs, (0)::bigint) AS drug_concepts
   FROM ((person_strata strata
     LEFT JOIN cond_counts cond ON ((strata.person_id = cond.person_id)))
     LEFT JOIN drug_counts drug ON ((strata.person_id = drug.person_id)));
